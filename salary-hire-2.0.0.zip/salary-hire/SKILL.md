---
name: salary-hire
description: 为拟入职候选人制作招聘定薪方案。录入原单位薪资与拟入职岗位，处理截图和文本回填，校验组织权限、确认对标名单、计算拟定薪资并导出 Excel。
metadata:
  platform: 星Claw
  version: "2.0.0"
---

# 招聘定薪

平台在一次业务会话内复用一个 `hire.HireSession`。用户提出在职员工调薪时使用在职调薪流程。构造参数与故障处理见 [平台集成](references/platform-integration.md)。

| 阶段 | 事件 | 调用与交付 |
|---|---|---|
| 开始或新候选人 | 定薪，可带姓名、组织、薪资 | `start(name=..., org=..., text=...)`。缺姓名仍可先录原单位情况，进入岗位阶段前补齐。 |
| 原单位 | 截图、文字、表单 | 截图识别出的字段传 `ocr(values)`，文本或 JSON 传 `parse_text(text)`，卡片提交传 `submit_origin(form)`。缺项时呈现预填卡，录齐后进入岗位卡。 |
| 原单位 | 单项修改、补姓名、文字确认 | `say_edit(field, value)`，纯确认调用 `confirm_origin()`。只缺姓名时补好姓名再确认，保留已有记录。 |
| 岗位 | 表单、文字回填、单项修改或确认 | 分别用 `submit_post(form)`、`parse_text(text)`、`say_edit(field, value)`、`confirm_post()`。疑似组织被否定时用 `reject_org()`。 |
| 补充 | 表单、文字回填、单项修改或跳过 | `submit_extra(form)`、`parse_text(text)`、`say_edit(field, value)` 或 `confirm_extra()`。补充项选填，组织权限通过后出名单卡。 |
| 名单 | 加人、删人、筛选 | `adjust("add"/"remove", 工号, section=...)` 或 `filter_roster(key, ...)`。各分区为 upper、peer、reportee。 |
| 名单 | 名单卡提交或文字确认 | `submit_roster(form)` 或 `confirm_roster()`，同轮计算方案。 |
| 方案 | 改涨幅、拟定薪数或名单 | `build_plan(ratio=0.08)`、`say_edit("months", "16薪")` 或已有名单方法，交付最新结果。 |
| 方案 | 导出 | `export(path)`，复核权限并重新生成文件。若返回故障气泡，按气泡处理。 |

表单事件优先按当前阶段路由，直接使用结构化字段。原单位固薪按元/年填写。用户提供月薪时保留原始月薪，取得薪数后年化。卡片仅改薪数时按原月薪重算，明确改填年固薪后采用新年薪。上年实发奖金和长期激励允许为零。原单位薪数必填且至少 12，拟定薪数独立，默认 13。

每轮只呈现返回的 `bubble` 和卡片，纯卡片轮直接投递。金额在卡片和方案文件中呈现。按 [卡片投递协议](references/platform-integration.md) 调用平台，用户主动取消即结束该次投递。故障重试使用平台更新后的登录态，重新绑定对应会话的适配器，再重试失败步骤一次。权限拒绝结束本次操作。

职级缺档、对标样本与审批例外见 [业务规则](references/salary-logic.md)。部署前核对 [运行配置](references/runtime-injection.md)。

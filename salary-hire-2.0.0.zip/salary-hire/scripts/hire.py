# -*- coding: utf-8 -*-
"""定薪状态机（五步：权限 → 原单位 → 入职岗位 → 补充 → 方案）。

口径（sheet3「定薪需求说明」）：
  拟定固薪 = 原单位固薪 × (1 + 系统建议涨幅)
  月薪     = 拟定固薪 / 13（或 12）
  奖金基线 = 固薪 × 占比/(1-占比)；占比按拟定 GGS 标准表
  上年实发奖金/长期激励（拟定）= 同层级平均
  GGS ≤ 12 → 简化模板（无长期激励）
"""

import datetime
import importlib.util
import json
import re
import urllib.error
from pathlib import Path

from card_delivery import emit as _emit
import calc
import rules
import roster as roster_mod
from roster_session import RosterSession, card_person
from structure import parse_grade, standard_bonus_ratio, city_tier


def _load_export():
    """只加载本 Skill 的 export.py，避免两个 Skill 同名模块串用。

    openpyxl 缺失只影响导出，不能拖垮 start/confirm 等前置流程：
    导入失败返回 None，由调用方按话术表兜底（「方案文件暂时无法生成」）。
    """
    path = Path(__file__).resolve().with_name("export.py")
    spec = importlib.util.spec_from_file_location("salary_hire_export", str(path))
    mod = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(mod)
    except ImportError:
        return None
    return mod


export_mod = _load_export()

ORIGIN_FIELDS = [
    ("company", "公司名", "input", True),
    ("post", "岗位", "input", True),
    ("city", "城市", "input", True),
    ("base_pay", "固薪（元/年）", "money", True),
    ("months", "薪酬月数（几薪）", "radio", True),
    ("last_bonus", "上年奖金（元）", "money", True),
    ("last_lti", "上年长期激励", "money", True),
]

POST_FIELDS = [
    ("org", "组织", "input", True),
    ("post", "岗位", "input", True),
    ("city", "城市", "input", True),
    ("seq", "序列", "radio", True),
    ("ggs", "GGS（1-30）", "stepper", True),
]
# GGS 合法区间（卡片 stepper 范围与 confirm_post 校验共用）
GGS_MIN, GGS_MAX = 1, 30

EXTRA_FIELDS = [
    ("cash_allowance", "现金补贴（元/年）", "input"),
    ("cash_note", "现金补贴说明", "input"),
    ("social", "社保说明", "input"),
    ("fund", "公积金说明", "input"),
    ("lti_note", "长期激励说明", "input"),
    ("special", "特殊约定", "input"),
]

# 卡片字段名对薪酬平台模板（card_salary_origin v222：cityName/salaryMonth；
# card_salary_extra v95：cashSubsidy/cashMemo/socialMemo/fundMemo/ltiMemo）
ORIGIN_CARD_KEYS = {"company": "companyName", "post": "jobName", "city": "cityName",
                    "base_pay": "basePay", "months": "salaryMonth",
                    "last_bonus": "lastBonus", "last_lti": "lastLti"}
POST_CARD_KEYS = {"org": "l2", "post": "jobName", "city": "cityType",
                  "seq": "jobSequence", "ggs": "empLevel"}
EXTRA_CARD_KEYS = {"cash_allowance": "cashSubsidy", "cash_note": "cashMemo",
                   "social": "socialMemo", "fund": "fundMemo", "lti_note": "ltiMemo"}
_ALIAS = {}
for _m in (ORIGIN_CARD_KEYS, POST_CARD_KEYS, EXTRA_CARD_KEYS):
    for _k, _v in _m.items():
        _ALIAS[_v] = _k
# 平台卡片 params 键 → 内部字段（_post_card/_origin_card 的 params 键与
# 内部键不同名的必须补齐，否则 event.form / say_edit 按卡键回传时值会写错地方：
# 真实案例：岗位卡 params 键是 job，缺映射时写进 post["job"]，confirm_post 报「还差：岗位」）
_ALIAS.update({"job": "post", "cityType": "city", "cityName": "city",
               "jobSequence": "seq", "empLevel": "ggs", "jobName": "post"})
_ALIAS.update({"months": "months", "13薪/12薪": "months",
               "12薪": "months", "13薪": "months", "薪数": "months",
               # 候选人常贴的 JSON/口语键名（baseSalary/totalPackage/payMonth 等）
               "baseSalary": "base_pay", "basePay": "base_pay",
               "baseSalaryYear": "base_pay",
               "payMonth": "months", "salaryMonth": "months",
               "salaryMonths": "months", "薪酬月数": "months",
               "totalPackage": "_total_package", "年总包": "_total_package",
               "companyName": "company", "公司名": "company",
               # 卡片上的中文标签（用户会照着卡片说「公司改成 X」「固薪 30 万」）
               "公司": "company", "原公司": "company",
               "固薪": "base_pay", "固定收入": "base_pay", "固定薪酬": "base_pay",
               "组织": "org", "入职部门": "org", "部门": "org",
               "jobName": "post", "岗位": "post", "职位": "post",
               "入职岗位": "post",
               "cityType": "city", "城市": "city", "工作地点": "city", "驻地": "city",
               "序列": "seq", "GGS": "ggs", "GGS等级": "ggs", "职级": "ggs",
               "lastBonus": "last_bonus", "上年奖金": "last_bonus",
               "lastLti": "last_lti", "上年长期激励": "last_lti",
               "现金补贴": "cash_allowance", "补贴": "cash_allowance",
               "现金补贴说明": "cash_note", "补贴说明": "cash_note",
               "社保": "social", "社保说明": "social",
               "公积金": "fund", "公积金说明": "fund",
               "长期激励说明": "lti_note", "特殊约定": "special",
               "base_pay_basis": "base_pay_basis", "固薪口径": "base_pay_basis",
               "薪资口径": "base_pay_basis"})

# say_edit 允许修改的内部字段（未知字段不再静默写入错误位置）
_EDIT_FIELDS = ({key for key, _, _, _ in ORIGIN_FIELDS}
                | {key for key, _, _, _ in POST_FIELDS}
                | {key for key, _, _ in EXTRA_FIELDS}
                | {"bonus_ratio", "base_pay_basis", "_total_package", "new_fixed"})


def _today():
    return datetime.date.today().strftime("%Y%m%d")

# 国籍代码映射（薪酬台账 nationality 为代码值 CN/HK/KR/TW/US…）：
# 用户口语「中国/中国籍」按大中华口径 = CN+HK+TW+MO；其余中文名/代码值精确展开。
_NAT_CN = {"CN", "HK", "TW", "MO"}
_NAT_ALIAS = {
    "中国": _NAT_CN, "中国籍": _NAT_CN, "大陆": {"CN"}, "中国大陆": {"CN"},
    "内地": {"CN"}, "香港": {"HK"}, "中国香港": {"HK"}, "台湾": {"TW"},
    "中国台湾": {"TW"}, "澳门": {"MO"}, "韩国": {"KR"}, "美国": {"US"},
    "日本": {"JP"}, "新加坡": {"SG"},
    "CN": {"CN"}, "HK": {"HK"}, "TW": {"TW"}, "MO": {"MO"}, "KR": {"KR"},
    "US": {"US"}, "JP": {"JP"}, "SG": {"SG"},
}


def _nationality_codes(text):
    """「中国/中国籍/中国香港/CN/HK…」→ 国籍代码集合；不识别返回空集。"""
    key = str(text or "").strip().upper()
    if key in _NAT_ALIAS:            # 代码值直接命中（upper 后）
        return set(_NAT_ALIAS[key])
    return set(_NAT_ALIAS.get(str(text or "").strip(), set()))


# ---- 异常兜底：任何步骤抛异常都转成标准故障气泡，不把报错裸抛给平台 agent ----
# （agent 拿到裸异常只能自己编话术；有了兜底，对用户的话永远只有规定的那几句。）
NET_ERR_TEXT = "系统繁忙，请稍后再试。"
GENERIC_ERR_TEXT = "系统暂时出了点问题，请稍后再试；问题持续请联系管理员。"
AUTH_ERR_TEXT = "你的登录状态已过期或未生效，请重新进入对话再试。"
PERM_DENIED_TEXT_ORG = ("组织「%s」不在你的薪酬权限范围内，"
                        "不能作为入职组织，请换一个组织。")
NAME_REQUIRED_TEXT = "请提供候选人姓名。"
# 薪酬月数下限：至少 12 薪（confirm_origin 闸门；低于 12 的输入原样保留但拦下重问）
MONTHS_MIN = 12
MONTHS_MIN_TEXT = ("薪酬月数需至少为 12（当前 %d），请核对后重新填写薪酬月数。")

# 鉴权/登录态类错误特征（PMS ssoToken 过期等）：重试无意义，应引导重新进入对话拿新 token
_AUTH_ERR_MARKS = ("SSO验证失败", "validate fail", "token无效", "token已过期",
                   "token 无效", "token 已过期", "401")


def _looks_auth_error(e):
    return any(k in str(e) for k in _AUTH_ERR_MARKS)


def _error_text(e):
    """接口类异常 → 系统繁忙；登录态异常 → 重新登录。"""
    return AUTH_ERR_TEXT if _looks_auth_error(e) else NET_ERR_TEXT


def _safe_step(fn):
    def wrapper(self, *args, **kwargs):
        try:
            return fn(self, *args, **kwargs)
        except ImportError:
            # 依赖缺失（如 openpyxl）→ 只影响导出，按话术表回复
            return _emit(None, "方案文件暂时无法生成，请联系管理员。")
        except Exception as e:
            # 技术原因只留内部日志（stderr），用户只见规定话术
            import sys
            import traceback
            print("[step-error] %s: %s" % (fn.__name__, traceback.format_exc()),
                  file=sys.stderr)
            from adapters.foura import FourAApiError
            from salary_api import SalaryApiError
            auth = _looks_auth_error(e)
            # 4A 的 401 是共享令牌配置问题，不是用户登录态过期
            if isinstance(e, FourAApiError):
                return _emit(None, NET_ERR_TEXT)
            if isinstance(e, SalaryApiError):
                return _emit(None, AUTH_ERR_TEXT if auth else NET_ERR_TEXT)
            if isinstance(e, (urllib.error.URLError, OSError)):
                return _emit(None, NET_ERR_TEXT)
            if auth:
                # 登录态过期：让用户重试「稍后再试」是死路，正确动作是重新进入对话拿新 token
                return _emit(None, AUTH_ERR_TEXT)
            return _emit(None, GENERIC_ERR_TEXT)
    wrapper.__name__ = fn.__name__
    wrapper.__doc__ = fn.__doc__
    return wrapper


def _guard_all_steps(cls):
    for name, fn in list(vars(cls).items()):
        if (name.startswith("_") or not callable(fn)
                or getattr(fn, "__module__", "") != __name__):
            continue
        setattr(cls, name, _safe_step(fn))
    return cls



def _num(v, default=0):
    if v is None or v == "":
        return default
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).replace(",", "").replace("元", "").replace("/年", "").strip()
    try:
        return float(s)
    except ValueError:
        return default


def _money_num(v, default=0):
    """金额归一：支持「20万」「2.5万」，其余走 _num。"""
    if isinstance(v, str):
        s = v.replace(",", "").strip()
        if s.endswith("万元"):
            s = s[:-1]
        if s.endswith("万"):
            try:
                return round(float(s[:-1].strip()) * 10000, 2)
            except ValueError:
                pass
    return _num(v, default)


def _dec(v):
    """数值 → 平台 decimal 字符串（整数不带小数点，空值返回空串）。"""
    if v is None or v == "":
        return ""
    f = _num(v, None)
    if f is None:
        return str(v)
    if f == int(f):
        return str(int(f))
    return ("%.2f" % f).rstrip("0").rstrip(".")


# ---------------- 薪资归一化 ----------------
# 唯一口径：固薪 = 元/年。卡面/对话直接给的数字一律视为年固薪，不换算、不反问。
# 仅当数据形态明显是「月薪」（JSON 带 totalPackage/baseSalary/payMonth 组合，
# 或用户明说「月薪X」）时，按 月薪×薪数 换算成年固薪。
def _months_value(v):
    """任意输入 → (months:int|None, normalized_label:str|None)。非法/缺失返回 (None, None)。"""
    if v is None or v == "":
        return None, None
    s = str(v).strip()
    m = re.fullmatch(r"([0-9]+)(?:\.0+)?\s*(?:个月|薪)?", s)
    if not m:
        return None, None
    n = int(m.group(1))
    if n <= 0:
        return None, None
    return n, "%d薪" % n


def _infer_pay_basis(origin):
    """仅用于识别「用户给的是月薪」这一数据形态：baseSalary+payMonth+totalPackage
    组合贴进来、或用户显式说「月薪」时返回 "monthly"；否则一律
    "yearly"（元/年，直接用）。"""
    if origin.get("base_pay_basis") == "monthly":
        return "monthly", None         # 用户/JSON 显式标记的月薪形态
    total = _num(origin.get("_total_package"), 0)
    base = _num(origin.get("base_pay"), 0)
    months, _ = _months_value(origin.get("months"))
    if total <= 0 or base <= 0:
        return "yearly", None          # 没有 totalPackage 佐证 → 就是年口径
    monthly_total = base * (months or 13)
    # 容差 8%：贴数常有取整/补贴误差
    def near(a, b):
        return b > 0 and abs(a - b) / b <= 0.08
    if near(total, base):              # 年总包≈给的这个数 → 它本身就是年固薪
        return "yearly", None
    if near(total, monthly_total):     # 年总包≈这个数×薪数 → 它是月薪
        return "monthly", None
    if total > monthly_total * 1.08:   # 总包远大于该数×薪数 → 该数是月薪
        return "monthly", None
    return "yearly", None


def _set_pay(origin, value, basis):
    origin["_base_input"] = _money_num(value, None)
    origin["_input_basis"] = basis
    origin.pop("_pay_converted", None)
    origin.pop("_base_pay_monthly", None)


def _normalize_origin_salary(origin):
    """Derive annual pay from the original amount on each edit, including legacy sessions."""
    if "_base_input" not in origin and origin.get("base_pay") not in (None, ""):
        monthly = origin.get("_base_pay_monthly")
        _set_pay(origin, monthly if monthly is not None else origin["base_pay"],
                 "monthly" if monthly is not None else origin.get("base_pay_basis", "auto"))
    for key in ("last_bonus", "last_lti", "_total_package"):
        if key in origin:
            origin[key] = _money_num(origin[key], None)
    raw = origin.get("_base_input")
    if raw is None:
        origin["base_pay"] = None
        return origin, []
    basis = origin["_input_basis"]
    if basis == "auto":
        basis, _ = _infer_pay_basis({**origin, "base_pay_basis": "", "base_pay": raw})
    months, label = _months_value(origin.get("months"))
    total = origin.get("_total_package") or 0
    if basis == "monthly" and months is None and raw > 0 and total > 0:
        inferred = total / raw
        if 12 <= inferred <= 24 and abs(inferred - round(inferred)) < 0.000001:
            months = round(inferred)
            label = "%d薪" % months
    if months is not None:
        origin["months"] = label
    origin["base_pay_basis"] = basis
    if basis == "monthly":
        origin["base_pay"] = round(raw * months, 2) if months else None
    else:
        origin["base_pay"] = raw
    return origin, []


@_guard_all_steps
class HireSession(RosterSession):
    def __init__(self, operator="", sap=None, auth=None, baseline=None,
                 initiator_name=None, salary_client=None, sso_token=""):
        self.operator = operator
        self.initiator_name = initiator_name
        self.sap = sap
        self.auth = auth
        self.baseline = baseline
        # 4a 模式下 sap.client 是 4A 客户端（没有 list_salary），不能用；
        # 薪酬客户端显式传入 > sap.salary_client（4A 适配层）> 薪酬适配层的 sap.client
        self.salary_client = (salary_client or getattr(sap, "salary_client", None)
                              or (getattr(sap, "client", None)
                                  if hasattr(getattr(sap, "client", None), "list_salary")
                                  else None))
        self.sso_token = sso_token or getattr(sap, "sso_token", "") or getattr(auth, "sso_token", "")
        self.step = None
        self.name = ""
        self.origin = {}
        self.post = {}
        self.extra = {}
        self.bundle = None
        self.sections = []
        self.roster_locked = False
        self.audit = []
        self.user_ratio = None   # 用户显式指定的涨幅（done 后改名单重出方案时保持）
        self.user_months = None  # 用户显式指定的拟定薪数（默认13，≥12 才接受）
        self._pending_org = None
        self.confirmed_at = None
        self._missing_salary = []

    # ---------------- 原单位 ----------------
    def start(self, name="", org="", text=""):
        # 「定薪」入口直接出卡：姓名可缺（confirm_origin 时才必填），
        # 消息里带的组织/原单位字段经 org/text 参数预填进卡。
        # 每次 start 都是全新流程：先整体复位，避免同一会话换人时沿用上一位
        # 候选人的 origin/post/extra/名单/方案/留痕。
        self.name = str(name or "").strip()
        self.origin = {}
        self.post = {}
        self.extra = {}
        self.sections = []
        self.bundle = None
        self.roster_locked = False
        self._pending_org = None
        self.audit = []
        self.user_ratio = None
        self.user_months = None
        self.confirmed_at = None
        self._missing_salary = []
        self.step = None
        # 4A 有 TTL 缓存（默认 24h，FOURA_CACHE_TTL 可调）；start 只在缓存过期时刷新
        if hasattr(self.sap, "refresh"):
            self.sap.refresh()
        if org:
            self.post["org"] = org
            # 用户开头已经明确组织：能解析出编码就做真实祖先链校验；
            # 解析不出编码时不在 start 阶段用 check_org 假放行，交给
            # confirm_post / confirm_extra 的组织解析与权限闸门处理。
            if hasattr(self.auth, "check_orgs"):
                org_code = str(self.post.get("org_code") or "")
                if not org_code and hasattr(self.sap, "resolve_org"):
                    matches = self.sap.resolve_org(str(org))
                    if len(matches) == 1:
                        org_code = str(matches[0].get("cOrgCode", ""))
                        self.post["org_code"] = org_code
                if org_code:
                    gate = roster_mod.org_perm_gate(self.sap, self.auth, org_code)
                    if not gate["allowed"]:
                        self.step = "perm_denied"
                        return _emit(None, gate.get("reason") or "你没有该组织的薪酬权限。")
                # 无 org_code：暂不校验，后续 confirm_post/confirm_extra 必须解析出编码
            else:
                # 旧版兼容：auth 无 check_orgs 时按名称校验（check_org 失败关闭）
                perm = self.auth.check_org(org)
                if not perm["allowed"]:
                    self.step = "perm_denied"
                    return _emit(None, perm.get("reason") or "你没有该组织的薪酬权限。")
        if str(text or "").strip():
            # 首条消息里已带原单位字段：解析预填
            self._apply_origin_text(text)
        self.step = "origin"
        # 新流程重置用户指定：拟定薪数回默认 13（user_ratio 同理，新候选人不受旧会话影响）
        self.user_ratio = None
        self.user_months = None
        # 录齐即推进：首条消息已带全原单位必填 → 直接 confirm_origin 同轮出岗位卡，
        # 不再弹原单位卡等用户再确认；缺姓名时出预填原单位卡 + 姓名引导
        if str(text or "").strip() and not self._missing_origin():
            r = self.confirm_origin()
            if r.get("card") is None and (r.get("bubble") or "") == NAME_REQUIRED_TEXT:
                return _emit(self._origin_card(), NAME_REQUIRED_TEXT)
            return r
        return _emit(self._origin_card(), self._origin_text())

    def _apply_origin_text(self, text):
        """把一段文字里的原单位字段解析进 self.origin（JSON 优先，其次标签式）。

        start(text=…) 与 parse_text 共用；解析后统一归一化（月薪换算、任意薪数）。
        """
        jd = self._parse_json_origin(text)
        if "base_pay" in jd:
            _set_pay(self.origin, jd.pop("base_pay"), jd.pop("base_pay_basis", "auto"))
        self.origin.update(jd)
        for k, pat in self.ORIGIN_PATTERNS.items():
            m = re.search(pat, text)
            if not m:
                continue
            if k == "base_pay":
                _set_pay(self.origin, m.group(1), "yearly")
            elif k == "monthly_pay":
                _set_pay(self.origin, m.group(1), "monthly")
            elif k in ("last_bonus", "last_lti"):
                self.origin[k] = _money_num(m.group(1))
            elif k == "bonus_ratio":
                self.origin[k] = self._ratio(m.group(1))
            elif k == "months":
                # 「薪酬月数：13」「13薪」统一落成「N薪」
                self.origin["months"] = "%d薪" % int(m.group(1))
            else:
                self.origin[k] = m.group(1)
        # 任意薪数：不再限定 12/13（兜底「N薪」写法，不与 months 模式冲突）
        if "months" not in jd and not re.search(self.ORIGIN_PATTERNS["months"], text):
            m = re.search(r"(\d+)\s*薪", text)
            if m:
                self.origin["months"] = "%d薪" % int(m.group(1))
        self.origin, note = _normalize_origin_salary(self.origin)

    def _origin_text(self):
        """原单位卡的气泡引导话术。带预填字段时复用回填轮话术（还差：…）。"""
        if self.post.get("org"):
            if self.post.get("org_code"):
                return "已校验「%s」组织权限。请先填写必填信息。" % self.post["org"]
            return "请填写必填信息。"
        if any(v not in (None, "") for v in self.origin.values()):
            return self._origin_backfill_text()
        return "请填写必填信息。"

    def _origin_card(self):
        """薪酬-原单位信息卡：平台模板 card_salary_origin（表单字段绑 vars 预填）。

        平台模板表单字段 default 取 vars（首次出卡全空，用户填过/文本粘贴
        过的字段再出卡时带入），提交经 event.form（confirm_origin，字段名
        走 _ALIAS 回内部键）。气泡话术由调用方经 _emit(card, bubble) 传入。
        """
        origin = self.origin
        months, _ = _months_value(origin.get("months"))
        return {
            "templateKey": "card_salary_origin",
            "params": {
                "companyName": str(origin.get("company") or ""),
                "jobName":     str(origin.get("post") or ""),
                "cityName":    str(origin.get("city") or ""),
                "basePay":     _dec(origin.get("base_pay")),
                "salaryMonth": months or 0,
                "lastBonus":   _dec(origin.get("last_bonus")),
                "lastLti":     _dec(origin.get("last_lti")),
                "footnote":    "",
                "requestId":   "",
                "sessionId":   "",
            },
        }

    def ocr(self, values):
        if self.step not in (None, "origin"):
            return _emit(None, "当前阶段不需要录入原单位信息，请按当前卡片操作。")
        self._update_origin_form(values, echo=False)
        # 缺项 → 重发预填卡让用户补填；齐全 → 直接 confirm_origin 出岗位卡（录齐即推进）
        return self._origin_after_backfill()

    def submit_origin(self, form=None):
        """「原单位情况」卡提交（event.form）→ 落字段 → **卡上点确认 = 确认**。

        必填齐全直接执行 confirm_origin()（同轮出岗位卡）；还缺项时推进不了，
        重发预填卡 +「还差：X」让用户补（与 ocr/parse_text 同一出口）。
        """
        if self.step not in (None, "origin"):
            return _emit(None, "当前阶段不需要提交原单位信息，请按当前卡片操作。")
        self._update_origin_form(form or {}, echo=True)
        return self._origin_after_backfill()

    def _update_origin_form(self, values, echo):
        known = {field[0] for field in ORIGIN_FIELDS} | {"bonus_ratio", "_total_package"}
        patch = {_ALIAS.get(k, k): v for k, v in values.items() if v not in (None, "")}
        if "base_pay" in patch:
            value = patch.pop("base_pay")
            basis = patch.get("base_pay_basis")
            unchanged = _money_num(value, None) == self.origin.get("base_pay")
            if basis or not (echo and unchanged):
                if basis in ("月薪", "月", "monthly"):
                    basis = "monthly"
                elif "baseSalary" in values and not basis:
                    basis = "auto"
                else:
                    basis = "yearly"
                _set_pay(self.origin, value, basis)
        self.origin.update({k: v for k, v in patch.items() if k in known})
        _normalize_origin_salary(self.origin)

    def _origin_after_backfill(self):
        """回填轮（ocr/parse_text）的统一出口：按必填状态决定发不发卡。

        还有缺项 → 重发预填卡（用户照卡补填）+「还差：X、Y」；
        已齐全 → **直接 confirm_origin() 同轮出岗位卡**——录齐即推进，没有
        「请回复『确认』」的二次确认轮（卡片确认按钮、文字「确认」都不再需要）。
        """
        if self._missing_origin():
            return _emit(self._origin_card(), self._origin_backfill_text())
        return self.confirm_origin()

    def _origin_backfill_text(self):
        """回填/预填轮的气泡：按必填状态回话。

        缺 → 「还差：X、Y」（与 confirm_origin 同一清单）；
        齐 → 录入回显（仅 start 首出卡预填齐全时用，卡上点确认即推进，不再
        引导回复「确认」）。不带任何金额（bubble 禁金额口径）。
        """
        miss = self._missing_origin()
        if miss:
            return "还差：" + "、".join(miss)
        months = self.origin.get("months") or "13薪"
        return "已录入您的原单位薪资信息（%s）。" % months

    # ---------------- 文字拷贝 ----------------
    ORIGIN_PATTERNS = {
        # 字段值不含分隔符（、，,；;）——「公司名：AAA、岗位：…」不能把后面字段吞进值里
        "company": r"(?:公司名|原公司|公司)\s*(?:（[^）]*）)?\s*[:：]?\s*([^\s，,、；;]+)",
        "post": r"(?:岗位|职位)\s*(?:（[^）]*）)?\s*[:：]?\s*([^\s，,、；;]+)",
        "city": r"(?:城市|驻地)\s*(?:（[^）]*）)?\s*[:：]?\s*([^\s，,、；;]+)",
        # 标签后允许带单位括号（卡面标签「固薪（元/年）」「上年奖金（元）」，用户照卡
        # 打字必带括号）：(?:（[^）]*）)? 吸收后再吃冒号取数
        "base_pay": r"(?:固薪|固定收入|固定薪酬)\s*(?:（[^）]*）)?\s*[:：]?\s*([\d,\.]+(?:\s*万)?)",
        # 「月薪 2 万」：明确是月薪形态，后续按薪数换算年固薪
        "monthly_pay": r"月薪\s*(?:（[^）]*）)?\s*[:：]?\s*([\d,\.]+(?:\s*万)?)",
        "last_bonus": r"(?:上年奖金|上年年化奖金)\s*(?:（[^）]*）)?\s*[:：]?\s*([\d,\.]+(?:\s*万)?)",
        "last_lti": r"(?:上年长期激励|长期激励)\s*(?:（[^）]*）)?\s*[:：]?\s*([\d,\.]+(?:\s*万)?)",
        # 「薪酬月数：13」「薪数：13薪」——卡面标签写法（此前只认「N薪」，标签式输入必丢）
        "months": r"(?:薪酬月数|薪数|月数)\s*(?:（[^）]*）)?\s*[:：]?\s*(\d+)\s*薪?",
        "bonus_ratio": r"(?:奖金占比|占比)\s*(?:（[^）]*）)?\s*[:：]?\s*(\d+%|0?\.\d+)",
    }
    POST_PATTERNS = {
        # 卡面标签是「入职部门」，用户照卡打字必带它；「组织」是口语叫法
        "org": r"(?:入职部门|组织|部门)\s*(?:（[^）]*）)?\s*[:：]?\s*([^\s，,；;]+)",
        "post": r"(?:入职岗位|岗位)\s*(?:（[^）]*）)?\s*[:：]?\s*([^\s，,；;]+)",
        "city": r"(?:工作地点|城市|base)\s*(?:（[^）]*）)?\s*[:：]?\s*([^\s，,；;]+)",
        "seq": r"序列\s*(?:（[^）]*）)?\s*[:：]?\s*([MPT])",
        # 卡面标签是「GGS等级」，值前还有「等级」两个字：(?:等级)? 吸收
        "ggs": r"GGS\s*(?:等级)?\s*[:：]?\s*(\d+)",
        "new_fixed": r"(?:拟定固薪|offer)\s*(?:（[^）]*）)?\s*[:：]?\s*([\d,\.]+(?:\s*万)?)",
    }

    @staticmethod
    def _money(v):
        v = str(v).replace(",", "").strip()
        if v.endswith("万"):
            return str(int(float(v[:-1]) * 10000))
        return v

    @staticmethod
    def _ratio(v):
        v = str(v).strip()
        if v.endswith("%"):
            return str(float(v[:-1]) / 100)
        return v

    def _parse_json_origin(self, text):
        """候选人薪资 JSON（baseSalary/totalPackage/payMonth 等）→ origin 字段。

        支持标准 JSON 与混合文本里的 "key": value / key=value 片段；
        字符串值（公司名/岗位/城市）也能取。
        返回 dict（空 = 没有可识别字段）。
        """
        raw = str(text).strip()
        data = None
        if raw.startswith("{"):
            try:
                data = json.loads(raw)
            except Exception:
                data = None
        if data is None:
            # 宽松提取：字符串与数字值都抠（中文值不含引号也能取到行尾/逗号前）
            data = {}
            for k in ("baseSalary", "basePay", "totalPackage",
                      "payMonth", "salaryMonth", "salaryMonths",
                      "lastBonus", "lastLti", "companyName", "jobName",
                      "cityType", "base_pay_basis"):
                m = re.search(r'"?%s"?\s*[:=]\s*"([^"]*)"|"?%s"?\s*[:=]\s*([\d,\.\s万]+)'
                              % (k, k), raw)
                if m:
                    data[k] = (m.group(1) if m.group(1) is not None
                               else m.group(2)).strip().rstrip('"')
        if not data:
            return {}
        out = {}
        for k, v in data.items():
            field = _ALIAS.get(k, _ALIAS.get(str(k).lower(), k))
            if field in ("base_pay", "last_bonus", "last_lti", "_total_package"):
                try:
                    v = self._money(v)
                except Exception:
                    pass
                out[field] = _num(v, 0)
                if k in ("basePay", "baseSalaryYear"):
                    out.setdefault("base_pay_basis", "yearly")
            elif field == "months":
                months, mlabel = _months_value(v)
                if months is not None:
                    out[field] = mlabel
            elif field == "base_pay_basis":
                # 数据形态标记：仅「月薪」有换算意义，其余按元/年直接用
                out[field] = "monthly" if "月" in str(v) or v == "monthly" else "yearly"
            elif field in ("company", "post", "city"):
                out[field] = v
        return out

    def parse_text(self, text):
        """从一段文字中抽取字段（文字拷贝 / JSON 粘贴）。"""
        text = str(text)
        if self.step == "done":
            return _emit(None, "方案已出，如需调整请直接说涨幅或名单。")
        if self.step is not None and self.step not in ("origin", "post", "extra"):
            return _emit(None, "当前阶段不能录入这些信息，请按当前卡片操作。")
        if self.step is None:
            self.step = "origin"

        if self.step == "origin":
            # JSON 粘贴与标签式解析统一走 _apply_origin_text（与 start(text=…) 共用）
            self._apply_origin_text(text)
            # 缺项 → 重发预填卡；齐全 → 直接 confirm_origin 出岗位卡（录齐即推进）
            return self._origin_after_backfill()

        if self.step == "post":
            self._pending_org = None
            # 文字改了组织：旧解析结果作废（org_code/org_path 是 confirm_extra 圈组织的依据）
            if re.search(r"(?:入职部门|组织|部门)\s*[:：]", text):
                for stale in ("org_code", "org_path", "org_path_input"):
                    self.post.pop(stale, None)
            for k, pat in self.POST_PATTERNS.items():
                m = re.search(pat, text)
                if not m:
                    continue
                self.post[k] = self._money(m.group(1)) if k == "new_fixed" else m.group(1)
            # 录齐即推进：必填齐全直接 confirm_post()（组织解析/权限闸同轮走完，
            # 出补充卡），不再重发同一张岗位卡让用户再点一次提交；
            # 还缺项 → 重发预填卡 +「还差：X」（与原单位回填轮同一出口形态）
            miss = [label for key, label, _, required in POST_FIELDS
                    if required and not str(self.post.get(key, "") or "").strip()]
            if miss:
                return _emit(self._post_card(), "还差：" + "、".join(miss))
            return self.confirm_post()

        for k, pat in {
            "cash_allowance": r"(?:现金补贴|补贴)\s*[:：]?\s*([\d,\.]+(?:\s*万)?)",
            "cash_note": r"(?:补贴说明)\s*[:：]?\s*([^\s，,；;]+)",
            "social": r"(?:社保)\s*[:：]?\s*([^\s，,；;]+)",
            "fund": r"(?:公积金)\s*[:：]?\s*([^\s，,；;]+)",
            "lti_note": r"(?:长期激励说明)\s*[:：]?\s*([^\s，,；;]+)",
            "special": r"(?:特殊约定)\s*[:：]?\s*([^\n]+)",
        }.items():
            m = re.search(pat, text)
            if m:
                self.extra[k] = m.group(1)
        # 录齐即推进：补充信息全部选填，任何文字回填都算「确认补充信息」，
        # 同轮 confirm_extra() 圈人出名单卡，不再重发同一张补充卡
        return self.confirm_extra()

    def submit_post(self, form=None):
        """「入职岗位信息」卡提交（event.form）→ 落字段（键名走 _ALIAS）→ confirm_post。

        与 parse_text（文字解析，正则兜底）分开：平台能回传结构化表单时
        优先走这里按字段取值，不从卡片文案里提取；只收认得的键（_ALIAS
        映射到 POST_FIELDS 的），未知键忽略不写进数据；字段缺失时
        confirm_post 自己会回「还差：X」，不会把已填的项弄丢。
        """
        if self.step not in (None, "post"):
            return _emit(None, "当前阶段不需要提交岗位信息，请按当前卡片操作。")
        known = {key for key, _, _, _ in POST_FIELDS}
        form = form or {}
        if any(_ALIAS.get(k, k) == "org" for k in form):
            # 卡片带了组织（含改组织重交）：旧解析结果作废
            for stale in ("org_code", "org_path", "org_path_input"):
                self.post.pop(stale, None)
        for k, v in form.items():
            key = _ALIAS.get(k, k)
            if key not in known:
                continue
            if key == "ggs" and v not in (None, ""):
                try:
                    v = parse_grade(v)
                except ValueError as error:
                    return _emit(None, str(error))
            if v not in (None, ""):
                self.post[key] = v
        return self.confirm_post()

    def say_edit(self, field, value):
        raw_field = str(field or "")
        if raw_field in ("姓名", "候选人姓名", "name"):
            if self.step in ("roster", "done"):
                return _emit(None, "名单/方案已生成，姓名需重新发起定薪修改。")
            self.name = str(value or "").strip()
            return _emit(None, "改好了。")
        field = _ALIAS.get(raw_field, raw_field)
        if field not in _EDIT_FIELDS and field not in ("月薪", "年薪"):
            return _emit(None, "卡片不存在此字段。")
        if self.step == "done" and field != "months":
            return _emit(None, "方案已出，信息不能再改；如需调整请重新发起定薪。")
        if self.step == "roster":
            extra_fields = {key for key, _, _ in EXTRA_FIELDS}
            if field not in extra_fields and field != "months":
                return _emit(None, "名单已生成，岗位/原单位信息需重新发起定薪。")
        if field == "org":
            self._pending_org = None
            # 组织变了：清掉旧解析结果（org_code/org_path），否则 confirm_extra 拿旧编码圈错组织
            for stale in ("org_code", "org_path", "org_path_input"):
                self.post.pop(stale, None)
        if field == "months":
            months, mlabel = _months_value(value)
            if months is None:
                return _emit(None, "薪数没看懂，请直接给数字（如 12薪、13薪、16薪）。")
            # origin 步：改的是原单位薪数（若固薪按月薪换算，按新薪数重算年固薪）
            if self.step == "origin":
                self.origin["months"] = mlabel
                target, note = _normalize_origin_salary(self.origin)
                self.origin = target
                note = [re.sub(r"\d+(?:\.\d+)?元", "", n).strip("，。 ") for n in note]
                note = [n for n in note if n]
                return _emit(None, "改好了。" + ("（%s）" % "；".join(note) if note else ""))
            # post/extra/done 步：「拟定XX薪」——记录拟定月数，done 态直接重出方案；
            # 低于 12 的指定不接受（拟定默认 13薪）
            if months < MONTHS_MIN:
                return _emit(None, "拟定薪数需至少为 12（当前 %d），未生效，拟定默认 13 薪。" % months)
            self.user_months = months
            if self.step == "done":
                return self.build_plan()   # 方案已出：按新薪数重出（涨幅保持）
            return _emit(None, "已记录拟定 %s，方案将按 %d 薪计算。" % (mlabel, months))
        if field in ("base_pay_basis", "固薪口径", "薪资口径", "月薪", "年薪"):
            s = str(value)
            # 「月薪X / 年薪X」形态：X 是金额，口径由字段决定
            m = re.search(r"([\d,\.]+(?:\s*万)?)", s)
            if not m:
                return _emit(None, "没看懂，请直接给数字（固薪按元/年）。")
            yearly = (field == "年薪") or ("年" in s and "月" not in s)
            _set_pay(self.origin, m.group(1), "yearly" if yearly else "monthly")
            _normalize_origin_salary(self.origin)
            return _emit(None, "改好了。")
        if field == "base_pay":
            _set_pay(self.origin, value, "yearly")
            _normalize_origin_salary(self.origin)
            return _emit(None, "改好了。")

        origin_fields = {"company", "base_pay", "last_bonus", "last_lti",
                         "bonus_ratio", "_total_package"}
        post_fields = {"org", "seq", "ggs", "new_fixed"}
        extra_fields = {key for key, _, _ in EXTRA_FIELDS}
        if field in origin_fields:
            target = self.origin
        elif field in post_fields:
            target = self.post
        elif field in extra_fields:
            target = self.extra
        else:
            # post / city 同时存在于原单位与入职岗位：按当前阶段选择目标
            target = self.origin if self.step == "origin" else self.post

        if field == "cash_allowance":
            value = _num(self._money(value))
        elif field in ("last_bonus", "last_lti"):
            value = _money_num(value)
        elif field == "ggs":
            try:
                value = parse_grade(value)
            except (TypeError, ValueError):
                return _emit(None, "GGS 没看懂，请直接给数字（1-30）。")
        target[field] = value
        if field == "_total_package":
            # 总包进来后回推口径/薪数
            target, note = _normalize_origin_salary(target)
            return _emit(None, "改好了。" + ("（%s）" % "；".join(note) if note else ""))
        return _emit(None, "改好了。")

    def add_subsidy(self, name, amount, note=""):
        """已废弃：补贴明细机制已移除，补贴只在「现金补贴（元/年）」字段体现。

        保留空实现是为了兼容旧调用不报错；统一并入 cash_allowance。
        """
        try:
            cur = _num(self.extra.get("cash_allowance"), 0)
            self.extra["cash_allowance"] = round(cur + _num(amount, 0), 2)
            if note and not self.extra.get("cash_note"):
                self.extra["cash_note"] = str(note)
        except Exception:
            pass
        return _emit(None, "补贴已并入现金补贴。")

    def _missing_origin(self):
        _normalize_origin_salary(self.origin)
        miss = []
        for key, label, _, required in ORIGIN_FIELDS:
            if not required:
                continue
            v = self.origin.get("_base_input") if key == "base_pay" else self.origin.get(key)
            # 0 是合法值（如无长期激励），只有 None/空串/缺字段算没填
            if v is None or (isinstance(v, str) and not v.strip()):
                miss.append(label)
        return miss

    def confirm_origin(self):
        if self.step not in (None, "origin"):
            return _emit(None, "当前阶段不需要确认原单位信息，请按当前卡片操作。")
        # 姓名必填闸后移到这里：岗位卡 subtitle 和方案都要姓名，原单位卡不需要
        if not str(self.name or "").strip():
            return _emit(None, NAME_REQUIRED_TEXT)
        miss = self._missing_origin()
        if miss:
            return _emit(None, "还差：" + "、".join(miss))
        _normalize_origin_salary(self.origin)
        if _num(self.origin.get("base_pay")) <= 0:
            return _emit(None, "请填写原单位固薪（元/年，需大于 0）。")
        # 录入前做最后一次归一化（月薪→年薪、任意薪数原样保留）；气泡不带金额（口径约束）
        self.origin, note = _normalize_origin_salary(self.origin)
        # 薪酬月数：必填且必须是可解析的正整数；≥12（卡片提交/文字回填/文字确认全路径经此闸）
        months_v, _mlabel = _months_value(self.origin.get("months"))
        if not self.origin.get("months") or months_v is None:
            return _emit(None, "还差：薪酬月数，请回复薪酬月数具体数字（12 及以上）。")
        if months_v < MONTHS_MIN:
            return _emit(None, MONTHS_MIN_TEXT % months_v)
        echo = ("已录入您的原单位薪资信息（%s）。"
                % (self.origin.get("months") or "13薪"))
        if note:
            # 去掉金额数字，只留口径说明
            note = [re.sub(r"\d{4,}", "", n).strip("，。 ") for n in note]
            note = [n for n in note if n]
            echo += "（%s）" % "；".join(note)
        self.step = "post"
        return _emit(self._post_card(), echo + "请填写入职岗位信息。")

    # ---------------- 入职岗位 ----------------
    def _post_card(self):
        """薪酬-入职岗位信息卡：平台模板 card_salary_post（表单字段绑 vars 预填）。

        org/job/city/seq 四个 string + ggs integer（平台卡上自带 1-30 步进），
        default 取 vars（首次出卡全空，已给组织等已知值再出卡时预填回显）；
        subtitle 进 header。GGS 区间校验（1-30）在 confirm_post 仍兜底。
        """
        return {
            "templateKey": "card_salary_post",
            "params": {
                "org":       str(self.post.get("org") or ""),
                "job":       str(self.post.get("post") or ""),
                "city":      str(self.post.get("city") or ""),
                "seq":       str(self.post.get("seq") or ""),
                "ggs":       int(_num(self.post.get("ggs"), 0)),
                "subtitle":  "候选人%s" % self.name,
                "footnote":  "",
                "requestId": "",
                "sessionId": "",
            },
        }

    def confirm_post(self):
        if self.step not in (None, "post"):
            return _emit(None, "当前阶段不需要确认岗位信息，请按当前卡片操作。")
        # 同一次对话内复用 4A 结果；新对话由 start() 重新拉取
        # 必填缺失不代填默认值，直接提醒用户补齐
        miss = [label for key, label, _, required in POST_FIELDS
                if required and not str(self.post.get(key, "") or "").strip()]
        if miss:
            return _emit(None, "还差：" + "、".join(miss))

        # GGS 区间校验（1-30）
        try:
            ggs_v = parse_grade(self.post.get("ggs"))
        except (TypeError, ValueError):
            return _emit(None, "请核对GGS是否填写正确。")
        if not (GGS_MIN <= ggs_v <= GGS_MAX):
            return _emit(None, "GGS 需在 %d-%d 之间，请修改后重新确认。" % (GGS_MIN, GGS_MAX))

        # 上一轮提示"疑似"，这次用户确认了
        if self._pending_org:
            self.post["org"] = self._pending_org["match"]
            self._pending_org = None
            self.step = "extra"
            return _emit(self._extra_card())

        org = str(self.post.get("org", "")).strip()
        # 组织匹配统一走 resolve_org（支持完整路径：末级名先筛 + 倒数第二级父名收窄，
        # 同名多命中交用户消歧/权限过滤，与 confirm_extra 同一口径）。
        # 旧平面名单 _known_orgs 不吃父路径——真实事故：全路径输入仍提示「匹配到多个组织」。
        if hasattr(self.sap, "resolve_org") and org:
            matches = self.sap.resolve_org(org)
            # 消歧前先按操作人权限过滤：无权限组织不出现在提示里
            if len(matches) > 1 and self.auth:
                matches, filter_err = roster_mod.filter_org_matches(self.sap, self.auth, matches)
                if filter_err:
                    return _emit(None, "组织权限校验暂时不可用，请稍后重试。")
                if not matches:
                    self.step = "perm_denied"
                    return _emit(None, PERM_DENIED_TEXT_ORG % org)
            if len(matches) == 1:
                self.post["org"] = str(matches[0].get("cOrgName") or org)
                self.post["org_code"] = str(matches[0].get("cOrgCode") or "")
                self.post.pop("org_path_input", None)
                self._pending_org = None
                self.step = "extra"
                return _emit(self._extra_card())
            if len(matches) > 1:
                return _emit(None, self.sap._resolve_ambiguous(matches))
            # resolve_org 没找到：不硬猜，与 confirm_extra 同一话术
            return _emit(None, "没找到组织「%s」，请确认名称"
                                "（可用完整路径如「OLED中台/印刷OLED中心」）。" % org)
        # 适配层没有 resolve_org（极老版本兜底）：全路径取末级后按平面名单匹配
        if "/" in org:
            self.post["org_path_input"] = org
            tail = [x.strip() for x in org.split("/") if x.strip()][-1]
            if tail:
                org = tail
                self.post["org"] = tail
        known = self._known_orgs()
        if not known or org in known:
            self.post["org"] = org
            self.step = "extra"
            return _emit(self._extra_card())

        matched = self._match_suspected(org, known)
        if matched:
            self._pending_org = {"input": org, "match": matched}
            return _emit(None, "组织「%s」疑似「%s」，确认使用吗？回复「确认」使用，或「不是」重新输入。"
                            % (org, matched))
        return _emit(None, "组织「%s」未匹配到系统组织，请确认或重新输入。" % org)

    def reject_org(self):
        """疑似匹配时，用户选择"不是"。"""
        self._pending_org = None
        return _emit(None, "请重新输入组织名称。")

    def _known_orgs(self):
        orgs = set()
        try:
            for p in self.sap.all_people():
                for key in ("l2", "l3", "l4", "l5", "l6"):
                    if p.get(key):
                        orgs.add(p[key])
        except Exception:
            pass
        return sorted(orgs)

    @staticmethod
    def _match_suspected(org, known):
        import difflib
        if not org or not known:
            return None
        for k in known:
            if org in k or k in org:
                return k
        best = difflib.get_close_matches(org, known, n=1, cutoff=0.6)
        return best[0] if best else None

    # ---------------- 补充（选填） ----------------
    def _extra_card(self):
        """薪酬-补充信息卡：平台模板 card_salary_extra（表单字段绑 vars 预填）。

        五个选填字段 default 取 vars（首次出卡全空，填过的再出卡时预填回显）；
        special（特殊约定）平台卡没有，仅留在 self.extra；subtitle 进 header。
        """
        e = self.extra
        return {
            "templateKey": "card_salary_extra",
            "params": {
                "cashSubsidy": _dec(e.get("cash_allowance")),
                "cashMemo":    str(e.get("cash_note") or ""),
                "socialMemo":  str(e.get("social") or ""),
                "fundMemo":    str(e.get("fund") or ""),
                "ltiMemo":     str(e.get("lti_note") or ""),
                "subtitle":    "候选人%s（选填）" % self.name,
                "footnote":    "",
                "requestId":   "",
                "sessionId":   "",
            },
        }

    def confirm_extra(self, form=None):
        # 补充信息全部选填：卡片表单（含全空）提交即确认，先把卡上字段落库再圈人。
        # 兼容平台把 event.form 以关键字传入；done 阶段不再允许回退到补充环节。
        if self.step not in (None, "extra"):
            return _emit(None, "当前阶段不需要提交补充信息，请按当前卡片操作。")
        extra_keys = {key for key, _, _ in EXTRA_FIELDS}
        for k, v in (form or {}).items():
            key = _ALIAS.get(k, k)
            if key not in extra_keys:
                continue
            if key == "cash_allowance" and v not in (None, ""):
                v = _num(self._money(v))
            self.extra[key] = "" if v is None else v
        # 同一次对话内复用 4A 结果；新对话由 start() 重新拉取
        ggs = int(self.post.get("ggs") or 0)
        seq = self.post.get("seq", "")
        org_input = str(self.post.get("org") or "")
        org_code = str(self.post.get("org_code") or "")
        org_note = ""
        if not org_code and hasattr(self.sap, "resolve_org"):
            # 支持完整路径输入；按最后一级名查，同名时用父路径收窄
            matches = self.sap.resolve_org(org_input)
            # 消歧前先按操作人权限过滤：无权限组织不出现在提示里
            # （全部被滤掉=目标组织不在权限内，直接给权限口径；过滤接口异常则原样交权限闸兜底）
            if len(matches) > 1 and self.auth:
                matches, filter_err = roster_mod.filter_org_matches(self.sap, self.auth, matches)
                if filter_err:
                    return _emit(None, "组织权限校验暂时不可用，请稍后重试。")
                if not matches:
                    self.step = "perm_denied"
                    return _emit(None, PERM_DENIED_TEXT_ORG % org_input)
            if len(matches) == 1:
                org_code = str(matches[0].get("cOrgCode", ""))
            elif len(matches) > 1:
                org_note = self.sap._resolve_ambiguous(matches)
            else:
                org_note = ("没找到组织「%s」，请确认名称"
                            "（可用完整路径如「OLED中台/印刷OLED中心」）。" % org_input)
        l2 = org_input
        l3 = ""
        org_path = org_input
        if org_code and hasattr(self.sap, "org_l2_l3"):
            l2_from_org, l3_from_org = self.sap.org_l2_l3(org_code)
            l2 = l2_from_org or l2
            l3 = l3_from_org or ""
        if org_code and hasattr(self.sap, "org_path"):
            org_path = self.sap.org_path(org_code) or org_path
        self.post["org_path"] = org_path

        # 组织没解析出来时不硬圈：提示用户补组织信息，也不再用名称假放行
        if not org_code:
            self.step = self.step or "extra"
            if org_note:
                return _emit(None, org_note)
            return _emit(None, "没找到组织「%s」，请确认名称"
                                "（可用完整路径如「OLED中台/印刷OLED中心」）。" % org_input)

        self.post["org_code"] = org_code
        # 补充信息确认后，再按实际入职组织校验 BP / BP HEAD 权限
        # （真鉴权：祖先链 + 接口1 orgCodes，与调薪共用 roster.org_perm_gate）
        if hasattr(self.auth, "check_orgs"):
            gate = roster_mod.org_perm_gate(self.sap, self.auth, org_code)
            if not gate["allowed"]:
                self.step = "perm_denied"
                return _emit(None, gate.get("reason") or "你没有该组织的薪酬权限。")
        else:
            perm = self.auth.check_org(org_path or org_input)
            if not perm["allowed"]:
                self.step = "perm_denied"
                return _emit(None, perm.get("reason") or "你没有该组织的薪酬权限。")

        # 定薪：把"入职岗位（组织/序列/GGS）"当作调薪后的信息，与调薪共用同一套圈人逻辑
        # L2-L6 编码与调薪 confirm_info 同口径：同级池按 l3_code/l2_code 匹配防同名串池
        target = {"emp_id": "", "name": self.name,
                  "l2": l2, "l3": l3, "seq": seq, "ggs": ggs,
                  "org_code": org_code, "org_path": org_path}
        if org_code:
            if hasattr(self.sap, "org_codes_at_level"):
                for i in range(2, 7):
                    c = self.sap.org_codes_at_level(org_code, "L%d" % i)
                    if c:
                        target["l%d_code" % i] = c
            if hasattr(self.sap, "org_path"):
                target["org_path"] = self.sap.org_path(org_code) or org_path
        self.sections = roster_mod.build_roster(
            target, ggs, seq, self.sap, self.auth,
            initiator_name=self.initiator_name)
        # 圈人后停 roster 步骤、出名单卡（与调薪同款）：用户可增删/筛选，
        # 「确认名单」才进方案（confirm_roster → build_plan）
        self.step = "roster"
        self.roster_locked = False
        return _emit(self._roster_card())

    def submit_extra(self, form=None):
        """「补充信息」卡提交事件：落补充字段 → 同轮 confirm_extra 圈人。"""
        return self.confirm_extra(form=form)

    # ---------------- 名单 ----------------
    def _roster_card(self):
        """定薪名单卡：与调薪同款（card_salary_roster，平台示例 16 键格式）。

        出名单这一趟里完成 _recheck（权限校准）与 _ensure_salary（补 GGS），
        保证卡片上的职级不是空的。人员项四键 {ggs, code, name, removed}，
        ggs 字符串化；上级无权限说明汇总进 headnote。
        """
        self._recheck()
        self._ensure_salary()

        by_key = {s["key"]: s for s in self.sections}
        s_up = by_key.get("upper")
        s_peer = by_key.get("peer")
        s_down = by_key.get("reportee")

        def rows_of(key):
            s = by_key.get(key)
            return [card_person(p) for p in (s["people"] if s else [])]

        # 上级保留（含无权限注记）；同级/下级也保留已移除行（removed 标记），
        # 由平台卡面渲染删除态，用户可再次勾选恢复。
        up_rows = rows_of("upper")
        peer_rows = rows_of("peer")
        down_rows = rows_of("reportee")

        # 卡顶说明：上级无权限/未核实 + 空节说明（如“直接上级岗位为空”）
        up_notes = [p.get("note") for p in (s_up["people"] if s_up else [])
                    if p.get("note")]
        section_notes = [s.get("note") for s in (s_up, s_peer, s_down)
                         if s and s.get("note") and not s["people"]]
        head_notes = list(dict.fromkeys(section_notes + up_notes))
        up_note = "；".join(head_notes) if head_notes else ""

        return {
            "templateKey": "card_salary_roster",
            "params": {
                "title":     "定薪名单确认",
                "up":        up_rows,
                "peer":      peer_rows,
                "down":      down_rows,
                "more":      [],
                "moreCount": "",
                "headnote":  up_note,
                "upTitle":   "上级名单",
                "peerTitle": "同级名单",
                "downTitle": "下级名单",
                "upRule":    (s_up["rule"] if s_up else ""),
                "peerRule":  (s_peer["rule"] if s_peer else ""),
                "downRule":  (s_down["rule"] if s_down else ""),
                "footnote":  "",
                "requestId": "",
                "sessionId": "",
            },
        }

    def adjust(self, action, emp_id, section=None):
        """名单加人/删人（与调薪同款）。roster 可改；done（方案已出）也可再调，
        改完直接重出方案（涨幅保持用户此前指定值，见 build_plan 的 user_ratio）。
        done 态保持 roster_locked=True（名单是确认过的，build_plan 才肯重算）。
        section：加人时指定分区（upper/peer/reportee，默认 peer 同级）；
        删人按工号/姓名全区搜，不分区。"""
        if self.step not in ("roster", "done"):
            return _emit(None, "名单已锁定，不能再改。")
        sec, p = self._find(emp_id)
        if not p:
            if action != "add":
                return _emit(None, "名单里没找到这个人。")
            raw = self.sap.fetch_person(emp_id)
            if not raw:
                return _emit(None, "工号 %s 查无此人。" % emp_id)
            if not self.auth.check_permission(raw)["allowed"]:
                return _emit(None, "%s 不在你的权限范围内，无法加入。" % raw["name"])
            sec_key = section if section in ("upper", "peer", "reportee") else "peer"
            target = next((s for s in self.sections if s["key"] == sec_key), None)
            if target is None:
                target = {"key": sec_key, "label": {"upper": "上级", "peer": "同级",
                                                    "reportee": "下级"}[sec_key],
                          "rule": "", "count": 0, "note": "", "people": []}
                self.sections.append(target)
            target["people"].append({
                "name": raw["name"], "emp_id": raw["emp_id"],
                "org": roster_mod.org_name(raw), "ggs": raw["ggs"], "seq": raw["seq"],
                "visible": True, "removed": False, "added": True, "note": "", "_raw": raw})
            self.audit.append(("add", raw["emp_id"]))
            if self.step == "done":
                # 方案已出：改完名单直接重出方案（不回名单卡；保持 roster_locked）
                return self.build_plan()
            self.roster_locked = False
            # 回执 + 重弹最新名单卡（卡上状态与服务端一致）
            return _emit(self._roster_card(),
                         "已加入 %s（%s）。" % (raw["name"], raw["emp_id"]))
        if action == "add" and not self.auth.check_permission(p["_raw"])["allowed"]:
            return _emit(None, "%s 不在你的权限范围内，无法加入。" % p["name"])
        p["removed"] = (action == "remove")
        p["added"] = (action == "add")
        self.audit.append((action, p["emp_id"]))
        if self.step == "done":
            return self.build_plan()
        self.roster_locked = False
        if action == "add":
            return _emit(self._roster_card(),
                         "已加入 %s（%s）。" % (p["name"], p["emp_id"]))
        return _emit(self._roster_card(),
                     "已移除 %s（%s）。" % (p["name"], p["emp_id"]))

    def submit_roster(self, form=None):
        """「定薪名单确认」卡提交（event.form）→ 应用卡上增删结果 → 同轮出方案。

        卡上点确认 = 确认，不二次确认（与调薪 submit_roster 同款）：
        - 已在名单的人：按卡上 removed 勾选态应用（勾了=移除）
        - 卡上新增行（名单里没有的 code）：过权限校验后加入同级区
        - 应用完直接 confirm_roster() 出方案；加的人查无/无权限时回原因停 roster
        """
        form = form or {}
        if self.step not in ("roster", "done"):
            return _emit(None, "请先圈定名单。")
        # ① 应用卡上勾选态（removed）
        for row in (form.get("up") or []) + (form.get("peer") or []) + (form.get("down") or []):
            if not isinstance(row, dict):
                continue
            code = str(row.get("code") or "").strip()
            if not code:
                continue
            sec, p = self._find(code)
            if p is not None:
                p["removed"] = bool(row.get("removed"))
                if p["removed"]:
                    self.audit.append(("card_remove", code))
            elif row.get("name") and not row.get("removed"):
                # 名单里没有的新增行：查人、过权限、加入同级区
                try:
                    raw = self.sap.fetch_person(code)
                except Exception:
                    raw = None
                if not raw:
                    return _emit(None, "工号 %s 查无此人，名单未确认。" % code)
                if not self.auth.check_permission(raw)["allowed"]:
                    return _emit(None, "%s 不在你的权限范围内，无法加入，名单未确认。" % raw["name"])
                peer = next((s for s in self.sections if s["key"] == "peer"), None)
                if peer is None:
                    peer = {"key": "peer", "label": "同级", "rule": "",
                            "count": 0, "people": []}
                    self.sections.append(peer)
                peer["people"].append({
                    "name": raw["name"], "emp_id": raw["emp_id"],
                    "org": roster_mod.org_name(raw), "ggs": raw["ggs"], "seq": raw["seq"],
                    "visible": True, "removed": False, "added": True, "note": "", "_raw": raw})
                self.audit.append(("card_add", code))
        # ② 应用完直接出方案（卡上确认 = 名单确认）
        return self.confirm_roster()

    def filter_roster(self, key, seq=None, name=None, org=None, nationality=None):
        """名单筛选（与调薪同款）；手动加的人不被筛掉。done 阶段也允许，改完直接重出方案。"""
        if self.step not in ("roster", "done"):
            return _emit(None, "名单已锁定，不能再改。")
        was_done = (self.step == "done")
        # 国籍只来自薪酬台账（接口3，代码值 CN/HK/KR/TW/US…）：force 查台账——
        # 4A 自带固薪后「全员有固薪则跳过」短路恒真，不 force 国籍永远拿不到。
        nat_codes = None
        if nationality:
            self._recheck()
            self._ensure_salary(force=True)
            nat_codes = _nationality_codes(nationality)
            if not nat_codes:
                return _emit(None, "没识别这个国籍，请用工号或姓名指定要保留的人。")
        for s in self.sections:
            if s["key"] != key:
                continue
            kept = []
            for p in s["people"]:
                if p["added"]:
                    kept.append(p)
                    continue
                ok = True
                if seq and p["seq"] != seq:
                    ok = False
                if name and name not in p["name"]:
                    ok = False
                raw = p.get("_raw") or {}
                if org and not any(org in str(raw.get(k, "")) for k in ("l2", "l3", "l4")):
                    ok = False
                if nat_codes is not None and str(raw.get("nationality") or "") not in nat_codes:
                    ok = False   # 代码值精确匹配：CN/HK/KR/TW…
                if ok:
                    kept.append(p)
                else:
                    self.audit.append(("filter_out", p["emp_id"]))
            s["people"] = kept
            s["count"] = sum(1 for p in kept if not p["removed"])
        if was_done:
            # 方案已出：筛选完直接重出方案（不回名单卡；保持 roster_locked=True）
            return self.build_plan()
        self.roster_locked = False
        return _emit(self._roster_card())

    def confirm_roster(self):
        """确认名单 → 直接出方案（与调薪 confirm_roster 一致）。"""
        if self.step not in ("roster", "done"):
            return _emit(None, "请先确认名单。")
        self.roster_locked = True
        self.confirmed_at = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return self.build_plan()

    # ---------------- 方案 ----------------
    def _find(self, token):
        token = str(token)
        for s in self.sections:
            for p in s["people"]:
                if p["emp_id"] == token or p["name"] == token:
                    return s, p
        return None, None

    def build_plan(self, ratio=None, months=None):
        if not self.roster_locked:
            return _emit(None, "名单没确认，方案先不出。")
        self.bundle = None
        if hasattr(self.auth, "check_orgs"):
            if not self.post.get("org_code"):
                return _emit(None, "请重新确认入职组织后再出方案。")
            gate = roster_mod.org_perm_gate(self.sap, self.auth, self.post["org_code"])
        else:
            gate = self.auth.check_org(self.post.get("org_path") or self.post.get("org"))
        if not gate["allowed"]:
            return _emit(None, gate.get("reason") or "你没有该组织的薪酬权限。")
        self._recheck()
        self._ensure_salary()
        orig_fixed = _num(self.origin.get("base_pay"))
        try:
            orig_months = int(str(self.origin.get("months", "13")).replace("薪", "") or 13)
        except (TypeError, ValueError):
            orig_months = 13
        orig_bonus_del = _num(self.origin.get("last_bonus"))
        # 原奖金占比 = 上年奖金 /(固薪 + 上年奖金)；固薪缺失时按默认比例兜底，避免除零
        if orig_fixed > 0 and (orig_fixed + orig_bonus_del) > 0:
            orig_ratio = round(orig_bonus_del / (orig_fixed + orig_bonus_del), 4)
            orig_ratio = max(0.0, min(orig_ratio, 0.99))
        else:
            orig_ratio = 0.2
        new_ggs = int(self.post.get("ggs") or 0)
        new_city = self.post.get("city") or self.origin.get("city") or ""

        peer_rows = self._peer_rows()
        peer_avg = calc.average_rows(peer_rows)
        upper_p, upper_fixed = self._upper()
        reportee_rows = self._sample_rows("reportee")

        # 定薪：系统给建议涨幅，拟定固薪 = 原固薪 × (1 + 建议涨幅)（与调薪一致）
        rec = calc.recommend_ratio(
            cur_fixed=orig_fixed, new_ggs=new_ggs, city=new_city,
            peer_avg_fixed=peer_avg["fixed"] if peer_avg else None,
            upper_fixed=upper_fixed)
        # 涨幅优先级：本次显式指定 > 用户此前指定（改名单重出方案时保持） > 系统建议
        if ratio is not None:
            self.user_ratio = ratio
            use_ratio = ratio
        elif getattr(self, "user_ratio", None) is not None:
            use_ratio = self.user_ratio
        else:
            use_ratio = rec["suggest"]
        new_fixed = round(orig_fixed * (1 + use_ratio), 2)

        # 拟定薪数：本次显式指定（「拟定12薪」）> 用户此前指定 > 默认 13薪。
        # 岗位卡无月数字段、无月数入口；不沿用原单位薪数（原单位 16薪 默认也按 13薪
        # 拟定，除非用户显式说「拟定16薪」）。低于 12 的指定不接受（回默认 13）。
        if months is not None:
            self.user_months = months if months >= MONTHS_MIN else None
        new_months = getattr(self, "user_months", None) or 13

        def growth(a, b):
            return round((b - a) / a, 4) if a else None

        orig_bonus = round(orig_fixed * orig_ratio / (1 - orig_ratio), 2)
        new_ratio = standard_bonus_ratio(new_ggs)
        new_bonus = round(new_fixed * new_ratio / (1 - new_ratio), 2)
        peer_bonus = peer_avg["last_bonus"] if peer_avg else None
        peer_lti = peer_avg["last_lti"] if peer_avg else None
        orig_lti_del = _num(self.origin.get("last_lti"))

        new_org_path = self.post.get("org_path") or self.post.get("org", "")
        scheme = {
            "组织岗位职级": {
                "before": "%s\n%s\nbase %s" % (
                    self.origin.get("company", ""), self.origin.get("post", ""),
                    self.origin.get("city", "")),
                "after": "%s\n%s\n%s序列 GGS%d\nbase %s" % (
                    new_org_path, self.post.get("post", ""),
                    self.post.get("seq", ""), new_ggs, new_city),
                "growth": None, "peer": None, "note": "用户告知"},
            "固薪": {"before": orig_fixed, "after": new_fixed,
                     "growth": growth(orig_fixed, new_fixed), "peer": peer_avg["fixed"] if peer_avg else None,
                     "note": calc.competition_note(new_fixed, new_city, new_ggs)},
            "月薪": {"before": calc.monthly(orig_fixed, orig_months),
                     "after": calc.monthly(new_fixed, new_months),
                     "growth": growth(calc.monthly(orig_fixed, orig_months), calc.monthly(new_fixed, new_months)),
                     "peer": round((peer_avg["fixed"] / new_months), 2) if peer_avg else None,
                     "note": "拟定按 %d 薪；原单位月薪按 %d 薪折算" % (new_months, orig_months)},
            "13薪/12薪": {"before": "%d薪" % orig_months, "after": "%d薪" % new_months,
                          "growth": None, "peer": None,
                          "note": ("拟定 %d 薪（用户指定）" % new_months
                                   if getattr(self, "user_months", None)
                                   else "拟定默认13薪") + "；原单位口径原样记录"},
            "奖金基线": {"before": orig_bonus, "after": new_bonus,
                         "growth": growth(orig_bonus, new_bonus),
                         "peer": peer_avg["bonus_base"] if peer_avg else None,
                         "note": "占比 %d%%→%d%%" % (orig_ratio * 100, new_ratio * 100)},
            "奖金基线占比": {"before": orig_ratio, "after": new_ratio, "growth": None,
                             "peer": None, "note": "默认标准占比"},
            "上年实发奖金": {"before": orig_bonus_del, "after": peer_bonus, "growth": None,
                             "peer": None, "note": "拟定参考同层级平均"},
            "上年实发长期激励": {"before": orig_lti_del, "after": peer_lti, "growth": None,
                                 "peer": None, "note": "拟定参考同层级平均"},
            "固薪+奖金基线": {"before": round(orig_fixed + orig_bonus, 2),
                             "after": round(new_fixed + new_bonus, 2),
                             "growth": growth(orig_fixed + orig_bonus, new_fixed + new_bonus),
                             "peer": peer_avg["total_fixed_bonus"] if peer_avg else None, "note": "计算"},
            "固薪+实发奖金": {"before": round(orig_fixed + orig_bonus_del, 2),
                             "after": round(new_fixed + (peer_bonus or 0), 2),
                             "growth": growth(orig_fixed + orig_bonus_del, new_fixed + (peer_bonus or 0)),
                             "peer": None, "note": "拟定参考同层级平均"},
            "固薪+实发奖金+实发长期激励": {
                "before": round(orig_fixed + orig_bonus_del + orig_lti_del, 2),
                "after": round(new_fixed + (peer_bonus or 0) + (peer_lti or 0), 2),
                "growth": growth(orig_fixed + orig_bonus_del + orig_lti_del,
                                 new_fixed + (peer_bonus or 0) + (peer_lti or 0)),
                "peer": None, "note": "拟定参考同层级平均"},
        }

        ctx = {"ratio": use_ratio, "cur_fixed": orig_fixed, "new_fixed": new_fixed,
               "city": new_city, "new_ggs": new_ggs, "upper_fixed": upper_fixed,
               "peer_avg_fixed": peer_avg["fixed"] if peer_avg else None,
               "perf2": "", "perf1": "", "perf3": "", "nine_box": "",
               "competitiveness": calc.competitiveness(new_fixed, new_city, new_ggs)}
        checks = rules.run_checks(ctx)

        template = "GGS12 及以下" if new_ggs <= 12 else "通用"
        fname = "定薪方案_%s_%s.xlsx" % (self.name, _today())
        rec["source"] = "系统建议涨幅"

        self.bundle = {
            "kind": "hire",
            "target": {"name": self.name, "new_ggs": new_ggs, "new_fixed": new_fixed,
                       "city": new_city, "seq": self.post.get("seq", ""),
                       "post": self.post.get("post", ""), "org": self.post.get("org", ""),
                       "org_path": self.post.get("org_path") or self.post.get("org", "")},
            "origin": dict(self.origin), "post": dict(self.post), "extra": dict(self.extra),
            "peers": peer_rows, "peer_avg": peer_avg,
            "upper": calc.person_row(upper_p) if upper_fixed else upper_p,
            "upper_visible": bool(upper_p and upper_fixed and upper_fixed > 0),
            "reportees": reportee_rows,
            "reportee_avg": calc.average_rows(reportee_rows) if reportee_rows else None,
            "sections": self._public_sections(),
            "scheme": scheme, "checks": checks, "ratio": use_ratio,
            "recommendation": rec, "template": template, "filename": fname,
            "missing_salary": list(self._missing_salary),
            "sample_counts": self._sample_counts(),
            "audit": list(self.audit),
            "confirm": {"operator": self.operator, "at": self.confirmed_at},
        }
        self.step = "done"
        self.roster_locked = True   # 方案已出：名单锁回（done 后 adjust/filter 可再解锁）

        return {
            "bubble": rules.summary(checks),
            "card": None,
        }

    def export(self, path):
        if self.step != "done":
            return _emit(None, "方案还没生成，请先确认名单。")
        result = self.build_plan()
        if self.bundle is None:
            return result
        if export_mod is None:
            raise ImportError("openpyxl 不可用，无法生成 Excel")
        return export_mod.build_hire(self.bundle, path)

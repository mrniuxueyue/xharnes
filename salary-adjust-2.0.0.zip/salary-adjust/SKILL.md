---
name: salary-adjust
description: 为在职员工制作调薪方案。按工号或姓名查权限与台账，确认调薪后岗位及对标名单，计算涨幅并导出 Excel。适用于调薪、调整在职人员职级和重算已有调薪方案。
metadata:
  platform: 星Claw
  version: "2.0.0"
---

# 在职员工调薪

平台在一次业务会话内复用一个 `plan.Session`。新对象从 `start` 开始。用户要给拟入职候选人定薪时使用招聘定薪流程。构造参数与故障处理见 [平台集成](references/platform-integration.md)。

| 阶段 | 事件 | 调用与交付 |
|---|---|---|
| 开始 | 只说调薪 | 提示「请输入被调薪人的工号或姓名。」 |
| 开始或更换对象 | 给出工号或姓名 | `start(工号或姓名)`。同名按返回提示选工号。无权限或无台账时结束本次查询。 |
| 信息 | 文字改单项 | `say_edit(field, value)`，留在信息阶段。 |
| 信息 | 信息卡提交、文字确认、文字全量填写 | 分别用 `submit_info(form)`、`confirm_info()`、`submit_info(字段字典)`。校验通过即出名单卡。 |
| 名单 | 加人、删人、筛选 | `adjust("add"/"remove", 工号, section=...)` 或 `filter_roster(key, ...)`，呈现最新名单。各分区为 upper、peer、reportee。 |
| 名单 | 名单卡提交或文字确认 | `submit_roster(form)` 或 `confirm_roster()`，同轮计算方案。 |
| 方案 | 指定涨幅、改薪数、调名单 | 分别用 `build_plan(ratio=0.08)`（示例为 8%）、`say_edit("months", 薪数)`、已有名单方法。使用最新方案交付，保留此前明确指定的涨幅。 |
| 方案 | 导出 | `export(path)`，复核权限并重新生成文件。若返回故障气泡，按气泡处理。 |

表单事件优先按提交标识和当前阶段分流，将结构化字段完整传入。空的 after 字段和卡片整数 afterLevel=0 代表沿用现值。明确给出的职级须为 1–30 的整数。薪数沿用现值，可指定至少 12 薪。目标组织消歧以组织路径、权限和唯一编码为准。

每轮只呈现返回的 `bubble` 和卡片，纯卡片轮直接投递。金额在卡片和方案文件中呈现，聊天气泡只给操作结果或校验限制。按 [卡片投递协议](references/platform-integration.md) 调用平台，用户主动取消即结束该次投递。故障重试使用平台更新后的登录态，重新绑定对应会话的适配器，再重试失败步骤一次。权限拒绝结束本次操作。

薪酬口径、职级缺档、样本缺失及审批例外见 [业务规则](references/salary-logic.md)。部署前核对 [运行配置](references/runtime-injection.md)。

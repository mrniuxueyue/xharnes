# 运行配置

`adapters.build` 默认使用 production。仅在明确设置 `environment="test"` 或 `SALARY_ENV=test` 时启用内置测试服务地址和 HTTP。生产服务均须显式配置 HTTPS 地址。服务地址与凭据由部署方注入，环境变量或参数缺失会在首次网络请求前报告。

| 用途 | build 入参 | 环境变量或来源 |
|---|---|---|
| 环境 | environment | SALARY_ENV，默认 production |
| 当前登录人 | sso_token | 平台逐会话传入 |
| 操作人 | operator | 可选，操作留痕 |
| PMS 地址 | base_url | SALARY_BASE_URL |
| 4A 地址 | gateway | FOURA_BASE_URL |
| 4A 共享令牌 | foura_api_token | FOURA_API_TOKEN |
| 凭据服务地址 | sso_config_base_url | SSO_CONFIG_BASE_URL |
| 凭据服务令牌 | sso_config_token | SSO_CONFIG_TOKEN |
| 凭据服务租户 | sso_config_org_id | SSO_CONFIG_ORG_ID，默认 31 |
| 4A 租户 | — | FOURA_ORG_ID，默认 31 |
| PMS 凭据 | salary_cred | 平台可注入完整字典，否则从凭据服务获取 |

设置顺序为调用参数、对应环境变量、显式测试环境的默认地址。4A 和凭据服务各自读取本服务的令牌。完整 PMS 凭据含 appId、secret、aesKey、rsaPublic（兼容 rsaPublicKey）。提供完整凭据时无需配置凭据服务。生产服务地址须来自目标部署的实际配置。

PMS 用应用凭据换取访问令牌，薪酬查询携带当前用户的 SSO 登录态，对返回的加密信封先验签再解密。4A 负责组织和人员关系，鉴权头为 X-Api-Token。角色和发起人身份仅取平台可信上下文。每个用户会话单独构造适配器。

# 星Claw 平台集成

将本包 scripts 目录加入当前技能运行环境的 Python 模块搜索路径。安装本包 requirements.txt 后，在平台会话内创建适配器及业务会话。首次创建时按 [运行配置](runtime-injection.md) 注入对应环境的地址及凭据。

```python
import adapters

sap, auth, baseline = adapters.build(sso_token=sso_token, operator=operator)
session = SessionClass(operator=operator, sap=sap, auth=auth, baseline=baseline,
                       sso_token=sso_token, initiator_name=initiator_name)
```

在调薪包中导入 `from plan import Session as SessionClass`，在定薪包中导入 `from hire import HireSession as SessionClass`。按会话绑定实例，后续用户回复回到同一实例。组织圈选规则见 [4A 适配层](four-a-adapter.md)。

## 卡片投递

步骤返回 `{"bubble": ..., "card": ...}`。先呈现非空气泡，非空卡片交给 `card_delivery`。导出成功返回文件路径，失败时返回气泡对象，平台仅对成功的路径创建附件。若权限在导出前发生变化，以最新 bundle 的检查结果生成交付摘要（`rules.summary(session.bundle["checks"])`）。

当平台宿主可在 Python 内调用卡片 API，使用 `deliver(card, send)`。回调 `send(question=..., ext=...)` 将宿主回执映射为下列状态。通过模型工具投递时，使用 `question_args(card)` 获取参数，原样调用一次 `ask_question`，对回执采用同样的策略。一次投递仅使用其中一种方式。

| 回执 | 动作 |
|---|---|
| sent | 完成本轮，等待用户提交 |
| cancelled | 结束该次投递，保留会话 |
| transient_failure | 仅在平台明确表示临时失败且卡片未送达时，用相同参数再试一次 |
| failed 或送达状态未知 | 停止投递，返回简短系统繁忙提示 |

校验、标题和序列化由适配函数统一处理。ext 顶层只有 templateKey 和 params，params 是完整参数对象的 JSON 字符串。请求 ID 和会话 ID 由星Claw 绑定。卡片提交直接传结构化 form，名单卡提交即确认。用户取消不触发推进。

## 故障与权限

登录状态过期时提示重新进入会话。配置服务不可用时提示稍后重试或联系管理员。网络暂时不可用时提示系统繁忙。导出失败时返回文件生成失败提示。内部技术异常、令牌和薪酬金额不进入故障气泡。

权限拒绝立即结束相应操作。调薪按目标员工和目标组织校验，定薪按入职组织校验，名单按员工逐人校验。COE 的外部审批及授权操作由既有管理流程负责，两个 skill 的对话路由均不调用授权写接口。

# 4A 适配层（唯一真实模式）

`scripts/adapters/foura.py`：hr-4a-service 主数据（组织树 / 人员池 / 上下级）+ 薪酬接口合并。
对应 build 的 `data_source="4a"`（唯一真实模式——圈人一律走 4A，组织数据只有 4A 有）。
人员池由 4A 组织树自带，无需外部注入。

## 职责分工

| 数据 | 来源 | 说明 |
|---|---|---|
| 组织树 / 祖先链 / 下级 | hr-4a-service | `org_descendants` 从根全量拉取，0.2s 级 |
| 人员池 | hr-4a-service `peer-candidates`（兜底 `/persons` 翻页） | 带 sequence/jobLevelCode，排除 O/非在职 |
| 上级（组织管理者） | hr-4a-service `leader-candidates`（官方负责人候选，层级语义正确）优先；不可用时回退 `job_persons` 岗位链（charge 优先、parent 兜底） | 惰性解析，按需查人 |
| 固薪 / 奖金 / GGS / 序列 | 薪酬接口（`salary_client.list_salary`） | 合并时以薪酬字段为准（`ggs_source=salary`） |

## 环境变量

| 变量 | 默认 | 说明 |
|---|---|---|
| `FOURA_BASE_URL` | 生产显式 HTTPS，测试环境有测试默认 | 部署版 hr-4a-service 直连 base（context-path /hr-4a-service） |
| `FOURA_ORG_ID` | `31` | 租户段，REST 路径形态 `/{organizationId}/api/v1/**` |
| `FOURA_API_TOKEN` | 无（必须注入） | **服务侧共享令牌（唯一凭据）**：`X-Api-Token` 头，值与 hr-4a-service 的 `four-a.api-token` 配置一致；无内置默认，必须用此变量或 build 的 `foura_api_token` 入参注入（测试可与 `SSO_CONFIG_TOKEN` 同值） |
| `FOURA_TIMEOUT` | 30 | 秒 |
| `FOURA_CACHE_TTL` | 86400 | 组织树/人员池内存缓存秒数；4A 每天更新，默认 24h；0=每次重拉 |
| `FOURA_ORG_FALLBACK_MAX` | 50 | 根树缺少组织时最多补链的组织数；0=不补，负数=不限 |
| `FOURA_ROOT_ORG` | `50016195` | 华星光电根组织 |

## 请求形态（2026-11-19 部署版实测 8/8 接口 200 真数据）

- **直连 REST 形态**：`{base}/{organizationId}/api/v1/**`，orgCode/empId/jobCode 均为**路径参数**（如 `/31/api/v1/orgs/50016195`、`/31/api/v1/persons/10020`）；分页等筛选项走 query。
- 端点表（`DEFAULT_ENDPOINTS`，与源码 `hr-4a-service-server\...\controller\*Controller.java` 一致）：orgs/{orgCode}、orgs/{orgCode}/ancestors、orgs/{orgCode}/descendants、orgs/{orgCode}/leader-candidates、persons、persons/{empId}、persons/batch（POST，body `empIds` 数组）、jobs/{jobCode}/persons、peer-candidates。
- **peer-candidates / persons 均支持 `name` 模糊过滤**（2026-11-19 服务端新增并已部署）：`?name=方` 按姓名 LIKE 查询，可与 scopeLevel/scopeOrgCode/sequence 组合；服务端只做 L2/L3+序列+姓名粗筛，**GGS 不在 4A**——权限+GGS 仍由 skill 拿候选工号去薪酬接口3批量补齐后定名单。
- **`find_by_name` 已切服务端**：优先 `persons?name=`（单次请求），结果内姓名精确匹配；旧服务端（total>len(items)）或接口异常时回退内存池扫描，口径不变。姓名开单不再触发全池加载。
- **鉴权（2026-11-19 正式定稿，实测通过）**：单头 `X-Api-Token: <共享令牌>`——服务侧 `ApiTokenInterceptor` 校验（值 = 部署配置 `four-a.api-token`，必须由 `FOURA_API_TOKEN` 或 `foura_api_token` 注入，无内置默认）；错误/无头 401 `API token 无效`，不重试。metis 网关 permissionPublic 已放行，**无需 metis token / personal_key**。
- **无限流、无重试**：不走 AGW 网关，无 1 QPS 限制；请求一次直达，失败直接抛错交上层兜底话术。
- 服务源码：`D:\workspace\hr-4a-service`（部署走 helm：`szfabregisty.csot.tcl.com/metis/hr-4a-service`）。

## 薪酬客户端来源

`build_adapters` 内（薪酬接口一律直连 PMS）：

1. 显式传入 `salary_client` 直接用；
2. 否则用 `salary_cred` → `SalaryApiClient.from_cred(salary_cred, base_url=base_url, sso_token=sso_token)`
   （`base_url` 为 PMS 直连地址：测试 `http://10.110.20.245` / 生产 `https://pas.csot.tcl.com`）。

   salary_cred 通常由 adapters.build 经 getSsoConfig 拉取后传入；缺失即抛错，不回退。

## 已知缺口

- GGS：4A 不给，由薪酬接口 `empLevel` 补齐；未合并前为 0。
- 行政汇报线：4A 不提供 `manager_id`，按「组织管理者」推导。
- 组织树/人员池内存缓存默认 24h（`FOURA_CACHE_TTL`）；根树失败时直接报错，不再按人员组织逐个补链；树缺个别组织时最多补 `FOURA_ORG_FALLBACK_MAX` 个。
- 组织权限：已接通——`check_orgs`（接口1 `orgCodes`，祖先链精确匹配）；组织名解析不出编码时不按名称假放行（`check_org` 失败关闭），由 `confirm_post` / `confirm_extra` 强制解析出编码后再校验。
- 薪酬台账无记录：`start` 直接终止流程（不回退 4A 主数据展示固薪 0——方案会失真）。

# -*- coding: utf-8 -*-
"""圈人：上级 / 同级 / 下级（调薪、定薪共用同一套逻辑）。

- 上级：M 取“组织 -1 层”、P/T 取同组织中「主管标识 X」负责人岗位的人（可多人/兼岗）；无主管岗位则空，不兜底。
- 同级：大组织 L3 / 中小组织 L2；15 级以上且发起人为唐嘉/张亚君时同 GGS、同序列、不限组织。
- 下级：M 取本组织 + 下级组织所有人；按总薪酬（固薪+奖金+长期激励）前 10；P/T 为空。
"""


def seq_group(seq):
    return "M" if seq == "M" else "PT"


def org_name(p):
    return p.get("l4") or p.get("l3") or p.get("l2") or ""


def _pick_upper(target, new_seq, sap):
    """只按组织取上级，不使用行政汇报线。返回上级人员（单 dict 或列表均可）。

    M → 调薪后组织的上层组织；P/T → 调薪后本组织；负责人 = 该组织主管标识 X
    岗位上的人（可多人/兼岗）；无主管岗位 → 空（「直接上级岗位为空」，不兜底）。
    """
    if not target.get("org_code"):
        return []
    return sap.manager_for_org(target["org_code"], new_seq) or []


def _total_cash(p):
    return ((p.get("fixed", 0) or 0)
            + (p.get("last_bonus", 0) or 0)
            + (p.get("last_lti", 0) or 0))


BIG_ORGS = {"OLED中台", "制造中台", "研发中台"}


def _ggs_known(p):
    """人员是否带有可信 GGS（4A 不给 GGS，只有薪酬接口合并后才算数）。"""
    v = p.get("ggs")
    if not v:
        return False
    # 薪酬接口合并后会带 ggs_source=salary（或 fixed>0），以此判断 GGS 是否可信。
    return (p.get("fixed") or 0) > 0 or p.get("ggs_source") == "salary"


def _peer_scope(target, new_ggs, new_seq, initiator_name=None):
    """同级候选池条件（不含 GGS 过滤；GGS 由 _peer_ggs_filter 二次过滤）。

    大组织看 L3；中小组织看 L2；15+ 且发起人是唐嘉/张亚君才不限组织。
    匹配优先用组织编码（l3_code/l2_code，4A 适配层提供），避免同名组织串池。
    """
    sg = seq_group(new_seq)
    if new_ggs >= 15 and initiator_name in ("唐嘉", "张亚君"):
        return (lambda p: seq_group(p.get("seq")) == sg, "")

    l2_name = target.get("l2")
    l3_name = target.get("l3")
    if l2_name in BIG_ORGS and (target.get("l3_code") or l3_name):
        # 大组织：按 L3 编码匹配（防同名串池）；旧数据无编码时回退名称
        l3_code = target.get("l3_code") or ""
        if l3_code:
            return (lambda p: (p.get("l3_code") or "") == l3_code
                    and seq_group(p.get("seq")) == sg, "")
        return (lambda p: p.get("l3") == l3_name and seq_group(p.get("seq")) == sg, "")
    # 中小组织：按 L2 匹配（编码优先，防同名串池）
    l2_code = target.get("l2_code") or ""
    if l2_code:
        return (lambda p: (p.get("l2_code") or "") == l2_code
                and seq_group(p.get("seq")) == sg, "")
    return (lambda p: p.get("l2") == l2_name and seq_group(p.get("seq")) == sg, "")


def _peer_ggs_filter(new_ggs, peers, sap, auth):
    """同级 GGS 精确过滤。返回 (GGS 相同的人员, 有权限人员列表或 None)。

    - 候选自带 GGS（薪酬适配层 / 已合并过薪酬）：直接按 GGS 过滤，
      行为与旧逻辑一致，不做额外查询
    - 候选无 GGS（4A 适配层）：先权限校验淘汰无权限的人，
      再对有权限的人批量查薪酬接口取 GGS，留下 GGS == new_ggs 的

    薪酬查询结果由 sap.fetch_salary 合并回其人员池；候选是池内 dict 的引用，
    合并后原 dict 已更新（load_salary 原地改），无需重新取。
    """
    if all(_ggs_known(p) for p in peers):
        return [p for p in peers if p.get("ggs") == new_ggs], None

    # 4A：先权限（便宜的先做），无权限的直接淘汰
    perm = _permission_map(auth, peers)
    allowed = [p for p in peers
               if perm.get(str(p.get("emp_id")), {}).get("allowed", False)]

    # 再薪酬（贵的后做）：批量查接口3，结果合并回人员池（原地更新 dict）
    if allowed and hasattr(sap, "fetch_salary"):
        sap.fetch_salary([p["emp_id"] for p in allowed])
    return ([p for p in allowed if p.get("ggs") == new_ggs], allowed)


def _permission_map(auth, people, fresh=False):
    if not auth:
        return {}
    uniq = {}
    for p in people or []:
        if p and p.get("emp_id"):
            uniq[str(p["emp_id"])] = p
    if not uniq:
        return {}
    checked = [p for p in uniq.values() if p.get("hasPermission") is not False]
    if not checked:
        return {}
    if fresh and hasattr(auth, "fresh_permissions"):
        return auth.fresh_permissions(checked)
    if hasattr(auth, "check_permissions"):
        return auth.check_permissions(checked)
    return {str(p["emp_id"]): auth.check_permission(p) for p in checked}


def _org_ancestor_chain(sap, org_code):
    """组织编码 → [自身, 父, 祖, ...] 根向上链（组织校验接口精确匹配用）。

    4A 适配层内部索引：FourASapAdapter._orgs，字段 parentOrgCode。
    """
    chain = [str(org_code)]
    idx = getattr(sap, "_orgs", None)
    if not isinstance(idx, dict) or chain[0] not in idx:
        return chain
    seen = set(chain)
    cur = idx[chain[0]]
    guard = 0
    while cur is not None and guard < 12:
        parent = str(cur.get("parentOrgCode") or "")
        if not parent or parent in seen:
            break
        chain.append(parent)
        seen.add(parent)
        cur = idx.get(parent)
        guard += 1
    return chain


def org_perm_gate(sap, auth, org_code):
    """组织权限闸门：用户改写/模糊匹配出的目标组织必须落在操作人权限内。

    权限口径：BP 有 A 的权限即覆盖 A 的全部子孙组织（A/B/C → B、C 同权）。
    组织校验接口只做精确匹配，所以沿 parentOrgCode 上溯生成祖先链
    [目标, 父, 祖, ...]，链上任一组织在权限内即放行。

    只走真·组织校验（check_orgs，checkSalaryBp 按 orgCodes 校验）；接口异常
    一律严格拦截，不做抽样兜底、不因抖动放行。
    返回 {"allowed": bool, "reason": str|None, "samples": [], "note": str|None,
          "via": "empty"|"org_api"}。
    """
    out = {"allowed": True, "reason": None, "samples": [], "note": None, "via": None}
    if not org_code or not auth:
        out["via"] = "empty"
        return out
    org_code = str(org_code)

    chain = _org_ancestor_chain(sap, org_code)
    try:
        verdict = auth.check_orgs(chain)
    except Exception:
        out["allowed"] = False
        out["via"] = "org_api"
        out["reason"] = "组织权限校验暂时不可用，请稍后重试（已按最严格口径拦截）。"
        return out

    out["via"] = "org_api"
    if any(verdict.get(c) for c in chain):
        return out

    name = ""
    if hasattr(sap, "org_path"):
        try:
            name = sap.org_path(org_code) or ""
        except Exception:
            name = ""
    out["allowed"] = False
    out["reason"] = ("组织「%s」不在你的薪酬权限范围内。"
                     "不能把它作为调薪后组织/入职组织。"
                     % (name or org_code))
    return out


def filter_org_matches(sap, auth, matches):
    """按组织权限过滤同名匹配列表（消歧话术前调用，避免向用户展示无权限组织）。

    口径与 org_perm_gate 一致：候选组织的祖先链上任一组织在权限内即保留。
    返回 (过滤后列表, 是否因接口异常而未过滤)。
    """
    if not auth or not matches:
        return list(matches or []), False
    kept = []
    for m in matches:
        code = str(m.get("cOrgCode") or m.get("orgCode") or "")
        if not code:
            continue
        try:
            gate = org_perm_gate(sap, auth, code)
        except Exception:
            return list(matches), True   # 校验异常时不猜：保留原列表交权限闸兜底
        if (not gate.get("allowed")
                and "暂时不可用" in str(gate.get("reason") or "")):
            return list(matches), True   # 权限接口异常：交调用方按系统繁忙处理
        if gate.get("allowed"):
            kept.append(m)
    return kept, False


def build_roster(target, new_ggs, new_seq, sap, auth, initiator_name=None):
    """target：调薪取本人；定薪取“入职岗位”虚拟人员（emp_id 可为空）。

    上级按组织管理者取；下级 M 按本组织 + 下级组织取；不使用行政汇报线。
    """
    upper = _pick_upper(target, new_seq, sap)
    # manager_for_org 返回单 dict（4A 适配层）；统一成列表消费
    if isinstance(upper, dict):
        upper = [upper]
    upper = [p for p in (upper or []) if p and p.get("emp_id")]
    upper_ids = {p.get("emp_id") for p in upper}
    match, peer_rule = _peer_scope(target, new_ggs, new_seq, initiator_name)

    peers = [p for p in sap.all_people()
             if p.get("emp_id") and match(p)
             and p.get("emp_id") != target.get("emp_id")
             and p.get("emp_id") not in upper_ids]
    peers, _ = _peer_ggs_filter(new_ggs, peers, sap, auth)

    # 下级：M 取本组织 + 所有下级组织的人；按总薪酬前 10；P/T 为空。
    # 无 org_code（如入职组织未解析）时无法按组织圈下级，直接为空。
    subs = []
    if new_seq == "M" and target.get("org_code"):
        pool = sap.reports_for_org(target["org_code"], new_seq, target.get("emp_id"))

        uniq = {}
        for p in pool:
            eid = p.get("emp_id")
            if not eid or eid == target.get("emp_id"):
                continue
            if target.get("manager_id") and eid == target.get("manager_id"):
                continue
            if upper_ids and eid in upper_ids:
                continue
            uniq[eid] = p
        pool = list(uniq.values())
        # 先过薪酬权限，再查薪酬：无权限的人不该被拉薪酬数据（也不该占 top10 名额）。
        # 排序按总薪酬，所以薪酬还是得查——但只查有权限的人。
        pool_perm = _permission_map(auth, pool)
        pool = [p for p in pool
                if (pool_perm.get(str(p.get("emp_id"))) or {}).get("allowed")]
        # 4A 等无薪酬数据源：先查薪酬再按总薪酬排（否则 top10 是任意顺序）
        if pool and not all((p.get("fixed") or 0) > 0 or p.get("ggs_source")
                            for p in pool) and hasattr(sap, "fetch_salary"):
            sap.fetch_salary([p["emp_id"] for p in pool])
        subs = sorted(pool, key=_total_cash, reverse=True)[:10]

    sections = []
    perm = _permission_map(auth, list(upper) + peers + subs)

    def pack(key, label, rule, people, show_when_hidden=False):
        rows = []
        for p in people:
            allowed = perm.get(str(p.get("emp_id")), {}).get("allowed", False)
            if not allowed and not (key == "upper" and show_when_hidden):
                continue
            rows.append({
                "name": p["name"], "emp_id": p["emp_id"],
                "org": org_name(p), "ggs": p.get("ggs"), "seq": p.get("seq"),
                "visible": allowed, "removed": False, "added": False,
                "note": "" if allowed else "未在你的薪酬权限范围内，不提供上级薪酬信息",
                "_raw": p,
            })
        note = ""
        if key == "upper" and not people:
            note = "直接上级岗位为空"
        elif key == "peer" and not people:
            note = "同级名单为空"
        sections.append({"key": key, "label": label, "rule": rule,
                         "count": sum(1 for r in rows if not r["removed"]),
                         "note": note, "people": rows})

    if new_seq == "M":
        upper_rule = ""
    else:
        upper_rule = ""

    if new_seq == "M":
        sub_rule = ""
    else:
        sub_rule = ""

    pack("upper", "上级", upper_rule, upper, show_when_hidden=True)
    pack("peer", "同级", peer_rule, peers)
    pack("reportee", "下级", sub_rule, subs)
    return sections

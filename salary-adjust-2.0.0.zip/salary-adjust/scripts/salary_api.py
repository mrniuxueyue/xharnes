# -*- coding: utf-8 -*-
"""薪酬系统(PMS)直连客户端。

对应《AI 调用薪酬系统接口文档 v1.0》（全部直连 PMS，不经任何网关）：
  0 POST {base}/external/token                      获取 accessToken（缓存 2h）
  1 POST {base}/external/salary/checkSalaryBp       校验操作人是否为薪酬 BP
  2 POST {base}/external/salary/grantSalaryBpAuth   COE 调整员工 BP（7 天临时授权，AES-GCM + RSA 签名）
  3 POST {base}/external/salary/list                查询调薪对象薪酬（响应 AES-GCM 加密 + RSA 验签）

配置优先从环境变量读取（不要把密钥写进代码/仓库/日志）：
  SALARY_BASE_URL          例（测试）：http://10.110.20.245（生产 https://pas.csot.tcl.com）
  SALARY_APP_ID
  SALARY_SECRET
  SALARY_AES_KEY           AES 密钥串（双方预置）
  SALARY_RSA_PRIVATE_KEY   AI 平台 RSA 私钥（PEM 或 Base64 DER），接口2 签名用
  SALARY_RSA_PUBLIC_KEY    薪酬系统 RSA 公钥（PEM 或 Base64 DER），接口3 验签用
  SALARY_SSO_TOKEN         登录人 SSO token（接口 1/3 的 ssoToken，放 body）

凭据通常由 getSsoConfig 拉取后经 from_cred() 传入：
  SalaryApiClient.from_cred({"appId": "...", "secret": "...", "aesKey": "...", "rsaPublic": "..."},
                            base_url="https://pas.csot.tcl.com")

依赖：cryptography（仅接口 2/3 的加解密+签名需要；未安装时接口 0/1 仍可用）
"""
import base64
import hashlib
import json
import os
import time
import urllib.error
import urllib.request


class SalaryApiError(Exception):
    def __init__(self, code, msg, path=""):
        super().__init__("[%s] code=%s msg=%s" % (path, code, msg))
        self.code = code
        self.msg = msg
        self.path = path


class SalaryApiClient:
    def __init__(self, base_url="", app_id="", secret="", aes_key="",
                 rsa_private="", rsa_public="", timeout=15, ai_session_id=None,
                 sso_token=""):
        self.base = (base_url or "").rstrip("/")
        self.app_id = app_id
        self.secret = secret
        self.aes_key = aes_key
        self.rsa_private = rsa_private
        self.rsa_public = rsa_public
        self.sso_token = sso_token
        self.timeout = timeout
        self.ai_session_id = ai_session_id or ("ai-%d" % int(time.time() * 1000))
        self._token = None
        self._token_exp = 0.0

    # ---------------- 构造 ----------------
    @classmethod
    def from_env(cls):
        g = os.environ.get
        return cls(
            base_url=g("SALARY_BASE_URL", ""),
            app_id=g("SALARY_APP_ID", ""),
            secret=g("SALARY_SECRET", ""),
            aes_key=g("SALARY_AES_KEY", ""),
            rsa_private=g("SALARY_RSA_PRIVATE_KEY", ""),
            rsa_public=g("SALARY_RSA_PUBLIC_KEY", ""),
            sso_token=g("SALARY_SSO_TOKEN", ""),
        )

    @classmethod
    def from_cred(cls, cred, base_url="", sso_token="", timeout=15):
        """按《AI调用薪酬系统接口文档》凭据模型构造。

        cred 形如 {"appId": "...", "secret": "...", "aesKey": "...", "rsaPublic": "..."}，
        兼容大小写与旧键名（app_id/secret/aes_key/rsa_public）。
        base_url 必填（测试 http://10.110.20.245 / 生产 https://pas.csot.tcl.com）。
        """
        cred = cred or {}
        def pick(*keys):
            for k in keys:
                v = cred.get(k)
                if v:
                    return v
            return ""
        return cls(
            base_url=base_url or pick("base_url", "baseUrl"),
            app_id=pick("appId", "app_id", "应用标识"),
            secret=pick("secret", "应用密钥"),
            aes_key=pick("aesKey", "aes_key", "AES密钥", "AES 密钥"),
            rsa_public=pick("rsaPublic", "rsaPublicKey", "rsa_public", "RSA公钥", "RSA 公钥"),
            rsa_private=pick("rsaPrivate", "rsaPrivateKey", "rsa_private", "RSA私钥"),
            sso_token=sso_token,
            timeout=timeout,
        )

    # ---------------- HTTP ----------------
    def _http(self, url, payload, headers):
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                return r.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            return e.read().decode("utf-8", "replace")
        except Exception as e:
            raise SalaryApiError(-1, "%s: %s" % (type(e).__name__, e), url)

    def _call(self, path, payload, auth=True):
        if not self.base:
            raise SalaryApiError(-1, "缺少薪酬系统地址（base_url / SALARY_BASE_URL）", path)
        headers = {"Content-Type": "application/json"}
        if auth:
            headers["Authorization"] = "Bearer " + self.token()
        body = self._http(self.base + path, payload, headers)
        try:
            j = json.loads(body)
        except Exception:
            raise SalaryApiError(-1, "非 JSON 响应: " + body[:200], path)
        if j.get("code") != 0:
            raise SalaryApiError(j.get("code"), j.get("msg"), path)
        return j

    # ---------------- token ----------------
    def token(self, force=False):
        if not force and self._token and time.time() < self._token_exp - 60:
            return self._token
        j = self._call("/external/token",
                       {"appId": self.app_id, "secret": self.secret}, auth=False)
        data = j.get("data") or {}
        self._token = data.get("accessToken")
        exp = int(data.get("expiresIn") or 7200)
        self._token_exp = time.time() + exp
        if not self._token:
            raise SalaryApiError(j.get("code"), j.get("msg"), "/external/token")
        return self._token

    # ---------------- 接口 1 ----------------
    def check_bp(self, user_codes=None, sso_token="", org_codes=None):
        """校验薪酬 BP。userCodes（工号批量）或 orgCodes（组织批量，userCodes 为空时生效）。"""
        body = {"aiSessionId": self.ai_session_id, "ssoToken": sso_token}
        if user_codes:
            body["userCodes"] = list(user_codes)
        if org_codes:
            body["orgCodes"] = list(org_codes)
        j = self._call("/external/salary/checkSalaryBp", body)
        return j.get("data") or {}

    # ---------------- 接口 3 ----------------
    def list_salary(self, user_codes, sso_token):
        j = self._call("/external/salary/list",
                       {"aiSessionId": self.ai_session_id, "ssoToken": sso_token,
                        "userCodes": list(user_codes)})
        env = j.get("data") or {}
        plain = self._decrypt_verify(env)
        data = json.loads(plain)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            for key in ("data", "records", "list", "items"):
                inner = data.get(key)
                if isinstance(inner, list):
                    return inner
                if isinstance(inner, dict) and (inner.get("userCode") or inner.get("emp_id")):
                    return [inner]
            # 单条记录：必须有工号才算有效，空对象/纯包装对象返回空列表
            if data.get("userCode") or data.get("emp_id"):
                return [data]
            return []
        return []

    # ---------------- 接口 2 ----------------
    def grant_bp(self, user_code, salary_bp_usercode, user_name="",
                 salary_bp_name="", sso_token=""):
        body = {
            "userCode": user_code,
            "salaryBpUserCode": salary_bp_usercode,
        }
        if user_name:
            body["userName"] = user_name
        if salary_bp_name:
            body["salaryBpName"] = salary_bp_name
        plain = json.dumps(body, ensure_ascii=False)
        iv_b64, data_b64 = self._encrypt(plain)
        sign = self._sign(iv_b64, data_b64)
        return self._call("/external/salary/grantSalaryBpAuth",
                          {"aiSessionId": self.ai_session_id, "ssoToken": sso_token,
                           "iv": iv_b64, "data": data_b64, "sign": sign})

    # ---------------- 加解密 / 签名 ----------------
    def _aes(self):
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        key = hashlib.sha256(self.aes_key.encode("utf-8")).digest()
        return AESGCM(key)

    def _encrypt(self, plain):
        iv = os.urandom(12)
        ct = self._aes().encrypt(iv, plain.encode("utf-8"), None)
        return base64.b64encode(iv).decode(), base64.b64encode(ct).decode()

    def _load_private(self):
        from cryptography.hazmat.primitives import serialization
        raw = (self.rsa_private or "").strip().replace("\\n", "\n")
        if not raw:
            raise SalaryApiError(-1, "未配置 RSA 私钥（SALARY_RSA_PRIVATE_KEY）")
        if "BEGIN" in raw:
            return serialization.load_pem_private_key(raw.encode(), password=None)
        return serialization.load_der_private_key(base64.b64decode(raw), password=None)

    def _load_public(self):
        from cryptography.hazmat.primitives import serialization
        raw = (self.rsa_public or "").strip().replace("\\n", "\n")
        if not raw:
            raise SalaryApiError(-1, "未配置 RSA 公钥（SALARY_RSA_PUBLIC_KEY）")
        if "BEGIN" in raw:
            return serialization.load_pem_public_key(raw.encode())
        return serialization.load_der_public_key(base64.b64decode(raw))

    def _sign(self, iv_b64, data_b64):
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.asymmetric import padding
        sig = self._load_private().sign(
            (iv_b64 + "\n" + data_b64).encode("utf-8"),
            padding.PKCS1v15(), hashes.SHA256())
        return base64.b64encode(sig).decode()

    def _decrypt_verify(self, env):
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.asymmetric import padding
        if not env or not env.get("iv") or not env.get("data"):
            raise SalaryApiError(-1, "响应缺少 iv/data，无法解密")
        iv_b64 = env["iv"]
        data_b64 = env["data"]
        sign_b64 = env.get("sign", "")
        # 接口3 响应必须验签，未验签的数据不使用
        if not sign_b64:
            raise SalaryApiError(-1, "响应缺少 sign，拒绝使用未验签数据")
        if not self.rsa_public:
            raise SalaryApiError(-1, "未配置薪酬系统 RSA 公钥，无法验签")
        self._load_public().verify(
            base64.b64decode(sign_b64),
            (iv_b64 + "\n" + data_b64).encode("utf-8"),
            padding.PKCS1v15(), hashes.SHA256())
        plain = self._aes().decrypt(
            base64.b64decode(iv_b64), base64.b64decode(data_b64), None)
        return plain.decode("utf-8")

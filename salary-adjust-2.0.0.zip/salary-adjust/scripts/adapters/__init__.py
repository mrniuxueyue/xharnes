"""Build independent 4A and PMS adapters for one signed-in platform session."""
from runtime_config import TEST_4A, TEST_PMS, TEST_SSO, deployment_mode, endpoint, setting

_CREDENTIALS = ("appId", "secret", "aesKey", "rsaPublic")


def build(sso_token="", operator="", role=None, client=None,
          salary_cred=None, gateway="", data_source="4a", base_url="",
          salary_client=None, sso_config_base_url="", sso_config_org_id=None,
          sso_config_token="", foura_api_token="", environment=None):
    if (data_source or "4a").strip().lower() != "4a":
        raise ValueError("data_source 仅支持 4a")
    mode = deployment_mode(environment)
    if not str(sso_token or "").strip():
        raise ValueError("缺少 sso_token")
    if client is None:
        gateway = endpoint(gateway, "FOURA_BASE_URL", mode, TEST_4A)
        foura_api_token = setting(foura_api_token, "FOURA_API_TOKEN")
        if not foura_api_token:
            raise ValueError("缺少 FOURA_API_TOKEN")
    cred = dict(salary_cred or {})
    if salary_client is None:
        base_url = endpoint(base_url, "SALARY_BASE_URL", mode, TEST_PMS)
        for key in ("rsaPublic", "rsaPrivate"):
            cred[key] = cred.get(key) or cred.get(key + "Key") or cred.get(
                "rsa_public" if key == "rsaPublic" else "rsa_private")
        if any(not cred.get(key) for key in _CREDENTIALS):
            from sso_config import load_sso_config
            config_url = endpoint(sso_config_base_url, "SSO_CONFIG_BASE_URL", mode, TEST_SSO)
            config_token = setting(sso_config_token, "SSO_CONFIG_TOKEN")
            if not config_token:
                raise ValueError("缺少 SSO_CONFIG_TOKEN")
            fetched = load_sso_config(base_url=config_url, organization_id=sso_config_org_id,
                                      token=config_token, environment=mode)
            for key in (*_CREDENTIALS, "rsaPrivate"):
                if not cred.get(key):
                    cred[key] = fetched.get(key)
        missing = [key for key in _CREDENTIALS if not cred.get(key)]
        if missing:
            raise ValueError("缺少薪酬服务配置项 " + "、".join(missing))
    from .foura import build_adapters
    return build_adapters(client=client, operator=operator, role=role,
                          sso_token=sso_token, salary_cred=cred, salary_client=salary_client,
                          base_url=base_url, gateway=gateway, foura_api_token=foura_api_token,
                          environment=mode)

# -*- coding: utf-8 -*-
"""真实薪酬系统适配层（PMS 直连：checkSalaryBp / list_salary / grant）。

用法（在 scripts 目录）：
    import os
    from adapters.salary import AuthAdapter, BaselineAdapter
    from salary_api import SalaryApiClient

    client = SalaryApiClient.from_cred(salary_cred, base_url=...)
    auth = AuthAdapter(client, operator=os.environ["SALARY_OPERATOR_CODE"],
                       sso_token=os.environ["SALARY_SSO_TOKEN"],
                       role=os.environ.get("SALARY_ROLE", "BP"))
    base = BaselineAdapter()

组织/上下级取人由 adapters/foura.py（4A 组织树）提供；
岗位序列 jobSequence → M/P/T：默认用 jobCategory 兜底，可用 SALARY_SEQ_MAP 覆盖。
"""
import math
import json
import os
import re
import time

from salary_api import SalaryApiClient, SalaryApiError

# jobSequence / jobCategory 的后备映射（可用环境变量 SALARY_SEQ_MAP 覆盖，
# 如 {"研发":"T","管理":"M","专业":"P"}）
try:
    _SEQ_MAP = json.loads(os.environ.get("SALARY_SEQ_MAP", "{}") or "{}")
except Exception:
    _SEQ_MAP = {}

# 九宫格 talentInventory9BoxPos → ①②③④，可用 SALARY_NINE_BOX_MAP 覆盖

# 九宫格：接口值 → Skill 的 ①②③④
# 可用 SALARY_NINE_BOX_MAP 覆盖，如 {"高潜":"①","核心":"②"}
_NINE_BOX_DEFAULT = {
    "高潜": "①", "高潜力": "①", "明星": "①", "超级明星": "①", "卓越": "①",
    "核心": "②", "中坚": "②", "骨干": "②", "高绩效": "②",
    "待发展": "③", "潜力": "③", "普通": "③", "一般": "③",
    "中潜": "②", "中潜力": "②", "中等": "③",
    "低绩效": "④", "待改进": "④", "淘汰": "④", "低潜": "④",
}
try:
    _NINE_BOX_MAP = dict(_NINE_BOX_DEFAULT)
    _NINE_BOX_MAP.update(json.loads(os.environ.get("SALARY_NINE_BOX_MAP", "{}") or "{}"))
except Exception:
    _NINE_BOX_MAP = dict(_NINE_BOX_DEFAULT)


def map_nine_box(v):
    """接口 talentInventory9BoxPos → ①-⑨。未知值保留原文，calc 仍会兜底 0.5。"""
    s = (v or "").strip()
    if s in ("①", "②", "③", "④", "⑤", "⑥", "⑦", "⑧", "⑨"):
        return s
    if s in _NINE_BOX_MAP:
        return _NINE_BOX_MAP[s]
    if any(k in s for k in ("高潜", "明星", "卓越", "超")):
        return "①"
    if "中潜" in s:
        return "②"
    if any(k in s for k in ("核心", "中坚", "骨干", "高绩")):
        return "②"
    if any(k in s for k in ("待发展", "潜力", "普通", "一般")):
        return "③"
    if any(k in s for k in ("低绩", "待改进", "淘汰", "低潜")):
        return "④"
    return s


def _num(v, default=0.0):
    try:
        n = float(v)
        return n if math.isfinite(n) else default
    except (TypeError, ValueError):
        return default


def _int(v, default=0):
    if v is None:
        return default
    try:
        return int(float(str(v).strip()))
    except (TypeError, ValueError):
        m = re.search(r"-?\d+", str(v))
        return int(m.group()) if m else default


def map_seq(job_sequence, job_category=""):
    """jobSequence/jobCategory → M/P/T。

    文档示例：jobSequence=研发、jobCategory=技术 → T。
    精确字典请用 SALARY_SEQ_MAP 覆盖；默认：管理→M，技术/研发→T，其余→P。
    """
    for s in (job_sequence, job_category):
        s = (s or "").strip()
        if s in ("M", "P", "T"):
            return s
        if s in _SEQ_MAP:
            return _SEQ_MAP[s]
    text = "%s/%s" % (job_sequence or "", job_category or "")
    if any(k in text for k in ("管理", "经理", "总监", "主管")):
        return "M"
    if any(k in text for k in ("技术", "研发", "开发", "工程")):
        return "T"
    return "P"


def _si_get(d, key, default=None):
    """薪酬明细取数：兼容接口返回大写 T002 / BS043，也兼容文档里的小写。"""
    if not d:
        return default
    if key in d:
        return d[key]
    lk = str(key).lower()
    for k, v in d.items():
        if str(k).lower() == lk:
            return v
    return default


def to_person(item):
    """接口3 单条记录 → Skill 人员结构。"""
    si = item.get("salaryItems") or {}
    bs = item.get("bonusSpecial") or {}
    ar = item.get("adjustRecord") or {}
    months = _int(item.get("salary13Or12"), 13) or 13
    # 业务确认：固薪取 t002 固定收入，t002 是年口径，不再乘 12/13。
    fixed = _num(_si_get(si, "t002CNY"), None) or _num(_si_get(si, "t002"), None)
    # t009 奖金基线保留接口原始值；方案里的奖金基线按 GGS 占比重算
    bonus_base = _num(_si_get(si, "t009CNY")) or _num(_si_get(si, "t009"))
    l2 = item.get("l2", "")
    l3 = item.get("l3", "")
    l4 = item.get("l4", "")
    l5 = item.get("l5", "")
    l6 = item.get("l6", "")
    org_path = "/".join(x for x in (l2, l3, l4, l5, l6) if x)
    return {
        "emp_id": str(item.get("userCode", "")),
        "name": item.get("userName", ""),
        "nationality": item.get("nationality", ""),
        "l2": l2,
        "l3": l3,
        "l4": l4,
        "l5": l5,
        "l6": l6,
        "org_path": org_path,
        "post": item.get("jobName", ""),
        # 业务确认：M/P/T 暂时只看 jobSequence
        "seq": map_seq(item.get("jobSequence", "")),
        "seq_raw": item.get("jobSequence", ""),
        "job_category": item.get("jobCategory", ""),
        "ggs": _int(item.get("empLevel"), 0),
        "city": item.get("cityType", ""),
        "months": months,
        "fixed": fixed,
        "bonus_base": bonus_base,
        "last_bonus": _num(_si_get(bs, "bs043")),
        "last_lti": _num(_si_get(bs, "bs044")),
        "resident": _num(_si_get(si, "t011")),
        "t001": _num(_si_get(si, "t001")),
        "t003": _num(_si_get(si, "t003")),
        "t004": _num(_si_get(si, "t004")),
        "t005": _num(_si_get(si, "t005")),
        "t007": _num(_si_get(si, "t007")),
        "t049": _num(_si_get(si, "t049")),
        "t002CNY": _num(_si_get(si, "t002CNY")),
        "t009CNY": _num(_si_get(si, "t009CNY")),
        "t002": _num(_si_get(si, "t002")),
        "t009": _num(_si_get(si, "t009")),
        "perf1": item.get("last1YearPerformance", ""),
        "perf2": item.get("last2YearPerformance", ""),
        "perf3": item.get("last3YearPerformance", ""),
        "nine_box": map_nine_box(item.get("talentInventory9BoxPos", "")),
        "nine_box_raw": item.get("talentInventory9BoxPos", ""),
        "fixed_competitiveness": item.get("fixedSalaryCompetitiveness", ""),
        "current_salary_pos": item.get("currentSalaryPos", ""),
        "seniority": item.get("seniority", ""),
        "salary_type": item.get("salaryType", ""),
        "special_structure": item.get("specialStructure", ""),
        "currency": item.get("currency", ""),
        "effective_date": item.get("effectiveDate", ""),
        "yearly_modulate": _num(item.get("yearlySalaryModulate")),
        "manager_id": "",                      # 缺口：接口未提供行政主管
        "bp": item.get("salaryBp", ""),
        "bp_head": item.get("salaryBpHead", ""),
        "bp_name": item.get("salaryBpName", ""),
        "bp_head_name": item.get("salaryBpHeadName", ""),
        "email": item.get("email", ""),
        "join_date": item.get("entryDate", ""),
        "last_raise_date": _si_get(ar, "effectiveDate", ""),
        "last_raise_ratio": _num(_si_get(ar, "t002Increase")),
        "edu": item.get("education", ""),
        "school_type": item.get("schoolType", ""),
        "first_degree": item.get("firstDegree", ""),
        "first_degree_school_type": item.get("firstDegreeSchoolType", ""),
        "eyas": item.get("eyas", ""),
        "family": item.get("jobFamily", ""),
        "post_class": item.get("jobCategory", ""),
        "post_sub": item.get("postSubclass", ""),
        "cohort": item.get("eyas", "") if item.get("eyas") not in ("否", "无") else "",
        "salary_items": si,
        "bonus_special": bs,
        "bonus_year": bs.get("bonusYear", ""),
        "time_coefficient": _num(bs.get("timeCoefficient"), 1.0),
        "adjust_record": ar,
        "hasPermission": item.get("hasPermission"),
        "message": item.get("message"),
    }




class AuthAdapter:
    """权限：接口1（校验BP）、接口2（COE 授权）。"""

    def __init__(self, client, operator="", sso_token="", role="BP"):
        self.client = client
        self.operator = str(operator)
        self.sso_token = sso_token
        self.role = role
        self._cache = {}
        self._cache_ttl = 300  # 权限结果最多缓存 5 分钟，且只属于当前操作人

    def is_coe(self):
        return self.role == "COE"

    def check_permission(self, target):
        emp = str(target.get("emp_id") if isinstance(target, dict) else target)
        res = self.check_permissions([target]).get(emp)
        return res or {"allowed": False, "reason": "未在你的薪酬权限范围内"}

    def fresh_permissions(self, targets):
        return self.check_permissions(targets, fresh=True)

    def check_permissions(self, targets, batch=50, fresh=False):
        """批量校验 BP：接口 1 的 userCodes 支持数组，50 个一批。"""
        targets = list(targets or [])
        results = {}
        to_query = []
        seen = set()
        for target in targets:
            emp = str(target.get("emp_id") if isinstance(target, dict) else target)
            if not emp:
                continue
            # 接口3 已明确无数据权限时直接拒绝
            if isinstance(target, dict) and target.get("hasPermission") is False:
                results[emp] = {"allowed": False,
                                "reason": target.get("message") or "未在你的薪酬权限范围内"}
                continue
            if self.is_coe():
                results[emp] = {"allowed": True, "reason": None}
                continue
            cached = self._cache.get(emp)
            if not fresh and cached and time.time() < cached[1]:
                allowed = cached[0]
                results[emp] = {"allowed": allowed,
                                "reason": None if allowed else "未在你的薪酬权限范围内"}
                continue
            if emp not in seen:
                seen.add(emp)
                to_query.append(emp)

        for i in range(0, len(to_query), batch):
            chunk = to_query[i:i + batch]
            data = self.client.check_bp(chunk, self.sso_token)
            authorized = {str(x) for x in (data.get("authorizedUserCodes") or [])}
            for emp in chunk:
                allowed = emp in authorized
                self._cache[emp] = (allowed, time.time() + self._cache_ttl)
                results[emp] = {"allowed": allowed,
                                "reason": None if allowed else "未在你的薪酬权限范围内"}
        return results

    def check_org(self, org):
        # 组织权限必须按组织编码 + 祖先链校验；没有编码时不假放行。
        return {"allowed": False,
                "reason": "暂时无法校验该组织权限，请使用完整组织路径或联系管理员。"}

    def check_orgs(self, org_codes, batch=50):
        """按组织批量校验 BP：接口 1 的 orgCodes（userCodes 为空时按组织校验）。

        返回 {org_code: bool}。祖先链由调用方（roster.org_perm_gate）生成，
        本方法只做接口查询与解析（authorizedOrgCodes）。
        """
        codes = [str(c) for c in (org_codes or []) if c]
        results = {c: False for c in codes}
        if not codes:
            return results
        for i in range(0, len(codes), batch):
            chunk = codes[i:i + batch]
            data = self.client.check_bp(org_codes=chunk, sso_token=self.sso_token)
            authorized = {str(x) for x in (data.get("authorizedOrgCodes") or [])}
            for c in chunk:
                results[c] = c in authorized
        return results

    def grant(self, emp_id, user_name="", bp_name=""):
        # COE：把当前操作人设为该员工的薪酬 BP（7 天临时授权）
        if not self.operator:
            raise SalaryApiError(-1, "未配置操作人工号 SALARY_OPERATOR_CODE，无法调用接口2")
        res = self.client.grant_bp(user_code=str(emp_id),
                                   salary_bp_usercode=self.operator,
                                   user_name=user_name,
                                   salary_bp_name=bp_name,
                                   sso_token=self.sso_token)
        self._cache.pop(str(emp_id), None)
        return res


class BaselineAdapter:
    """兼容占位。底线/参考校验已在 rules.py 中实现。"""
    pass



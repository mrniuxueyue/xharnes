# -*- coding: utf-8 -*-
"""hr-4a-service 适配层（4A 组织/上下级/人员池；薪酬字段由 adapters/salary.py 合并）。
"""
from runtime_config import TEST_4A, TEST_PMS, deployment_mode, endpoint
import json
import os
import time
import urllib.error
import urllib.request

# hr-4a-service 部署版直连（2026-11-19 实测 8/8 接口 200 真数据）：
# URL = {base}/{organizationId}/api/v1/**（原始 REST 形态，orgCode/empId/jobCode 为路径参数），
# 鉴权 = X-Api-Token: <共享令牌>（服务侧校验 four-a.api-token；网关 permissionPublic 已放行，
# 无需 metis token / personal_key）。
# 部署源码：D:/workspace/hr-4a-service（Spring Boot，context-path /hr-4a-service）。
DEFAULT_BASE = TEST_4A
DEFAULT_ORG_ID = "31"

# 端点表（直连 REST 形态）；{org_code}/{emp_id}/{job_code} 占位符由 _ep() 填充为路径段。
DEFAULT_ENDPOINTS = {
    "org":               "/{organizationId}/api/v1/orgs/{org_code}",
    "org_ancestors":     "/{organizationId}/api/v1/orgs/{org_code}/ancestors",
    "org_descendants":   "/{organizationId}/api/v1/orgs/{org_code}/descendants",
    "leader_candidates": "/{organizationId}/api/v1/orgs/{org_code}/leader-candidates",
    "persons":           "/{organizationId}/api/v1/persons",
    "person":            "/{organizationId}/api/v1/persons/{emp_id}",
    "persons_batch":     "/{organizationId}/api/v1/persons/batch",
    "job_persons":       "/{organizationId}/api/v1/jobs/{job_code}/persons",
    "peer_candidates":   "/{organizationId}/api/v1/peer-candidates",
}


# 4A 不提供 GGS（ggs=null / PENDING），由薪酬接口 empLevel 补齐；此处只返回 0。


def _env(name, default=""):
    return (os.environ.get(name) or default).strip()


# 服务侧共享令牌（X-Api-Token）：不再内置默认，必须由 FOURA_API_TOKEN 或构建入参注入。
# 测试环境可与 getSsoConfig 的 SSO_CONFIG_TOKEN 同值，由部署方统一配置。
DEFAULT_API_TOKEN = ""


class FourAApiError(RuntimeError):
    """hr-4a-service 调用失败。"""

    def __init__(self, path, status, body):
        super().__init__("hr-4a-service %s HTTP %s: %s" % (path, status, body[:200]))
        self.path = path
        self.status = status


class FourAClient:
    """hr-4a-service 的 REST 客户端（标准库实现）。"""

    def __init__(self, base_url=None, timeout=None, endpoints=None, org_id=None,
                 api_token=None, environment=None):
        base = endpoint(base_url, "FOURA_BASE_URL", deployment_mode(environment), TEST_4A)
        self.base = base
        # 租户段：直连形态是 REST 路径段 /{organizationId}/api/v1/**，
        # _ep() 把 {organizationId} 占位符填成 self.org_id。
        if org_id is None:
            org_id = _env("FOURA_ORG_ID", DEFAULT_ORG_ID)
        self.org_id = str(org_id or "").strip().strip("/")
        # 服务侧共享令牌（X-Api-Token 头）：显式入参 > FOURA_API_TOKEN > 无
        if api_token is None:
            api_token = _env("FOURA_API_TOKEN", DEFAULT_API_TOKEN)
        if not str(api_token or "").strip():
            raise ValueError("缺少 FOURA_API_TOKEN")
        self.api_token = api_token.strip()
        self.timeout = int(timeout or _env("FOURA_TIMEOUT", "30") or 30)
        self.endpoints = dict(DEFAULT_ENDPOINTS)
        if endpoints:
            self.endpoints.update({str(k): str(v) for k, v in endpoints.items() if v})

    def _headers(self):
        # 鉴权（2026-11-19 正式定稿，实测通过）：单头 X-Api-Token 共享令牌（服务侧校验，
        # 永不过期）；网关 permissionPublic 已放行，无需 metis token。
        headers = {"Accept": "application/json"}
        if self.api_token:
            headers["X-Api-Token"] = self.api_token
        return headers

    def _ep(self, name, **path_params):
        """取端点路径并填充占位符。

        直连形态：{organizationId} 用 self.org_id 填充，其余占位符由调用方给。
        """
        path = self.endpoints[name]
        if "{organizationId}" in path and self.org_id:
            path_params.setdefault("organizationId", self.org_id)
        for key, val in path_params.items():
            path = path.replace("{%s}" % key, urllib.request.quote(str(val), safe=""))
        return self.base + path

    def _bool_fmt(self, v):
        """query 参数序列化：bool → 小写 true/false，其余 str()。"""
        if isinstance(v, bool):
            return "true" if v else "false"
        return str(v)

    def get(self, path, **params):
        query = "&".join(
            "%s=%s" % (k, urllib.request.quote(self._bool_fmt(v), safe=""))
            for k, v in params.items() if v is not None
        )
        url = path + ("?" + query if query else "")
        req = urllib.request.Request(url, headers=self._headers())
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                data = json.loads(resp.read().decode("utf-8", "replace"))
        except urllib.error.HTTPError as e:
            raise FourAApiError(path, e.code, e.read().decode("utf-8", "replace"))
        # Result<T> 封装：code != Ok 视为业务错误
        if isinstance(data, dict) and data.get("code") not in (None, "Ok"):
            raise FourAApiError(path, data.get("code"), data.get("message") or "")
        return data.get("data", data) if isinstance(data, dict) else data

    # ---- 便捷方法（端点名见 DEFAULT_ENDPOINTS；org_code/emp_id/job_code 走路径）----
    def org(self, org_code):
        return self.get(self._ep("org", org_code=org_code))

    def org_ancestors(self, org_code, level=None):
        return self.get(self._ep("org_ancestors", org_code=org_code), level=level) or []

    def org_descendants(self, org_code, depth=None):
        return self.get(self._ep("org_descendants", org_code=org_code), depth=depth) or []

    def leader_candidates(self, org_code):
        data = self.get(self._ep("leader_candidates", org_code=org_code)) or {}
        return data.get("candidates") or []

    def persons_page(self, org_code=None, include_descendants=None, sequence=None,
                     name=None, page=1, page_size=500):
        data = self.get(self._ep("persons"), orgCode=org_code,
                        includeDescendants=include_descendants, sequence=sequence,
                        name=name, page=page, pageSize=page_size) or {}
        return data

    def persons_all(self, org_code=None, include_descendants=None, sequence=None):
        """翻页拉全量（pageSize=500）。"""
        out, page = [], 1
        page_size = 500
        while True:
            data = self.persons_page(org_code=org_code, include_descendants=include_descendants,
                                     sequence=sequence, page=page, page_size=page_size)
            items = data.get("items") or []
            out.extend(items)
            if not items:
                break
            total = int(data.get("total") or 0)
            if total and len(out) >= total:
                break
            if not total and len(items) < page_size:
                break
            page += 1
        return out

    def person(self, emp_id):
        # person-detail：empId 是路径参数（直连 REST 形态）
        try:
            return self.get(self._ep("person", emp_id=emp_id))
        except FourAApiError as e:
            if str(e.status) == "404":
                return None
            raise

    def persons_batch(self, emp_ids):
        if not emp_ids:
            return []
        url = self._ep("persons_batch", organizationId=self.org_id)
        req = urllib.request.Request(
            url,
            data=json.dumps({"empIds": [str(x) for x in emp_ids]}).encode("utf-8"),
            method="POST", headers=dict(self._headers(), **{"Content-Type": "application/json"}))
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                data = json.loads(resp.read().decode("utf-8", "replace"))
        except urllib.error.HTTPError as e:
            raise FourAApiError(url, e.code, e.read().decode("utf-8", "replace"))
        return data.get("data") or []

    def job_persons(self, job_code):
        return self.get(self._ep("job_persons", job_code=job_code)) or []

    def peer_candidates(self, scope_level=None, scope_org_code=None, sequence=None,
                        exclude_emp_id=None, name=None, page=1, page_size=500):
        data = self.get(self._ep("peer_candidates"), scopeLevel=scope_level,
                        scopeOrgCode=scope_org_code, sequence=sequence,
                        excludeEmpId=exclude_emp_id, name=name, page=page,
                        pageSize=page_size) or {}
        return data

    def peer_candidates_all(self, scope_level=None, sequence=None):
        """翻页拉全量（scopeLevel 不传 = 全公司；仅 L2/L3/空，无 NONE；含 sequence/jobLevelCode）。"""
        out, page = [], 1
        page_size = 500
        while True:
            data = self.peer_candidates(scope_level, sequence=sequence, page=page, page_size=page_size)
            items = data.get("items") or []
            out.extend(items)
            if not items:
                break
            total = int(data.get("total") or 0)
            if total and len(out) >= total:
                break
            if not total and len(items) < page_size:
                break
            page += 1
        return out


def _ggs_of(job_level_code):
    """4A 无 GGS，恒返回 0（GGS 由薪酬接口补齐）。"""
    return 0


class FourASapAdapter:
    """roster.py 的 SapAdapter 实现：all_people / fetch_person /
    manager_for_org / reports_for_org。

    组织树/人员池有 TTL 缓存（FOURA_CACHE_TTL，默认 24h，4A 每天更新）；
    refresh() 默认仅在过期时清空，force=True 强制重拉。
    """

    def __init__(self, client=None, salary_people=None, salary_client=None, sso_token=""):
        self.client = client or FourAClient()
        # 薪酬接口客户端（接口3）：同级 GGS 比对与薪酬字段来源；可为 None。
        self.salary_client = salary_client
        self.sso_token = sso_token
        self._people = {}
        self._orgs = {}          # org_code -> OrgVO
        self._job_holders = {}   # job_code -> [holder]（岗位查人缓存，兼岗共用）
        self._children = {}      # org_code -> [child_code]
        self._level_names = {}   # org_code -> {L2..L6: org_name}（_fill_org_path 缓存）
        self._level_codes = {}   # org_code -> {L2..L6: org_code}（同级按编码匹配用）
        self._loaded = False
        self._loaded_at = 0.0
        self._org_fallback_skipped = set()
        # 4A 每天更新：默认缓存 24h，避免每次 start 都全量重拉组织树+人员池。
        # 需要更及时可把 FOURA_CACHE_TTL 调小（秒；0=每次重拉）。
        try:
            self.cache_ttl = int(_env("FOURA_CACHE_TTL", "86400") or 86400)
        except ValueError:
            self.cache_ttl = 86400
        self.anomalies = []
        # 根组织：FOURA_ROOT_ORG 可覆盖，默认华星光电
        self.root_org = _env("FOURA_ROOT_ORG", "50016195")

    # ---- 惰性加载 ----
    def _cache_valid(self):
        return (self.cache_ttl > 0 and self._loaded
                and time.time() - self._loaded_at < self.cache_ttl)

    def _ensure_loaded(self):
        if self._cache_valid():
            return
        if self._loaded:
            self._clear_cache()
        self._load()
        self._loaded = True
        self._loaded_at = time.time()

    def _clear_cache(self):
        self._people = {}
        self._orgs = {}
        self._job_holders = {}
        self._children = {}
        self._level_names = {}
        self._level_codes = {}
        self._loaded = False
        self._loaded_at = 0.0
        self._org_fallback_skipped = set()
        self.anomalies = []

    def refresh(self, force=False):
        """按 TTL 刷新缓存：未过期不重拉；force=True 或已过期才清空。"""
        if force or not self._loaded or not self._cache_valid():
            self._clear_cache()
        return self

    def _load(self):
        # 1. 组织树：从根一次 descendants 拉全树（实测 0.2s，替代逐组织祖先链）。
        #    返回顺序不保证父先于子，所以分两遍：先全部入索引，再统一上溯建 L2-L6 映射。
        tree_failed = False
        try:
            for org in self.client.org_descendants(self.root_org):
                self._index_org(org)
            # descendants 不含根本身，补上
            if self.root_org not in self._orgs:
                try:
                    self._index_org(self.client.org(self.root_org))
                except FourAApiError:
                    pass
            for code in list(self._orgs):
                self._build_level_map(code)
        except FourAApiError:
            tree_failed = True
        if tree_failed and not self._orgs:
            # 根树都拉不到时不要按人员组织逐个补链（会放大成请求风暴），直接抛错兜底
            raise FourAApiError(self.root_org, "org_tree_unavailable",
                                "4A 组织树加载失败")

        # 2. 人员池：优先 peer-candidates（scopeLevel 不传 = 全公司；官方只认
        #    L2/L3/空，传 NONE 会被拒；服务端已排除 O / 非在职）；
        #    接口不可用时回退 /persons 翻页（此时序列默认 P，靠薪酬接口覆盖）。
        try:
            raw_people = self.client.peer_candidates_all()
        except FourAApiError:
            raw_people = self.client.persons_all()
        for raw in raw_people:
            p = self._to_person(raw)
            if p:
                self._people[p["emp_id"]] = p

        # 3. 兜底：人员所在组织若不在根树里（如孤儿组织的上级缺失），
        #    逐个拉祖先链补齐（有缓存，只补缺的）；数量异常时设上限，避免请求风暴。
        org_codes = sorted({p["org_code"] for p in self._people.values()
                            if p.get("org_code") and p["org_code"] not in self._orgs})
        try:
            max_fallback = int(_env("FOURA_ORG_FALLBACK_MAX", "50") or 50)
        except ValueError:
            max_fallback = 50
        if max_fallback >= 0 and len(org_codes) > max_fallback:
            self.anomalies.append(("org_fallback_skipped", len(org_codes)))
            self._org_fallback_skipped = set(org_codes[max_fallback:])
            org_codes = org_codes[:max_fallback]
        else:
            self._org_fallback_skipped = set()
        for org_code in org_codes:
            self._load_org_chain(org_code)

        # 4. 管理者不在此全量构建——改为 manager_for_org 里按需惰性解析
        #    （全量 1500+ 次岗位查人只有目标组织的 1-2 个会被用到）

    def _index_org(self, org):
        """把一个 OrgVO 放进 _orgs / _children（L2-L6 映射由 _build_level_map 统一建）。"""
        code = str(org.get("orgCode") or "")
        if not code:
            return
        if code not in self._orgs:
            self._orgs[code] = org
            parent = str(org.get("parentOrgCode") or "")
            if parent:
                self._children.setdefault(parent, []).append(code)

    def _build_level_map(self, org_code):
        """沿 parentOrgCode 上溯，建 {L2..L6: 名称/编码} 映射（幂等，可多次调用）。"""
        code = str(org_code)
        cur = self._orgs.get(code)
        if cur is None:
            return
        by_name = dict(self._level_names.get(code) or {})
        by_code = dict(self._level_codes.get(code) or {})
        guard = 0
        while cur is not None and guard < 10:
            lv = str(cur.get("actualLevel") or "")
            if lv and lv not in by_code:
                by_name[lv] = cur.get("orgName")
                by_code[lv] = cur.get("orgCode")
            parent_code = str(cur.get("parentOrgCode") or "")
            if not parent_code:
                break
            cur = self._orgs.get(parent_code)
            guard += 1
        self._level_names[code] = by_name
        self._level_codes[code] = by_code

    def _load_org_chain(self, org_code):
        """拉 org 及其祖先链（根树缺失时的兜底），建立各索引。"""
        if org_code in self._level_names and org_code in self._orgs:
            return
        try:
            chain = [self.client.org(org_code)] + (self.client.org_ancestors(org_code) or [])
        except FourAApiError:
            self._level_names.setdefault(org_code, {})
            self._level_codes.setdefault(org_code, {})
            return
        for org in chain:
            self._index_org(org)
        for org in chain:
            code = str(org.get("orgCode") or "")
            if code:
                self._build_level_map(code)

    def _manager_of_org(self, org_code):
        """惰性解析一个组织的管理者。

        口径（2026-11-19 实测定稿）：优先走 4A 官方 leader-candidates 接口
        （组织负责人候选，服务端按 chargeMark 直出正确的人——如「广州制造革新科」
        数据里 chargeLeaderJobCode 为空、parentLeaderJobCode 指向的是上级部长岗，
        若按岗位链兜底会错圈成「制造革新部部长」而非本科科长）。leader-candidates
        不可用/为空时，回退岗位链：charge 优先，parent 兜底；岗位-人员关系含
        兼岗（PART_TIME），按 job_persons 查人不按主岗过滤。
        多候选按 anomalies 记录并返回 None（交上层「直接上级岗位为空」口径，不猜测）。
        """
        org_code = str(org_code)
        org = self._orgs.get(org_code)
        if not org:
            return None

        def _resolve(holders, via):
            if len(holders) == 1:
                emp_id = str(holders[0]["empId"])
                if emp_id not in self._people:
                    p = self._to_person(holders[0])
                    if p:
                        self._people[emp_id] = p
                return emp_id
            if len(holders) > 1:
                note = ("org_manager_person_not_unique", org_code, len(holders), via)
                if note not in self.anomalies:
                    self.anomalies.append(note)
            return None

        # 1) 4A 官方：组织负责人候选（正确层级语义）。
        #    官方接口给出候选即以它为准：单人直接用；多人不猜测（记 anomalies 返回
        #    None），均不再走岗位链兜底（避免错圈到上级组织负责人）。
        try:
            cands = [c for c in self.client.leader_candidates(org_code) if c.get("empId")]
        except FourAApiError:
            cands = []
        if cands:
            return _resolve(cands, "leader_candidates")

        # 2) 回退：岗位链（charge 优先，parent 兜底）
        job_code = str(org.get("chargeLeaderJobCode") or org.get("parentLeaderJobCode") or "")
        if not job_code:
            return None
        if job_code in self._job_holders:
            holders = self._job_holders[job_code]
        else:
            try:
                holders = [c for c in self.client.job_persons(job_code) if c.get("empId")]
            except FourAApiError:
                holders = []
            self._job_holders[job_code] = holders
        return _resolve(holders, "job_persons")

    # ---- 字段映射 ----
    def _to_person(self, raw):
        """PeerCandidateVO / PersonVO → Skill 人员结构。"""
        emp_id = str(raw.get("empId") or "")
        if not emp_id:
            return None
        seq = (raw.get("sequence") or "").strip().upper()
        if seq not in ("M", "P", "T"):
            # PersonVO 无 sequence：回退默认 P（薪酬接口会覆盖）
            seq = "P"
        level_code = str(raw.get("jobLevelCode") or raw.get("jobLevelText") or "")
        ggs = raw.get("ggs")
        person = {
            "emp_id": emp_id,
            "name": raw.get("name") or "",
            "org_code": str(raw.get("orgCode") or raw.get("unitCode") or ""),
            "org_name": raw.get("orgName") or raw.get("unitName") or "",
            "job_code": str(raw.get("jobCode") or ""),
            "post": raw.get("jobName") or "",
            "seq": seq,
            "job_level_code": level_code,
            "ggs": ggs or _ggs_of(level_code),
            "employee_status": str(raw.get("employeeStatus") or ""),
            # 薪酬字段默认 0，由 load_salary / fetch_salary 合并填充
            "fixed": None, "bonus_base": 0, "last_bonus": 0, "last_lti": 0,
            "months": 13, "manager_id": "",
        }
        if ggs:
            # 接口真给了 GGS（peer-candidates 的 ggs 字段），视为可信
            person["ggs_source"] = "4a"
        return person

    def load_salary(self, salary_people):
        """合并薪酬接口数据（同 FourAAdapter 的 salary_people 语义：薪酬字段为准）。"""
        by_id = {str(p.get("emp_id")): p for p in (salary_people or []) if p.get("emp_id")}
        for emp_id, sal in by_id.items():
            p = self._people.get(emp_id)
            if p is None:
                p = {
                    "emp_id": emp_id, "name": sal.get("name", ""), "org_code": "",
                    "org_name": "", "job_code": "", "post": sal.get("post", ""),
                    "seq": sal.get("seq", "P"), "job_level_code": "",
                    "ggs": sal.get("ggs", 0), "employee_status": "",
                    "manager_id": "",
                }
                self._people[emp_id] = p
            # 薪酬字段覆盖
            self._merge_one_salary(p, sal)
        return self

    def _merge_one_salary(self, p, sal):
        """薪酬记录覆盖 4A 人员字段（load_salary / fetch_salary 共用）。"""
        p["hasPermission"] = sal.get("hasPermission")
        p["fixed"] = sal.get("fixed") if p["hasPermission"] is not False else None
        if p["hasPermission"] is False:
            return
        for key in ("name", "seq", "ggs", "l2", "l3", "l4", "l5", "l6", "org_path",
                    "post", "city", "months", "bonus_base", "last_bonus",
                    "last_lti", "resident", "perf1", "perf2", "perf3", "nine_box",
                    "bp", "bp_head", "manager_id"):
            if sal.get(key) not in (None, ""):
                p[key] = sal[key]
        # 薪酬接口的 seq 优先（与 FourAAdapter._seq_of 口径一致）
        if str(sal.get("seq") or "") in ("M", "P", "T"):
            p["seq"] = sal["seq"]
        if sal.get("ggs"):
            p["ggs_source"] = "salary"

    def fetch_salary(self, emp_ids, batch=50):
        """按工号批量查薪酬接口3，合并进人员池；返回 {emp_id: 薪酬人员}。

        - 已有薪酬数据（fixed>0）的人不重复查询
        - 单批失败只跳过该批，不阻塞整体（失败的人 fixed 保持 0）
        - 薪酬接口有但 4A 人员池没有的工号也保留（供方案/名单展示）
        """
        if not self.salary_client:
            return {}
        ids, seen = [], set()
        for eid in (emp_ids or []):
            eid = str(eid or "").strip()
            if not eid or eid in seen:
                continue
            seen.add(eid)
            p = self._people.get(eid)
            if p and (p.get("fixed") or 0) > 0:
                continue  # 已合并过
            ids.append(eid)
        out = {}
        for i in range(0, len(ids), batch):
            chunk = ids[i:i + batch]
            try:
                rows = self.salary_client.list_salary(chunk, self.sso_token)
            except Exception:
                continue  # 单批失败不阻塞；缺失的人保持 4A 数据
            from adapters.salary import to_person
            merged_salary = []
            for item in rows:
                sal = to_person(item)
                if sal.get("emp_id"):
                    out[str(sal["emp_id"])] = sal
                    merged_salary.append(sal)
            self.load_salary(merged_salary)
        return out

    # ---- roster.py 需要的接口 ----
    def _fill_org_path(self, p):
        """按组织祖先链补 l2-l6 / org_path（薪酬接口没给时用，带缓存）。

        l2-l6 同时补名称（l2/l3/...）和编码（l2_code/l3_code/...）：
        roster 同级匹配用编码，展示用名称。
        """
        if p.get("l2"):
            return
        org_code = str(p.get("org_code") or "")
        if not org_code:
            return
        self._ensure_loaded()
        if org_code in self._org_fallback_skipped:
            # 根树缺失的孤儿组织超过兜底上限：不再逐人补链，避免请求风暴
            return
        by_name = self._level_names.get(org_code)
        by_code = self._level_codes.get(org_code)
        if by_name is None or by_code is None:
            self._load_org_chain(org_code)
            by_name = self._level_names.get(org_code) or {}
            by_code = self._level_codes.get(org_code) or {}
        for i in range(2, 7):
            p.setdefault("l%d" % i, by_name.get("L%d" % i, "") or "")
            p.setdefault("l%d_code" % i, by_code.get("L%d" % i, "") or "")
        p["org_path"] = "/".join(x for x in (p.get("l2"), p.get("l3"), p.get("l4"),
                                             p.get("l5"), p.get("l6")) if x)

    def all_people(self):
        self._ensure_loaded()
        people = list(self._people.values())
        for p in people:
            self._fill_org_path(p)
        return people

    def fetch_person(self, emp_id):
        self._ensure_loaded()
        p = self._people.get(str(emp_id))
        if p:
            self._fill_org_path(p)
            return p
        # 人员池（peer-candidates）可能不含新入职/外借人员：按 4A person-detail 补查一次
        try:
            raw = self.client.person(str(emp_id))
        except FourAApiError:
            raw = None
        if not raw:
            return None
        p = self._to_person(raw)
        if not p:
            return None
        self._fill_org_path(p)
        self._people[p["emp_id"]] = p
        return p

    def manager_for_org(self, org_code, seq):
        """按「调整后组织编码」取上级：M → 父组织管理者；P/T → 本组织管理者。"""
        self._ensure_loaded()
        org = self._orgs.get(str(org_code))
        if not org:
            return None
        target = str(org.get("parentOrgCode") or "") if seq == "M" else str(org_code)
        # 父组织可能不在根树（根 descendants 不含根本身 / 孤儿组织），先补索引
        if target and target not in self._orgs:
            self._load_org_chain(target)
        mgr = self._manager_of_org(target) if target else None
        return self._people.get(mgr) if mgr else None

    def reports_for_org(self, org_code, seq, exclude_emp_id=None):
        """M：本组织及下级组织所有人；P/T：空。（/descendants 含自身，语义一致）"""
        if seq != "M":
            return []
        self._ensure_loaded()
        exclude = str(exclude_emp_id or "")
        orgs = {str(org_code)}
        for org in self.client.org_descendants(org_code):
            code = str(org.get("orgCode") or "")
            if code:
                orgs.add(code)
        return [p for p in self._people.values()
                if p.get("org_code") in orgs and p["emp_id"] != exclude]

    def find_by_name(self, name):
        """按姓名精确查人（调薪 start 支持姓名开单用）。返回人员列表（可能多人同名）。

        优先服务端 persons?name= 模糊查询（2026-11-19 新接口，服务端已过滤
        在职/非 O），结果里再做姓名精确匹配；服务端未按 name 过滤（旧版本
        total>len(items)）或接口异常时，回退内存池精确匹配（口径不变）。
        """
        key = (name or "").strip()
        if not key:
            return []
        try:
            data = self.client.persons_page(name=key, page=1, page_size=500)
            items = data.get("items") or []
            total = int(data.get("total") or 0)
            if total <= len(items):
                return [p for p in (self._to_person(raw) for raw in items)
                        if p and p.get("name") == key]
        except FourAApiError:
            pass
        self._ensure_loaded()
        return [p for p in self._people.values() if p.get("name") == key]

    def org_codes_at_level(self, org_code, level):
        """取 org_code 祖先链上 level（如 L3）的组织编码；取不到返回 ''。"""
        self._ensure_loaded()
        org_code = str(org_code or "")
        codes = self._level_codes.get(org_code)
        if codes is None:
            self._load_org_chain(org_code)
            codes = self._level_codes.get(org_code) or {}
        return codes.get(level, "") or ""

    # ---- 组织名称 → 编码（调薪转组织 / 定薪入职组织用） ----
    @staticmethod
    def _parent_level(level):
        """actualLevel → 直接父级的层级键（L6→L5、L3→L2；L2 及解析失败返回 None）。"""
        s = str(level or "").strip().upper().lstrip("L")
        try:
            n = int(s)
        except ValueError:
            return None
        return "L%d" % (n - 1) if n > 2 else None

    def resolve_org(self, name, limit=20):
        """按组织名查组织。返回 OrgVO 列表（cOrgCode/cOrgName 兼容旧字段）。

        - 精确同名优先；无精确命中时再包含匹配
        - 路径式输入 "L2名/L3名/…/末级名"：**从末级起逐级与输入段全等比对**
          （末级=精确名、倒数第二级=直接父级、再往上每级都比）——4A 同名组织
          约 49 组，同名可能贯穿多层，只比直接父级会收窄失败；完整路径必须
          能匹配到唯一。
        - 仍多命中交由调用方消歧，不静默二选一
        """
        name = (name or "").strip().rstrip("/")
        if not name:
            return []
        self._ensure_loaded()
        # 支持路径式输入 "L2名/L3名/L4名"：按最后一级名先筛，再用父路径逐级收窄
        parts = [x.strip() for x in name.split("/") if x.strip()]
        tail = parts[-1] if parts else name
        exact = [o for o in self._orgs.values()
                 if (o.get("orgName") or "").strip() == tail]
        matches = exact or [o for o in self._orgs.values()
                            if tail in (o.get("orgName") or "")]
        if exact and len(parts) >= 2:
            # 有父路径：从直接父级起逐级向上与输入段全等比对，
            # 输入给了几级就比几级；末级唯一但父路径对不上时也不静默采用
            root = self._orgs.get(str(self.root_org)) or {}
            root_name = (root.get("orgName") or "").strip()
            narrowed = []
            for o in exact:
                code = str(o.get("orgCode") or "")
                names = self._level_names.get(code) or {}
                lv = self._parent_level(o.get("actualLevel"))   # 直接父级层键
                ok = True
                # parts 去掉末级后倒序，与候选的祖先链逐级比对
                for seg in reversed(parts[:-1]):
                    if lv is None:
                        # 已到 L2 之上：允许完整路径最前面带一个根组织名（L1）
                        if root_name and seg == root_name:
                            break
                        ok = False
                        break
                    want = names.get(lv, "")
                    if want != seg:
                        ok = False
                        break
                    lv = self._parent_level(lv)
                if ok:
                    narrowed.append(o)
            if narrowed:
                matches = narrowed
            elif len(exact) == 1:
                # 末级唯一但完整路径与其祖先不一致：不采用错误组织，交给上层提示重输
                matches = []
        # 按组织层级深浅排序（浅的先出，通常是用户想要的口径）
        matches.sort(key=lambda o: int(o.get("orgLevel") or 0))
        out = []
        for o in matches[:limit]:
            out.append({
                "cOrgCode": o.get("orgCode"),
                "cOrgName": o.get("orgName"),
                "orgCode": o.get("orgCode"),
                "orgName": o.get("orgName"),
                "actualLevel": o.get("actualLevel"),
                "parentOrgCode": o.get("parentOrgCode"),
            })
        return out

    def org_l2_l3(self, org_code):
        """组织编码 → (L2 名称, L3 名称)；取不到为 ''。"""
        self._ensure_loaded()
        org_code = str(org_code or "")
        names = self._level_names.get(org_code)
        if names is None:
            self._load_org_chain(org_code)
            names = self._level_names.get(org_code) or {}
        return names.get("L2", "") or "", names.get("L3", "") or ""

    def org_path(self, org_code):
        """组织编码 → 完整路径 L2/L3/L4/L5/L6（无 L1）。"""
        self._ensure_loaded()
        org_code = str(org_code or "")
        names = self._level_names.get(org_code)
        if names is None:
            self._load_org_chain(org_code)
            names = self._level_names.get(org_code) or {}
        return "/".join(names.get("L%d" % i, "") for i in range(2, 7)
                        if names.get("L%d" % i, ""))

    def _resolve_ambiguous(self, matches):
        """多命中的用户提示文本（plan/hire 卡片 footnote 用）。"""
        if len(matches) <= 1:
            return ""
        names = ["%s(%s)" % (m.get("cOrgName"), m.get("cOrgCode")) for m in matches[:5]]
        more = "" if len(matches) <= 5 else " 等 %d 个" % len(matches)
        return "组织「%s」有 %d 个同名匹配：%s%s，请说明是哪一个（可用完整路径）。" % (
            matches[0].get("cOrgName", ""), len(matches),
            "、".join(names), more)


def build_adapters(salary_people=None, client=None, operator="", role=None,
                   salary_client=None, sso_token="", salary_cred=None,
                   base_url="", gateway="", foura_api_token="", environment=None):
    """便捷工厂：返回 (sap, auth, baseline)。

    - sap：FourASapAdapter（组织/上下级 + 合并薪酬）
    - auth：薪酬系统的 AuthAdapter（BP/COE 校验）
    - baseline：占位
    - salary_cred：薪酬凭据 {appId/secret/aesKey/rsaPublic}（可含 rsaPrivate），
      通常由 adapters.build 经 getSsoConfig 拉取后传入；
      薪酬接口一律直连 PMS（base_url + /external/...）。
    - gateway：4A 直连 base（默认内置部署版地址，沿用旧参数名）。
    """
    from .salary import AuthAdapter as SalaryAuthAdapter, BaselineAdapter as SalaryBaseline
    from salary_api import SalaryApiClient
    mode = deployment_mode(environment)
    directory_client = client or FourAClient(base_url=gateway or None,
                                             api_token=foura_api_token or None, environment=mode)
    client_sal = salary_client
    if client_sal is None:
        base_url = endpoint(base_url, "SALARY_BASE_URL", mode, TEST_PMS)
        client_sal = SalaryApiClient.from_cred(
            salary_cred or {}, base_url=base_url or "", sso_token=sso_token)
    auth = SalaryAuthAdapter(client_sal,
                             operator=os.environ.get("SALARY_OPERATOR_CODE", "") or operator,
                             sso_token=sso_token or os.environ.get("SALARY_SSO_TOKEN", ""),
                             role=role or os.environ.get("SALARY_ROLE", ""))
    baseline = SalaryBaseline()
    sap = FourASapAdapter(client=directory_client,
                          salary_client=client_sal, sso_token=sso_token)
    if salary_people:
        sap.load_salary(salary_people)
    return sap, auth, baseline

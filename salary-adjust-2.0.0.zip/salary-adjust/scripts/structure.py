# -*- coding: utf-8 -*-
"""薪酬基础配置（管理员维护，BP 只读）。

数据源优先级：
  1. config/structure.json（管理员维护，改配置不改代码）
  2. 内置默认值（配置文件缺失/损坏时兜底）

包含：
  - 城市 × GGS 五档（薪酬结构表）
  - 奖金基线占比（按 GGS 分档）
  - 城市分档、调幅区间、五档倍数
"""

import json
import os

CONFIG_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "config", "structure.json")

# ---------------- 内置默认（兜底） ----------------
DEFAULT_TIER1 = {"北京", "上海", "广州", "深圳"}


def _default_grade(tier):
    base, step = (44000, 10000) if tier == "一线" else (39000, 5000)
    table = {}
    for ggs in range(2, 19):
        lv1 = base + (ggs - 2) * step
        table[ggs] = [lv1 + 3000 * i for i in range(5)]
    table[1] = [34000, 37000, 40000, 43000, 46000]
    return table


DEFAULT_GRADE = {"一线": _default_grade("一线"), "二线": _default_grade("二线")}
DEFAULT_BANDS = [
    {"min_ggs": 18, "max_ggs": None, "ratio": 0.50},
    {"min_ggs": 15, "max_ggs": 17, "ratio": 0.40},
    {"min_ggs": 13, "max_ggs": 14, "ratio": 0.30},
    {"min_ggs": 11, "max_ggs": 12, "ratio": 0.20},
    {"min_ggs": 9, "max_ggs": 10, "ratio": 0.15},
    {"min_ggs": 6, "max_ggs": 8, "ratio": 0.12},
    {"min_ggs": None, "max_ggs": 5, "ratio": 0.09},
]


def _load():
    """返回 (grade_table, bands, tier1, ratio_min, ratio_max, grade_cap_factor)。"""
    if not os.path.exists(CONFIG_PATH):
        return (DEFAULT_GRADE, DEFAULT_BANDS, DEFAULT_TIER1, 0.05, 0.30, 1.3)
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            cfg = json.load(f)
        grade = {tier: {int(k): v for k, v in rows.items()}
                 for tier, rows in cfg["grade_table"].items()}
        return (
            grade or DEFAULT_GRADE,
            cfg.get("bonus_ratio_bands") or DEFAULT_BANDS,
            set(cfg.get("tier1_cities") or DEFAULT_TIER1),
            float(cfg.get("ratio_min", 0.05)),
            float(cfg.get("ratio_max", 0.30)),
            float(cfg.get("grade_cap_factor", 1.3)),
        )
    except Exception:
        return (DEFAULT_GRADE, DEFAULT_BANDS, DEFAULT_TIER1, 0.05, 0.30, 1.3)


GRADE_TABLE, _BANDS, TIER1_CITIES, RATIO_MIN, RATIO_MAX, GRADE_CAP_FACTOR = _load()


def city_tier(city):
    c = (city or "").strip()
    if not c:
        return "二线"   # 城市缺失按二线兜底（定薪流程必填卡会先拦住空城市）
    # 接口可能返回“一线/二线”档位，也可能返回具体城市
    if c in ("一线", "二线"):
        return c
    if c.endswith("市"):
        c = c[:-1]
    return "一线" if c in TIER1_CITIES else "二线"


def grade_band(city, ggs):
    g = int(ggs) if ggs else 0
    return GRADE_TABLE[city_tier(city)].get(g)


def grade_third(city, ggs):
    band = grade_band(city, ggs)
    return band[2] if band else None


def standard_bonus_ratio(ggs):
    g = int(ggs)
    for b in _BANDS:
        lo, hi = b.get("min_ggs"), b.get("max_ggs")
        if (lo is None or g >= lo) and (hi is None or g <= hi):
            return b["ratio"]
    return _BANDS[-1]["ratio"]

def parse_grade(value):
    """The platform accepts whole grades from 1 to 30."""
    text = str(value).strip()
    if text.isascii() and text.isdigit() and 1 <= int(text) <= 30:
        return int(text)
    raise ValueError("职级需为 1–30 的整数。")

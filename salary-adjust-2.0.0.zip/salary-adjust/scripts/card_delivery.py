"""星Claw 卡片参数及投递协议。"""
import json

_CARD_PARAMS_KEYS = {
    "card_salary_info": {"empId", "title", "intro", "beforeOrg", "beforeJob", "beforeLevel",
                         "beforeSeq", "beforeCity", "afterOrg", "afterJob", "afterLevel",
                         "afterSeq", "afterCity", "footnote", "requestId", "sessionId"},
    "card_salary_origin": {"companyName", "jobName", "cityName", "basePay", "salaryMonth",
                           "lastBonus", "lastLti", "footnote", "requestId", "sessionId"},
    "card_salary_post": {"org", "job", "city", "seq", "ggs", "subtitle",
                         "footnote", "requestId", "sessionId"},
    "card_salary_extra": {"cashSubsidy", "cashMemo", "socialMemo", "fundMemo", "ltiMemo",
                          "subtitle", "footnote", "requestId", "sessionId"},
    "card_salary_roster": {"title", "up", "peer", "down", "more", "moreCount",
                           "headnote", "upTitle", "peerTitle", "downTitle",
                           "upRule", "peerRule", "downRule", "footnote",
                           "requestId", "sessionId"},
}


def validate(card):
    if not isinstance(card, dict) or set(card) != {"templateKey", "params"}:
        raise ValueError("卡片结构无效")
    key, params = card["templateKey"], card["params"]
    if key not in _CARD_PARAMS_KEYS or not isinstance(params, dict) or set(params) != _CARD_PARAMS_KEYS[key]:
        raise ValueError("模板或卡片字段无效")
    for name in ("ggs", "beforeLevel", "afterLevel", "salaryMonth"):
        if name in params and type(params[name]) is not int:
            raise ValueError("卡片数值字段类型无效")
    if key == "card_salary_roster":
        for section in ("up", "peer", "down", "more"):
            if not isinstance(params[section], list):
                raise ValueError("名单字段必须为数组")
            for row in params[section]:
                if (not isinstance(row, dict) or set(row) != {"ggs", "code", "name", "removed"}
                        or type(row["removed"]) is not bool
                        or not all(isinstance(row[k], str) for k in ("ggs", "code", "name"))):
                    raise ValueError("名单行格式无效")


def emit(card, bubble=None):
    if card is None:
        return {"bubble": bubble or "", "card": None}
    card = dict(card)
    default = card.pop("text", "")
    validate(card)
    return {"bubble": default if bubble is None else bubble, "card": card}


def question_args(card):
    validate(card)
    params = card["params"]
    key = card["templateKey"]
    if key == "card_salary_origin":
        title = "原单位情况"
    elif key in ("card_salary_post", "card_salary_extra"):
        title = params["subtitle"]
    else:
        title = params["title"]
    return {"question": title, "ext": {"templateKey": key,
            "params": json.dumps(params, ensure_ascii=False, allow_nan=False)}}


def deliver(card, send):
    """send maps the host result to sent/cancelled/transient_failure/failed."""
    args = question_args(card)
    status = send(**args)
    if status == "transient_failure":
        status = send(**args)
    return status

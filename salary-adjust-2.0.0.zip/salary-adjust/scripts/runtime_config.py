"""Deployment endpoints are resolved before any credential request."""
import os
from urllib.parse import urlsplit

TEST_PMS = "http://10.110.20.245"
TEST_4A = "http://testmetis.csot.tcl.com/hr-4a-service"
TEST_SSO = "http://10.110.167.11:32754"


def deployment_mode(value=None):
    mode = (value or os.getenv("SALARY_ENV") or "production").strip().lower()
    if mode not in ("production", "test"):
        raise ValueError("SALARY_ENV 必须为 production 或 test")
    return mode


def setting(value, env):
    return (value or os.getenv(env) or "").strip()


def endpoint(value, env, mode, test_default):
    url = setting(value, env) or (test_default if mode == "test" else "")
    parsed = urlsplit(url)
    if not parsed.hostname or parsed.scheme not in ("http", "https"):
        raise ValueError("请配置有效的服务地址 " + env)
    if mode == "production" and parsed.scheme != "https":
        raise ValueError("生产环境需要 HTTPS 地址 " + env)
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("服务地址格式无效 " + env)
    return url.rstrip("/")

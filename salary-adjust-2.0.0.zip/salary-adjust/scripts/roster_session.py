"""Authorization, salary samples and public roster views used by both sessions."""
import math

import calc
import roster
from adapters.salary import to_person


def has_fixed(person):
    value = person.get("fixed")
    return isinstance(value, (float, int)) and math.isfinite(value) and value > 0


def identity(person):
    return {k: person[k] for k in ("emp_id", "name")}


def card_person(row):
    grade = row.get("ggs") if row.get("visible") else None
    return {"ggs": str(grade) if grade else "", "code": row["emp_id"],
            "name": row["name"], "removed": bool(row.get("removed"))}


class RosterSession:
    def _recheck(self):
        rows = [row for sec in self.sections for row in sec["people"]]
        verdict = roster._permission_map(self.auth, [r["_raw"] for r in rows], fresh=True)
        for sec in self.sections:
            kept = []
            for row in sec["people"]:
                decision = verdict.get(str(row["emp_id"]))
                allowed = bool(decision and decision.get("allowed"))
                if not allowed and sec["key"] != "upper":
                    continue
                row["visible"] = allowed
                row["note"] = ""
                if not allowed:
                    row["note"] = ("未在你的薪酬权限范围内，不提供上级薪酬信息" if decision
                                   else "上级薪酬权限未核实，暂不提供上级薪酬信息")
                    row["_raw"] = identity(row)
                    row["ggs"] = None
                    row["org"] = row["seq"] = ""
                kept.append(row)
            sec["people"] = kept
            sec["count"] = sum(not row["removed"] for row in kept)

    def _ensure_salary(self, batch=50, force=False):
        """Resolve missing salaries in visible rows. Exclude failed reads from this sample."""
        rows = [row for sec in self.sections for row in sec["people"]
                if row.get("visible") and not row.get("removed")]
        ids = list(dict.fromkeys(str(row["emp_id"]) for row in rows
                                 if force or not has_fixed(row["_raw"])))
        salaries = {}
        if self.salary_client:
            for i in range(0, len(ids), batch):
                chunk = ids[i:i + batch]
                try:
                    records = self.salary_client.list_salary(chunk, self.sso_token)
                except Exception:
                    continue
                for record in records:
                    person = to_person(record)
                    if person["emp_id"] in chunk:
                        salaries[person["emp_id"]] = person

        denied = set()
        missing = set()
        for row in rows:
            eid = str(row["emp_id"])
            sal = salaries.get(eid)
            raw = row["_raw"]
            if sal is not None and sal.get("hasPermission") is False:
                denied.add(eid)
                row["_raw"] = identity(row)
                row.update(visible=False, ggs=None, org="", seq="",
                           note="未在你的薪酬权限范围内，不提供上级薪酬信息")
                continue
            if sal is not None:
                merged = {**raw, **sal}
                for key in ("name", "org_code", "l2", "l3", "l4", "manager_id"):
                    if raw.get(key):
                        merged[key] = raw[key]
                row["_raw"] = raw = merged
                row.update(name=raw["name"], ggs=raw["ggs"], seq=raw["seq"])
            if not has_fixed(raw):
                missing.add(eid)
        if denied:
            for sec in self.sections:
                if sec["key"] != "upper":
                    sec["people"] = [r for r in sec["people"] if str(r["emp_id"]) not in denied]
                    sec["count"] = sum(not r["removed"] for r in sec["people"])
        self._missing_salary = sorted(missing)
        return self._missing_salary

    def _sample_rows(self, key):
        return [calc.person_row(r["_raw"], r.get("ggs"))
                for sec in self.sections if sec["key"] == key
                for r in sec["people"] if r.get("visible") and not r.get("removed")
                and has_fixed(r["_raw"])]

    def _peer_rows(self):
        return self._sample_rows("peer")

    def _upper(self):
        for sec in self.sections:
            if sec["key"] != "upper":
                continue
            for row in sec["people"]:
                if row.get("removed"):
                    continue
                if row.get("visible") and has_fixed(row["_raw"]):
                    return row["_raw"], row["_raw"]["fixed"]
                return identity(row), None
        return None, None

    def _public_sections(self):
        return [{**sec, "people": [card_person(r) for r in sec["people"]]}
                for sec in self.sections]

    def _sample_counts(self):
        return {sec["key"]: {"valid": sum(has_fixed(r["_raw"]) for r in sec["people"]
                                           if r.get("visible") and not r.get("removed")),
                             "missing": sum(not has_fixed(r["_raw"]) for r in sec["people"]
                                            if r.get("visible") and not r.get("removed"))}
                for sec in self.sections}

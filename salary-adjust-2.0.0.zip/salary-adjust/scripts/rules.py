# -*- coding: utf-8 -*-
"""规则校验：底线（硬）+ 参考原则（软）。

每条规则一个函数，统一返回结构：
  {no, kind: 'hard'|'ref', name, res: 'pass'|'fail'|'unchecked'|'info', note, suggest}
`RULES` 注册表顺序即执行顺序。改/加规则只动本文件。
"""

from structure import grade_band, RATIO_MIN, RATIO_MAX


def rule_ratio_band(ctx):
    r = ctx["ratio"]
    ok = RATIO_MIN <= r <= RATIO_MAX
    return {
        "no": "底线1", "kind": "hard", "name": "调薪涨幅 5%~30%",
        "res": "pass" if ok else "fail",
        "note": "当前 %.1f%%" % (r * 100),
        "suggest": "" if ok else "建议落在 %.0f%%~%.0f%%" % (RATIO_MIN * 100, RATIO_MAX * 100),
    }


def rule_not_over_upper(ctx):
    upper = ctx.get("upper_fixed")
    cur = ctx.get("cur_fixed")
    new = ctx.get("new_fixed")
    if upper is None or cur is None:
        return {
            "no": "底线2", "kind": "hard", "name": "调后固薪 ≤ 上级固薪",
            "res": "unchecked", "note": "上级薪酬不可见或无上级", "suggest": "",
        }
    if cur > upper:
        return {
            "no": "底线2", "kind": "hard", "name": "调后固薪 ≤ 上级固薪",
            "res": "unchecked", "note": "当前固薪已高于上级固薪，不适用", "suggest": "",
        }
    ok = new <= upper
    return {
        "no": "底线2", "kind": "hard", "name": "调后固薪 ≤ 上级固薪",
        "res": "pass" if ok else "fail",
        "note": "调后 %.0f / 上级 %.0f" % (new, upper),
        "suggest": "" if ok else "请调低涨幅，或提交人工审批。",
    }


def ref_not_over_peer_avg(ctx):
    avg = ctx.get("peer_avg_fixed")
    if not avg:
        return {"no": "参考1", "kind": "ref", "name": "不超同层级平均", "res": "info",
                "note": "无同层级数据", "suggest": ""}
    if ctx.get("cur_fixed", 0) > avg:
        return {"no": "参考1", "kind": "ref", "name": "不超同层级平均", "res": "info",
                "note": "当前固薪已高于同级平均，不适用该参考", "suggest": ""}
    ok = ctx["new_fixed"] <= avg
    return {"no": "参考1", "kind": "ref", "name": "不超同层级平均",
            "res": "pass" if ok else "info",
            "note": "调后 %.0f / 同级平均 %.0f" % (ctx["new_fixed"], avg),
            "suggest": "" if ok else "同级参考 %.0f" % avg}


def ref_grade_cap(ctx):
    band = grade_band(ctx["city"], ctx["new_ggs"])
    if band is None:
        return {"no": "参考2", "kind": "ref", "name": "五档不超过", "res": "unchecked",
                "note": "GGS %s 缺少薪酬结构档位，竞争力和五档均未校验" % ctx["new_ggs"],
                "suggest": "请核实该职级的薪酬结构表"}
    cap = band[4]
    ok = ctx["new_fixed"] <= cap
    return {"no": "参考2", "kind": "ref", "name": "五档不超过",
            "res": "pass" if ok else "info",
            "note": "调后 %.0f / 五档 %.0f" % (ctx["new_fixed"], cap),
            "suggest": "" if ok else "结构表口径待复核"}


RULES = [rule_ratio_band, rule_not_over_upper, ref_not_over_peer_avg,
         ref_grade_cap]


def run_checks(ctx):
    return [f(ctx) for f in RULES]


def report_checks(checks):
    return [c for c in checks if c["res"] in ("fail", "unchecked")
            or (c["kind"] == "ref" and c.get("suggest"))]


def summary(checks):
    failed = [c["name"] for c in checks if c["kind"] == "hard" and c["res"] == "fail"]
    pending = [c for c in checks if c["res"] == "unchecked"]
    parts = []
    if failed:
        parts.append("有 %d 条底线没过（%s），请调整或提交人工审批。" %
                     (len(failed), "、".join(failed)))
    if pending:
        details = "、".join("%s：%s" % (c["name"], c["note"]) for c in pending)
        parts.append("有 %d 项未校验（%s）。" % (len(pending), details))
    return "".join(parts) or "方案好了，底线都过了。"

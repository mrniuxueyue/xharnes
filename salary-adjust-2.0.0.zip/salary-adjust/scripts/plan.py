# -*- coding: utf-8 -*-
"""调薪状态机（四步：权限 → 信息 → 名单 → 方案）。"""

import datetime
import importlib.util
import urllib.error
from pathlib import Path

import roster as roster_mod
from card_delivery import emit as _emit
import calc
import rules
from roster_session import RosterSession, card_person
from structure import parse_grade, standard_bonus_ratio


def _load_export():
    """只加载本 Skill 的 export.py，避免两个 Skill 同名模块串用。

    openpyxl 缺失只影响导出，不能拖垮 start/confirm 等前置流程：
    模块级延迟到首次调用时再执行（exec_module 放到调用时），导入失败返回 None，
    由调用方按话术表兜底（「方案文件暂时无法生成」）。
    """
    path = Path(__file__).resolve().with_name("export.py")
    spec = importlib.util.spec_from_file_location("salary_adjust_export", str(path))
    mod = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(mod)
    except ImportError:
        return None
    return mod


export_mod = _load_export()

STEP_PERM = "perm"
STEP_INFO = "info"
STEP_ROSTER = "roster"
STEP_DONE = "done"

# ---- 异常兜底：任何步骤抛异常都转成标准故障气泡，不把报错裸抛给平台 agent ----
# （agent 拿到裸异常只能自己编话术，历史上编出过「名单暂时拉不出来」「登录状态
#   已过期」等自由发挥；有了兜底，对用户的话永远只有规定的那几句。）
NET_ERR_TEXT = "系统繁忙，请稍后再试。"
GENERIC_ERR_TEXT = "系统暂时出了点问题，请稍后再试；问题持续请联系管理员。"
AUTH_ERR_TEXT = "你的登录状态已过期或未生效，请重新进入对话再试。"
PERM_DENIED_TEXT_ORG = ("组织「%s」不在你的薪酬权限范围内，"
                        "不能作为调薪后组织，请换一个组织。")
NAME_PROMPT_TEXT = "请输入被调薪人的工号或姓名。"

# 鉴权/登录态类错误特征（PMS ssoToken 过期等）：重试无意义，应引导重新进入对话拿新 token
_AUTH_ERR_MARKS = ("SSO验证失败", "validate fail", "token无效", "token已过期",
                   "token 无效", "token 已过期", "401")


def _looks_auth_error(e):
    return any(k in str(e) for k in _AUTH_ERR_MARKS)


def _error_text(e):
    """接口类异常 → 系统繁忙；登录态异常 → 重新登录。"""
    return AUTH_ERR_TEXT if _looks_auth_error(e) else NET_ERR_TEXT


def _looks_like_emp_id(s):
    """工号形态：纯数字，或字母开头的短编码（如 E12345）。不含中文。"""
    if not s or not all(ord(c) < 128 for c in s):
        return False
    return s.isdigit() or (len(s) <= 12 and s[0].isalpha() and s[1:].isdigit())


def _is_chinese_name(s):
    """姓名形态：全中文（长度 2-15，覆盖少数民族姓名）。"""
    return bool(s) and 2 <= len(s) <= 15 and all("\u4e00" <= c <= "\u9fff" for c in s)


def _safe_step(fn):
    def wrapper(self, *args, **kwargs):
        try:
            return fn(self, *args, **kwargs)
        except ImportError:
            # 依赖缺失（如 openpyxl）→ 只影响导出，按话术表回复
            return _emit(None, "方案文件暂时无法生成，请联系管理员。")
        except Exception as e:
            # 技术原因只留内部日志（stderr），用户只见规定话术
            import sys
            import traceback
            print("[step-error] %s: %s" % (fn.__name__, traceback.format_exc()),
                  file=sys.stderr)
            # 四A/网络类错误 → 繁忙话术；登录态异常 → 重新登录；其余 → 通用话术
            from adapters.foura import FourAApiError
            from salary_api import SalaryApiError
            auth = _looks_auth_error(e)
            # 4A 的 401 是共享令牌配置问题，不是用户登录态过期
            if isinstance(e, FourAApiError):
                return _emit(None, NET_ERR_TEXT)
            if isinstance(e, SalaryApiError):
                return _emit(None, AUTH_ERR_TEXT if auth else NET_ERR_TEXT)
            if isinstance(e, (urllib.error.URLError, OSError)):
                return _emit(None, NET_ERR_TEXT)
            if auth:
                # 登录态过期：让用户重试「稍后再试」是死路，正确动作是重新进入对话拿新 token
                return _emit(None, AUTH_ERR_TEXT)
            return _emit(None, GENERIC_ERR_TEXT)
    wrapper.__name__ = fn.__name__
    wrapper.__doc__ = fn.__doc__
    return wrapper


def _guard_all_steps(cls):
    for name, fn in list(vars(cls).items()):
        if (name.startswith("STEP_") or name.startswith("_")
                or not callable(fn) or getattr(fn, "__module__", "") != __name__):
            continue
        setattr(cls, name, _safe_step(fn))
    return cls

EDIT_KEYS = {
    # 接口字段名（与薪酬系统一致）
    "l2": "l2", "jobName": "post", "jobSequence": "seq",
    "empLevel": "ggs", "cityType": "city",
    # 卡片 params 键（平台 event.form 按卡片字段回传时也能落库）
    "afterOrg": "l2", "afterJob": "post", "afterLevel": "ggs",
    "afterSeq": "seq", "afterCity": "city",
    "afterorg": "l2", "afterjob": "post", "afterlevel": "ggs",
    "afterseq": "seq", "aftercity": "city",
    # 卡片上的中文标签（用户会照着卡片说「职级改成 13」）
    "组织": "l2", "岗位": "post", "序列": "seq",
    "职级": "ggs", "驻地城市": "city", "城市": "city",
    # 兼容旧字段名
    "org": "l2", "post": "post", "seq": "seq", "ggs": "ggs",
    "location": "city", "city": "city",
    "months": "months", "salary13Or12": "months",
    "13薪/12薪": "months", "12薪": "months", "13薪": "months",
    "薪数": "months", "薪酬月数": "months",
}


def _today():
    return datetime.date.today().strftime("%Y%m%d")

# 权限校验未通过时的统一话术：只回文字、不出卡片
PERM_DENIED_TEXT = "你没有该员工的薪酬权限。"
# GGS 合法区间（与定薪岗位卡一致）
GGS_MIN, GGS_MAX = 1, 30

# 国籍代码映射（薪酬台账 nationality 为代码值 CN/HK/KR/TW/US…）：
# 用户口语「中国/中国籍」按大中华口径 = CN+HK+TW+MO；其余中文名/代码值精确展开。
_NAT_CN = {"CN", "HK", "TW", "MO"}
_NAT_ALIAS = {
    "中国": _NAT_CN, "中国籍": _NAT_CN, "大陆": {"CN"}, "中国大陆": {"CN"},
    "内地": {"CN"}, "香港": {"HK"}, "中国香港": {"HK"}, "台湾": {"TW"},
    "中国台湾": {"TW"}, "澳门": {"MO"}, "韩国": {"KR"}, "美国": {"US"},
    "日本": {"JP"}, "新加坡": {"SG"},
    "CN": {"CN"}, "HK": {"HK"}, "TW": {"TW"}, "MO": {"MO"}, "KR": {"KR"},
    "US": {"US"}, "JP": {"JP"}, "SG": {"SG"},
}


def _nationality_codes(text):
    """「中国/中国籍/中国香港/CN/HK…」→ 国籍代码集合；不识别返回空集。"""
    key = str(text or "").strip().upper()
    if key in _NAT_ALIAS:            # 代码值直接命中（upper 后）
        return set(_NAT_ALIAS[key])
    return set(_NAT_ALIAS.get(str(text or "").strip(), set()))



@_guard_all_steps
class Session(RosterSession):
    def __init__(self, operator="", sap=None, auth=None, baseline=None,
                 initiator_name=None, salary_client=None, sso_token=""):
        self.operator = operator
        self.initiator_name = initiator_name
        self.sap = sap
        self.auth = auth
        self.baseline = baseline
        # 4a 模式下 sap.client 是 4A 客户端（没有 list_salary），不能用；
        # 薪酬客户端显式传入 > sap.salary_client（4A 适配层）> 薪酬适配层的 sap.client
        self.salary_client = (salary_client or getattr(sap, "salary_client", None)
                              or (getattr(sap, "client", None)
                                  if hasattr(getattr(sap, "client", None), "list_salary")
                                  else None))
        self.sso_token = sso_token or getattr(sap, "sso_token", "") or getattr(auth, "sso_token", "")
        self.step = None
        self.person = None
        self.before = None
        self.after = None
        self.sections = []
        self.audit = []
        self.confirmed_at = None
        self.roster_locked = False
        self.bundle = None
        self.ratio = None
        self.user_ratio = None   # 用户显式指定的涨幅（done 后改名单重出方案时保持）
        self._missing_salary = []

    # ---------------- 1. 权限 ----------------
    def start(self, emp_id=""):
        """入口：emp_id 接受工号或姓名。

        - 纯数字/字母数字混合且像工号 → 按工号走原流程
        - 中文姓名 → 4A 人员池按姓名精确查：唯一命中直接用；同名多人时
          只保留有薪酬权限的工号，仍多个则列候选（姓名(组织)）让用户选；
          都没权限按无权限处理
        - 其他格式（如英文账号 guoruxuan1）→ 提示「请输入被调薪人的工号或姓名。」
        """
        # 每次 start 都是全新流程：先清空上一人的名单/方案/锁/薪酬缓存
        self.person = None
        self.before = None
        self.after = None
        self.sections = []
        self.bundle = None
        self.roster_locked = False
        self.confirmed_at = None
        self.user_ratio = None
        self.ratio = None
        self.audit = []
        self._missing_salary = []
        # 4A 有 TTL 缓存（默认 24h，FOURA_CACHE_TTL 可调）；start 只在缓存过期时刷新
        if hasattr(self.sap, "refresh"):
            self.sap.refresh()
        raw = str(emp_id or "").strip()
        if _looks_like_emp_id(raw):
            return self._start_by_id(raw)
        if _is_chinese_name(raw):
            return self._start_by_name(raw)
        self.step = STEP_PERM
        return _emit(None, NAME_PROMPT_TEXT)

    def _start_by_id(self, emp_id):
        # 1) 权限先行：按工号校验（checkSalaryBp），不触碰薪酬台账数据。
        #    真实薪酬权限按工号校验，不调 4A、不提前碰薪酬台账。
        perm_input = {"emp_id": emp_id}
        perm = self.auth.check_permission(perm_input)
        if not perm["allowed"]:
            # 无权限：只回文字、不出卡片
            self.step = STEP_PERM
            self.person = perm_input if perm_input.get("emp_id") else None
            return _emit(None, PERM_DENIED_TEXT)

        # 2) 权限过了，再调薪酬台账（接口3）→ 调薪前信息
        #    （l2-l6 组织路径、岗位、序列、职级、城市、固薪——不依赖 4A）
        #    台账无记录 → 终止流程：固薪为 0 会让方案失真，不降级展示。
        p = None
        salary_note = ""
        salary_error = None
        if self.salary_client:
            try:
                rows = self.salary_client.list_salary([emp_id], self.sso_token)
                if rows:
                    from adapters.salary import to_person
                    match = next((item for item in rows if str(item.get("userCode")) == emp_id), None)
                    if match is not None:
                        p = to_person(match)
            except Exception as e:
                salary_error = e
                salary_note = "薪酬接口暂时没查到现值，调薪前信息可能不全。"
        if p is None:
            self.step = STEP_PERM
            if salary_error is not None:
                return _emit(None, _error_text(salary_error))
            return _emit(None, "薪酬系统未找到该员工，请核对工号。")
        if p.get("hasPermission") is False:
            self.step = STEP_PERM
            return _emit(None, PERM_DENIED_TEXT)
        if not p.get("emp_id") or not p.get("fixed") or p["fixed"] <= 0:
            # 台账有记录但固薪缺失/为 0：方案会失真，按未找到终止
            self.step = STEP_PERM
            return _emit(None, "薪酬系统未找到该员工，请核对工号。")
        self.person = p
        self.before = dict(p)
        self.after = dict(p)
        # 换人成功 = 全新流程：清掉上一个人的指定涨幅与留痕（否则新人方案
        # 直接沿用旧涨幅——真实口径事故：旧人指定 8%，新人方案不按系统建议出）
        self.user_ratio = None
        self.ratio = None
        self.audit = []
        self.step = STEP_INFO
        return _emit(self._info_card(), salary_note or None)

    def _start_by_name(self, name):
        """按姓名开单：4A 人员池精确匹配 → 权限过滤 → 唯一直接进流程/多名列候选。"""
        if not hasattr(self.sap, "find_by_name"):
            self.step = STEP_PERM
            return _emit(None, NAME_PROMPT_TEXT)
        hits = self.sap.find_by_name(name)
        if not hits:
            self.step = STEP_PERM
            return _emit(None, "薪酬系统未找到该员工，请核对工号。")
        # 只保留有薪酬权限的候选（权限接口按工号批量校验）
        ids = [p["emp_id"] for p in hits if p.get("emp_id")]
        try:
            verdicts = self.auth.check_permissions([{"emp_id": i} for i in ids])
        except Exception as e:
            self.step = STEP_PERM
            return _emit(None, _error_text(e))
        allowed = [p for p in hits
                   if (verdicts.get(p.get("emp_id")) or {}).get("allowed")]
        if not allowed:
            self.step = STEP_PERM
            self.person = None
            return _emit(None, PERM_DENIED_TEXT)
        if len(allowed) == 1:
            return self._start_by_id(allowed[0]["emp_id"])
        # 同名且有权限的仍多人：列候选（姓名(组织)）让用户选
        cands = ["%s(%s)" % (p.get("name"), p.get("org_name") or p.get("org_code") or "")
                 for p in allowed[:5]]
        more = "" if len(allowed) <= 5 else " 等 %d 人" % len(allowed)
        self.step = STEP_PERM
        return _emit(None, "同名员工有 %d 位：%s%s，请回复工号指定要调薪的员工。"
                     % (len(allowed), "、".join(cands), more))

    def _info_card(self):
        """薪酬-调薪前后信息卡：只给渲染卡片需要的数据，不设计卡片。

        只提供「改之前」的信息（即从接口查到的现值；after 留空由用户在卡上改）。
        字段名与平台模板 vars 对齐（template=card_salary_info / env=prod），
        见变量注释；卡面长什么样由平台模板负责。
        """
        b = self.before
        # afterLevel/beforeLevel 平台类型为 integer（0=空，与定薪岗位卡 ggs=0 同口径）
        before_level = b.get("ggs")
        try:
            before_level = int(before_level) if before_level not in (None, "") else 0
        except (TypeError, ValueError):
            before_level = 0
        return {
            "templateKey": "card_salary_info",
            "params": {
                "empId": str(b["emp_id"]),
                "intro":  "权限没问题。下面是%s的当前薪酬信息。" % b["name"],
                "title": "调薪前后信息 · %s（工号 %s）" % (b["name"], b["emp_id"]),
                "afterJob": "",
                "afterOrg": "",
                "footnote": "",
                "afterCity": "",
                "beforeJob": b.get("post") or "",
                "beforeOrg": b.get("org_path") or b.get("l2") or "",
                "beforeSeq": b.get("seq") or "",
                "sessionId": "",
                "afterLevel": 0,
                "afterSeq": "",
                "beforeCity": b.get("city") or "",
                "beforeLevel": before_level,
                "requestId": "",
            }
        }
    

    def say_edit(self, field, value, side="after"):
        key = EDIT_KEYS.get(field)
        if not key:
            return _emit(None, "卡片不存在此字段。")
        if self.step == STEP_DONE and key != "months":
            return _emit(None, "方案已出，调薪前后信息不能再改；如需调整请重新发起调薪。")
        if self.step == STEP_ROSTER and key != "months":
            return _emit(None, "名单已生成，调薪前后信息不能再改；如需调整请重新发起调薪。")
        if key == "ggs":
            try:
                value = parse_grade(value)
            except (TypeError, ValueError):
                return _emit(None, "职级没看懂，请直接给数字（1-30）。")
            if not (GGS_MIN <= value <= GGS_MAX):
                return _emit(None, "职级需在 %d-%d 之间，请重新填写。" % (GGS_MIN, GGS_MAX))
        if key == "months":
            try:
                value = int(str(value).replace("薪", "").strip())
            except (TypeError, ValueError):
                return _emit(None, "薪数没看懂，请直接给数字（如 12薪、13薪）。")
            # 月数下限 12（与定薪 MONTHS_MIN 同口径）：低于 12 的月薪折算失真
            if value < 12:
                return _emit(None, "薪数需至少为 12，请重新填写。")
        target = self.before if side == "before" else self.after
        target[key] = value
        if key == "l2":
            target["org_path"] = value
        if key == "months" and self.step == STEP_DONE:
            return self.build_plan()
        return _emit(None, "改好了。")

    # ---------------- 2. 名单 ----------------
    def submit_info(self, form=None, side="after"):
        """「调薪前后信息」卡提交（event.form）→ 落字段 → 同轮直接 confirm_info。

        与 say_edit（聊天文字改字段，只保存不推进）分开：卡片提交 = 保存 + 确认，
        校验不过（组织未匹配/无权限/同名待选）时 confirm_info 自己会停在 info
        并给出原因，字段已保存、不会丢。
        """
        if self.step not in (None, STEP_INFO):
            return _emit(None, "当前阶段不需要提交调薪信息，请按当前卡片操作。")
        form = form or {}
        updates = {}
        for k, v in form.items():
            key = EDIT_KEYS.get(k, EDIT_KEYS.get(str(k).lower()))
            if not key:
                continue
            # 卡片空值/未填（after 列为空）表示“不修改”，不能把现值清掉
            if v in (None, ""):
                continue
            if key == "ggs":
                if str(k).lower() == "afterlevel" and v in (0, "0") and not isinstance(v, bool):
                    continue
                try:
                    v = parse_grade(v)
                except ValueError as error:
                    return _emit(None, str(error))
            if key == "months":
                try:
                    v = int(str(v).replace("薪", "").strip())
                except (TypeError, ValueError):
                    continue
                # 月数下限 12：卡片回传异常值（0/负数/个位数）直接忽略，不落值
                if v < 12:
                    continue
            updates[key] = v
            if key == "l2":
                updates["org_path"] = v
        target = self.before if side == "before" else self.after
        target.update(updates)
        return self.confirm_info()

    def _after_org_code(self):
        """调薪后组织编码。返回 (org_code, note)。

        - 用户主动改了组织：严格解析，多命中/没找到都返回 note 阻塞圈人（不静默二选一）
        - 组织没改（路径来自薪酬台账）：台账名称与 4A 有出入时**不阻塞**，
          返回 ("", "")，名单退回按名称口径（与旧版行为一致）
        """
        before_org = self.before.get("org_path") or self.before.get("l2") or ""
        after_org = self.after.get("org_path") or self.after.get("l2") or ""
        unchanged = (not after_org) or (after_org == before_org)
        if not hasattr(self.sap, "resolve_org"):
            return self.after.get("org_code") or self.person.get("org_code", ""), ""
        # 支持完整路径输入“OLED中台/OLED制造中心/模组制造部/模组运营科”：
        # resolve_org 按最后一级名查、并用父路径收窄同名组织
        matches = self.sap.resolve_org(str(after_org)) if after_org else []
        # 消歧前先按操作人权限过滤：无权限组织不出现在提示里
        # （全部被滤掉=目标组织不在权限内，直接给权限口径；过滤接口异常则原样交权限闸兜底）
        if len(matches) > 1 and self.auth:
            matches, filter_err = roster_mod.filter_org_matches(self.sap, self.auth, matches)
            if filter_err:
                return "", "组织权限校验暂时不可用，请稍后重试。"
            if not matches:
                return "", PERM_DENIED_TEXT_ORG % after_org
        if len(matches) == 1:
            return str(matches[0].get("cOrgCode", "")), ""
        if unchanged:
            return "", ""
        if len(matches) > 1:
            # 多命中（同名组织常见）：不静默二选一，交由用户消歧
            return "", getattr(self.sap, "_resolve_ambiguous")(matches)
        return "", "没找到组织「%s」，请确认名称（可用完整路径如「OLED中台/印刷OLED中心」）。" % after_org

    def confirm_info(self):
        if self.step not in (None, STEP_INFO):
            return _emit(None, "当前阶段不需要确认调薪信息，请按当前卡片操作。")
        # 同一次对话内复用 4A 结果；新对话由 start() 重新拉取
        try:
            new_ggs = int(self.after.get("ggs"))
        except (TypeError, ValueError):
            self.step = STEP_INFO
            return _emit(None, "请填写调薪后职级（1-30）。")
        if not (GGS_MIN <= new_ggs <= GGS_MAX):
            self.step = STEP_INFO
            return _emit(None, "请填写调薪后职级（1-30）。")
        new_seq = self.after.get("seq")
        # 大/中/小组织判断始终用“这个人的 l2”，不用输入组织
        target = {**self.person,
                  "org_path": self.after.get("org_path") or self.person.get("org_path")}
        org_code, org_note = self._after_org_code()
        # 组织名消歧失败（多命中/没找到）时不出名单，先让用户说清楚是哪个组织
        if org_note and not org_code:
            self.step = STEP_INFO
            return _emit(None, org_note)
        if org_code:
            # 组织权限闸门：模糊匹配/用户改写的目标组织必须落在操作人权限内
            # （checkSalaryBp 支持 orgCodes：按祖先链精确校验，不抽样）
            gate = roster_mod.org_perm_gate(self.sap, self.auth, org_code)
            if not gate["allowed"]:
                self.step = STEP_INFO
                return _emit(None, gate.get("reason") or "你没有该员工的薪酬权限。")
            if gate.get("note"):
                self.audit.append(("org_perm_note", org_code, gate["note"]))
            target["org_code"] = org_code
            # 转组织后按新编码重取 L2/L3（同级池/上级按新组织算）
            if hasattr(self.sap, "org_l2_l3"):
                l2, l3 = self.sap.org_l2_l3(org_code)
                if l2:
                    target["l2"] = l2
                if l3:
                    target["l3"] = l3
            # 同级池按编码匹配：台账人员没有 l*_code，这里从 4A 祖先链补齐
            if hasattr(self.sap, "org_codes_at_level"):
                for i in range(2, 7):
                    c = self.sap.org_codes_at_level(org_code, "L%d" % i)
                    if c:
                        target["l%d_code" % i] = c
            if hasattr(self.sap, "org_path"):
                target["org_path"] = self.sap.org_path(org_code) or target.get("org_path")
        self._target_org = org_code
        self.sections = roster_mod.build_roster(
            target, new_ggs, new_seq, self.sap, self.auth,
            initiator_name=self.initiator_name)
        self.step = STEP_ROSTER
        self.roster_locked = False
        return _emit(self._roster_card(), org_note or None)

    def _roster_card(self):
        # 出名单这一趟里完成两件事，顺序不能反：
        #   1) _recheck：先过薪酬权限，无权限的人从名单里剔除（上级保留但不查薪酬）
        #   2) _ensure_salary：只对留下来的、有权查看的人补一次薪酬（GGS/固薪），
        #      保证卡片上的职级不是空的
        self._recheck()
        self._ensure_salary()

        by_key = {s["key"]: s for s in self.sections}
        s_up = by_key.get("upper")
        s_peer = by_key.get("peer")
        s_down = by_key.get("reportee")

        def rows_of(key):
            s = by_key.get(key)
            return [card_person(p) for p in (s["people"] if s else [])]

        # 上级保留（含无权限注记）；同级/下级也保留已移除行（removed 标记），
        # 由平台卡面渲染删除态，用户可再次勾选恢复。
        up_rows = rows_of("upper")
        peer_rows = rows_of("peer")
        down_rows = rows_of("reportee")

        # 卡顶说明：上级无权限/未核实 + 空节说明（如“直接上级岗位为空”）
        up_notes = [p.get("note") for p in (s_up["people"] if s_up else [])
                    if p.get("note")]
        section_notes = [s.get("note") for s in (s_up, s_peer, s_down)
                         if s and s.get("note") and not s["people"]]
        head_notes = list(dict.fromkeys(section_notes + up_notes))
        up_note = "；".join(head_notes) if head_notes else ""

        return {
            "templateKey": "card_salary_roster",
            "params": {
                "title":     "调薪名单确认",
                "up":        up_rows,
                "peer":      peer_rows,
                "down":      down_rows,
                "more":      [],
                "moreCount": "",
                "headnote":  up_note,
                "upTitle":   "上级名单",
                "peerTitle": "同级名单",
                "downTitle": "下级名单",
                "upRule":    (s_up["rule"] if s_up else ""),
                "peerRule":  (s_peer["rule"] if s_peer else ""),
                "downRule":  (s_down["rule"] if s_down else ""),
                "footnote":  "",
                "requestId": "",
                "sessionId": "",
            },
        }

    def _find(self, token):
        token = str(token)
        for s in self.sections:
            for p in s["people"]:
                if p["emp_id"] == token or p["name"] == token:
                    return s, p
        return None, None

    def adjust(self, action, emp_id, section=None):
        # roster 阶段正常改名单；done 阶段（方案已出）也允许再调整，
        # 改完直接重出方案（涨幅保持用户此前指定值，见 build_plan 的 user_ratio）。
        # done 态保持 roster_locked=True（名单是确认过的，build_plan 才肯重算）。
        # section：加人时指定分区（upper/peer/reportee，默认 peer 同级）；
        # 删人按工号/姓名全区搜，不分区。
        if self.step not in (STEP_ROSTER, STEP_DONE):
            return _emit(None, "名单已锁定，不能再改。")
        sec, p = self._find(emp_id)
        if not p:
            if action != "add":
                return _emit(None, "名单里没找到这个人。")
            raw = self.sap.fetch_person(emp_id)
            if not raw:
                return _emit(None, "工号 %s 查无此人。" % emp_id)
            if not self.auth.check_permission(raw)["allowed"]:
                return _emit(None, "%s 不在你的权限范围内，无法加入。" % raw["name"])
            sec_key = section if section in ("upper", "peer", "reportee") else "peer"
            target = next((s for s in self.sections if s["key"] == sec_key), None)
            if target is None:
                target = {"key": sec_key, "label": {"upper": "上级", "peer": "同级",
                                                    "reportee": "下级"}[sec_key],
                          "rule": "", "count": 0, "note": "", "people": []}
                self.sections.append(target)
            target["people"].append({
                "name": raw["name"], "emp_id": raw["emp_id"],
                "org": roster_mod.org_name(raw), "ggs": raw["ggs"], "seq": raw["seq"],
                "visible": True, "removed": False, "added": True, "note": "", "_raw": raw})
            self.audit.append(("add", raw["emp_id"]))
            if self.step == STEP_DONE:
                # 方案已出：改完名单直接重出方案（不回名单卡；保持 roster_locked）
                return self.build_plan()
            self.roster_locked = False
            # 回执 + 重弹最新名单卡（卡上状态与服务端一致）
            return _emit(self._roster_card(),
                         "已加入 %s（%s）。" % (raw["name"], raw["emp_id"]))
        if action == "add" and not self.auth.check_permission(p["_raw"])["allowed"]:
            return _emit(None, "%s 不在你的权限范围内，无法加入。" % p["name"])
        p["removed"] = (action == "remove")
        p["added"] = (action == "add")
        self.audit.append((action, p["emp_id"]))
        if self.step == STEP_DONE:
            return self.build_plan()
        self.roster_locked = False
        if action == "add":
            return _emit(self._roster_card(),
                         "已加入 %s（%s）。" % (p["name"], p["emp_id"]))
        return _emit(self._roster_card(),
                     "已移除 %s（%s）。" % (p["name"], p["emp_id"]))

    def submit_roster(self, form=None):
        """「调薪名单确认」卡提交（event.form）→ 应用卡上增删结果 → 同轮出方案。

        卡上点确认 = 确认，不二次确认：
        - 已在名单的人：按卡上 removed 勾选态应用（勾了=移除）
        - 卡上新增行（名单里没有的 code）：过权限校验后加入同级区
        - 应用完直接 confirm_roster() 出方案；校验失败（加的人无权限）时
          回原因停在 roster，已应用的部分不丢
        """
        form = form or {}
        if self.step not in (STEP_ROSTER, STEP_DONE):
            return _emit(None, "请先圈定名单。")
        # ① 应用卡上勾选态（removed）
        for row in (form.get("up") or []) + (form.get("peer") or []) + (form.get("down") or []):
            if not isinstance(row, dict):
                continue
            code = str(row.get("code") or "").strip()
            if not code:
                continue
            sec, p = self._find(code)
            if p is not None:
                p["removed"] = bool(row.get("removed"))
                if p["removed"]:
                    self.audit.append(("card_remove", code))
            elif row.get("name") and not row.get("removed"):
                # 名单里没有的新增行：查人、过权限、加入同级区
                try:
                    raw = self.sap.fetch_person(code)
                except Exception:
                    raw = None
                if not raw:
                    return _emit(None, "工号 %s 查无此人，名单未确认。" % code)
                if not self.auth.check_permission(raw)["allowed"]:
                    return _emit(None, "%s 不在你的权限范围内，无法加入，名单未确认。" % raw["name"])
                peer = next((s for s in self.sections if s["key"] == "peer"), None)
                if peer is None:
                    peer = {"key": "peer", "label": "同级", "rule": "",
                            "count": 0, "people": []}
                    self.sections.append(peer)
                peer["people"].append({
                    "name": raw["name"], "emp_id": raw["emp_id"],
                    "org": roster_mod.org_name(raw), "ggs": raw["ggs"], "seq": raw["seq"],
                    "visible": True, "removed": False, "added": True, "note": "", "_raw": raw})
                self.audit.append(("card_add", code))
        # ② 应用完直接出方案（卡上确认 = 名单确认）
        return self.confirm_roster()

    def filter_roster(self, key, seq=None, name=None, org=None, nationality=None):
        if self.step not in (STEP_ROSTER, STEP_DONE):
            return _emit(None, "名单已锁定，不能再改。")
        was_done = (self.step == STEP_DONE)
        # 国籍只来自薪酬台账（接口3，代码值 CN/HK/KR/TW/US…）：force 查台账——
        # 4A 自带固薪后「全员有固薪则跳过」短路恒真，不 force 国籍永远拿不到。
        nat_codes = None
        if nationality:
            self._recheck()
            self._ensure_salary(force=True)
            nat_codes = _nationality_codes(nationality)
            if not nat_codes:
                return _emit(None, "没识别这个国籍，请用工号或姓名指定要保留的人。")
        for s in self.sections:
            if s["key"] != key:
                continue
            kept = []
            for p in s["people"]:
                if p["added"]:            # 手动加的人不被筛掉
                    kept.append(p)
                    continue
                ok = True
                if seq and p["seq"] != seq:
                    ok = False
                if name and name not in p["name"]:
                    ok = False
                raw = p.get("_raw") or {}
                if org and not any(org in str(raw.get(k, "")) for k in ("l2", "l3", "l4")):
                    ok = False
                if nat_codes is not None and str(raw.get("nationality") or "") not in nat_codes:
                    ok = False   # 代码值精确匹配：CN/HK/KR/TW…
                if ok:
                    kept.append(p)
                else:
                    self.audit.append(("filter_out", p["emp_id"]))
            s["people"] = kept
            s["count"] = sum(1 for p in kept if not p["removed"])
        if was_done:
            # 方案已出：筛选完直接重出方案（不回名单卡；保持 roster_locked）
            return self.build_plan()
        self.roster_locked = False
        return _emit(self._roster_card())

    def confirm_roster(self):
        """确认名单 → 直接出方案与 Excel（与定薪 confirm_extra 保持一致）。

        名单锁定后立刻生成方案，不再要求调用方额外触发一次 build_plan。
        需要改涨幅重算时，仍可单独调 build_plan(ratio=...)。
        done（方案已出）也放行：名单卡上再次点确认 = 按当前名单重出方案。
        """
        if self.step not in (STEP_ROSTER, STEP_DONE):
            return _emit(None, "请先确认名单。")
        self.roster_locked = True
        self.confirmed_at = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return self.build_plan()

    # ---------------- 3. 方案 ----------------
    def build_plan(self, ratio=None):
        if not self.roster_locked:
            return _emit(None, "名单没确认，方案先不出。")
        self.bundle = None
        subject = self.person
        verdict = roster_mod._permission_map(self.auth, [subject], fresh=True)
        if not verdict.get(str(subject["emp_id"]), {}).get("allowed"):
            return _emit(None, PERM_DENIED_TEXT)
        org_code = getattr(self, "_target_org", "")
        if org_code:
            gate = roster_mod.org_perm_gate(self.sap, self.auth, org_code)
            if not gate["allowed"]:
                return _emit(None, gate["reason"])
        self._recheck()
        self._ensure_salary()
        new_ggs = int(self.after["ggs"])
        if not (GGS_MIN <= new_ggs <= GGS_MAX):
            return _emit(None, "请填写调薪后职级（1-30）。")
        city = self.after.get("city") or self.person.get("city")
        peer_rows = self._peer_rows()
        peer_avg = calc.average_rows(peer_rows)
        upper_p, upper_fixed = self._upper()

        rec = calc.recommend_ratio(
            cur_fixed=self.person["fixed"], new_ggs=new_ggs, city=city,
            peer_avg_fixed=peer_avg["fixed"] if peer_avg else None,
            upper_fixed=upper_fixed)
        # 涨幅优先级：本次显式指定 > 用户此前指定（改名单重出方案时保持） > 系统建议
        if ratio is not None:
            self.user_ratio = ratio
            use_ratio = ratio
        elif getattr(self, "user_ratio", None) is not None:
            use_ratio = self.user_ratio
        else:
            use_ratio = rec["suggest"]
        self.ratio = use_ratio
        competitiveness = rec["competitiveness"]

        scheme = calc.build_scheme(
            {**self.person, "city": city}, new_ggs, use_ratio, peer_rows,
            new_months=(self.after or {}).get("months") or 13)

        ctx = {"ratio": use_ratio, "cur_fixed": self.person["fixed"],
               "new_fixed": scheme["固薪"]["after"], "city": city, "new_ggs": new_ggs,
               "upper_fixed": upper_fixed,
               "peer_avg_fixed": peer_avg["fixed"] if peer_avg else None,
               "perf2": self.person.get("perf2"), "perf1": self.person.get("perf1"),
               "perf3": self.person.get("perf3"),
               "nine_box": self.person.get("nine_box"),
               "competitiveness": competitiveness}
        checks = rules.run_checks(ctx)
        template = "GGS12 及以下" if new_ggs <= 12 else "通用"
        fname = "调薪方案_%s_%s_%s.xlsx" % (
            self.person["name"], self.person["emp_id"], _today())

        self.bundle = {
            "target": {**self.person, "new_ggs": new_ggs, "new_fixed": scheme["固薪"]["after"],
                       "city": city,
                       "new_org": self.after.get("l2") or self.person.get("l2"),
                       "new_org_path": (self.after.get("org_path") or self.after.get("l2")
                                        or self.person.get("org_path")),
                       "new_post": self.after.get("post") or self.person.get("post"),
                       "new_seq": self.after.get("seq") or self.person.get("seq")},
            "upper": calc.person_row(upper_p) if upper_fixed else upper_p,
            "upper_visible": bool(upper_p and upper_fixed and upper_fixed > 0),
            "peers": peer_rows, "peer_avg": peer_avg,
            "reportees": self._sample_rows("reportee"),
            "reportee_avg": None,
            "scheme": scheme, "checks": checks, "ratio": use_ratio,
            "recommendation": rec, "template": template, "filename": fname,
            "missing_salary": list(self._missing_salary),
            "sample_counts": self._sample_counts(),
            "audit": list(self.audit),
            "confirm": {"operator": self.operator, "at": self.confirmed_at},
        }
        if self.bundle["reportees"]:
            self.bundle["reportee_avg"] = calc.average_rows(self.bundle["reportees"])

        self.step = STEP_DONE
        self.roster_locked = True   # 方案已出：名单锁回（done 后 adjust/filter 可再解锁）
        bubble = rules.summary(checks)
        return {
            "bubble": bubble,
            "card": None,
        }

    def export(self, path):
        if self.step != STEP_DONE:
            return _emit(None, "方案还没生成，请先确认名单。")
        result = self.build_plan()
        if self.bundle is None:
            return result
        if export_mod is None:
            raise ImportError("openpyxl 不可用，无法生成 Excel")
        return export_mod.build(self.bundle, path)

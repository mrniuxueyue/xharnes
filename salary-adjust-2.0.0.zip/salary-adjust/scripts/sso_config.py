# -*- coding: utf-8 -*-
"""平台凭据拉取：调 getSsoConfig 一次拿到薪酬接口凭据（4A 用共享令牌，不走此配置）。

接口（GET，springdoc 实测确认 2026-11-18）：
    {base_url}/hr-agent-service/{organization_id}/assistant/sso/getSsoConfig
    Header: {"get-sso-cfg-token": <令牌>}

需要的返回字段（平铺 JSON，无 Result/code 封装）：
    appId / secret / aesKey / rsaPublicKey / rsaPrivateKey
      → salary_cred {appId, secret, aesKey, rsaPublic, rsaPrivate}

默认租户 organization_id = 31。base 内置测试默认；get-sso-cfg-token 不再写死在代码里，
必须由平台入参或环境变量注入（生产/测试都建议显式注入）：
    SSO_CONFIG_BASE_URL    getSsoConfig 的 base_url（默认测试 http://10.110.167.11:32754）
    SSO_CONFIG_ORG_ID      租户 organization_id，默认 31
    SSO_CONFIG_TOKEN       get-sso-cfg-token 头值（必填；无内置令牌）
"""
from runtime_config import TEST_SSO, deployment_mode, endpoint
import json
import os
import re
import urllib.error
import urllib.request

DEFAULT_ORG_ID = "31"
DEFAULT_BASE = TEST_SSO
DEFAULT_TOKEN = ""


def _env(name, default=""):
    return (os.environ.get(name) or "").strip() or default


class SsoConfigError(RuntimeError):
    """getSsoConfig 调用失败。"""

    def __init__(self, url, status=None, body=""):
        tail = " " + str(status) if status is not None else ""
        super().__init__("getSsoConfig%s（%s）：%s" % (tail, url, _redact_body(body)[:300]))
        self.url = url
        self.status = status
        self.body = _redact_body(body)


def _redact_body(body):
    """错误响应里可能带 appId/secret/aesKey/rsa 等凭据：日志/异常文本先脱敏。"""
    text = str(body or "")
    return re.sub(
        r'(?i)("?(?:secret|aesKey|rsaPublic|rsaPrivate|rsaPublicKey|rsaPrivateKey)"?'
        r'\s*[:=]\s*"?)[^",}\s]+',
        r"\1***", text)


def fetch_sso_config(base_url=None, organization_id=None, token=None,
                     timeout=30, environment=None):
    """调 getSsoConfig，返回平铺 JSON（字段：appId / secret / aesKey /
    rsaPublicKey / rsaPrivateKey 等）。

    base_url / organization_id / token 未传时依次回退：环境变量
    SSO_CONFIG_BASE_URL / SSO_CONFIG_ORG_ID / SSO_CONFIG_TOKEN，再内置默认
    （DEFAULT_BASE = 测试环境 / DEFAULT_ORG_ID=31 / DEFAULT_TOKEN 为空）。
    """
    base = endpoint(base_url, "SSO_CONFIG_BASE_URL", deployment_mode(environment), TEST_SSO)
    org = (str(organization_id or _env("SSO_CONFIG_ORG_ID", DEFAULT_ORG_ID))
           .strip().strip("/"))
    token = token or _env("SSO_CONFIG_TOKEN", DEFAULT_TOKEN)
    if not base:
        raise SsoConfigError("getSsoConfig", None,
                             "缺少 base_url：请传 sso_config_base_url 或设 SSO_CONFIG_BASE_URL")
    if not token:
        raise SsoConfigError("getSsoConfig", None,
                             "缺少 get-sso-cfg-token：请传 token 或设 SSO_CONFIG_TOKEN")

    url = "%s/hr-agent-service/%s/assistant/sso/getSsoConfig" % (base, org)
    req = urllib.request.Request(
        url, headers={"get-sso-cfg-token": token, "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        raise SsoConfigError(url, e.code, e.read().decode("utf-8", "replace"))
    except urllib.error.URLError as e:
        raise SsoConfigError(url, None, str(e.reason))
    if not isinstance(data, dict):
        raise SsoConfigError(url, None, "响应不是 JSON 对象：%r" % (data,))
    return data


def to_salary_cred(cfg):
    """取薪酬凭据 {appId, secret, aesKey, rsaPublic, rsaPrivate}，键名对齐
    SalaryApiClient.from_cred。缺项留空。"""
    if not isinstance(cfg, dict):
        return {}
    def pick(*keys):
        for k in keys:
            v = cfg.get(k)
            if v:
                return v
        return ""
    return {
        "appId": pick("appId", "app_id"),
        "secret": pick("secret", "应用密钥"),
        "aesKey": pick("aesKey", "aes_key"),
        "rsaPublic": pick("rsaPublicKey", "rsaPublic", "rsa_public"),
        "rsaPrivate": pick("rsaPrivateKey", "rsaPrivate", "rsa_private"),
    }


def load_sso_config(base_url=None, organization_id=None, token=None,
                    timeout=30, environment=None):
    """一站式：返回 salary_cred，供 build() 填充薪酬凭据。"""
    cfg = fetch_sso_config(base_url=base_url, organization_id=organization_id,
                           token=token, timeout=timeout, environment=environment)
    return to_salary_cred(cfg)

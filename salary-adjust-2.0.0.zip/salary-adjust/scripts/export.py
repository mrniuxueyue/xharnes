# -*- coding: utf-8 -*-
"""导出 Excel（固定三 sheet；方案本体按需求 sheet2/3 的宽表版式，行高列宽调好）。

落盘即自校验：build()/build_hire() 在 wb.save() 后自动验证文件（zip 完整性、
XML 良构、openpyxl 可重开且内容非空），校验不过直接抛错交上层兜底话术，
通过才返回路径——调用方拿到路径即可交付，无需再做任何文件校验。
"""

import datetime
import os
import tempfile
import zipfile
import xml.etree.ElementTree as ET
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from rules import report_checks
from structure import GRADE_TABLE


def _validate(path):
    """xlsx 自校验：zip 完整、所有 XML 良构、可重开、首个 sheet 有内容。"""
    with open(path, "rb") as f:
        if f.read(2) != b"PK":
            raise RuntimeError("导出文件不是合法的 xlsx（缺少 zip 头）")
    try:
        z = zipfile.ZipFile(path)
    except zipfile.BadZipFile as e:
        raise RuntimeError("导出文件不是合法的 xlsx（%s）" % e)
    with z:
        bad = z.testzip()
        if bad is not None:
            raise RuntimeError("导出文件损坏（zip 成员 %s 校验失败）" % bad)
        for name in z.namelist():
            if name.endswith(".xml") or name.endswith(".rels"):
                try:
                    ET.fromstring(z.read(name))
                except ET.ParseError as e:
                    raise RuntimeError("导出文件 XML 损坏（%s: %s）" % (name, e))
    wb2 = load_workbook(path, read_only=True)
    try:
        if not wb2.sheetnames:
            raise RuntimeError("导出文件没有工作表")
        ws2 = wb2[wb2.sheetnames[0]]
        if not ws2.max_row or ws2.max_row < 3:
            raise RuntimeError("导出文件内容不完整")
    finally:
        wb2.close()

def _save(workbook, path):
    directory = os.path.dirname(path) or "."
    os.makedirs(directory, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=directory, suffix=".xlsx")
    os.close(fd)
    try:
        workbook.save(tmp)
        _validate(tmp)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)
    return path


HEAD_FILL = PatternFill("solid", fgColor="FFD9E1F2")
SEC_FILL = PatternFill("solid", fgColor="FFE2EFDA")
AVG_FILL = PatternFill("solid", fgColor="FFFFF2CC")
THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
WRAP = Alignment(wrap_text=True, vertical="center")
LEFT = Alignment(horizontal="left", vertical="center", wrap_text=True)
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)

HEADERS = [
    "工号", "姓名", "国籍",
    "L2", "L3", "L4", "L5", "L6", "岗位名称", "序列", "人级",
    "驻地", "驻地城市", "固定收入人民币",
    "奖金基线人民币", "奖金基线占比", "固定薪酬+奖金基线",
    "13薪/12薪", "上年实发奖金", "上年实发长期激励", "薪酬竞争力",
    "币种", "上两年年度绩效", "上一年年度绩效", "人才盘点九宫格位置",
    "最高学历", "学校类别", "入职时间", "大学生届别", "职位族", "职位类", "职子类",
]
WIDTHS = [9, 11, 7, 13, 13, 13, 9, 9, 20, 7, 7,
          12, 8, 14, 14, 12, 18, 10, 13, 16, 11,
          8, 11, 11, 12, 10, 8, 11, 9, 9, 9, 12]
TABLE_WIDTH = len(HEADERS)
MONEY_COLS = {14, 15, 17, 19, 20}
PCT_COLS = {16}
RATIO_COLS = {21}
MONEY_FMT = "#,##0"

PERSON_KEYS = [
    "emp_id", "name", "nationality",
    "l2", "l3", "l4", "l5", "l6", "post", "seq", "ggs",
    "city", "city_tier", "fixed",
    "bonus_base", "bonus_ratio", "total_fixed_bonus",
    "months_label", "last_bonus", "last_lti", "competitiveness",
    "currency", "perf2", "perf1", "nine_box",
    "edu", "school_type", "join_date", "cohort", "family", "post_class", "post_sub",
]


def _num(v):
    return v if isinstance(v, (int, float)) else None


def _person_row(ws, r, row, masked=False):
    vals = []
    for key in PERSON_KEYS:
        if masked and key not in ("emp_id", "name"):
            vals.append(None)
        elif key == "months_label":
            vals.append("%s薪" % int(row.get("months") or 13))
        else:
            vals.append(row.get(key, ""))
    for c, v in enumerate(vals, 1):
        cell = ws.cell(r, c, v)
        cell.border = BORDER
        cell.alignment = LEFT
        if isinstance(v, (int, float)) and c in MONEY_COLS:
            cell.number_format = MONEY_FMT
        if isinstance(v, (int, float)) and c in PCT_COLS:
            cell.number_format = "0.0%"
        if isinstance(v, (int, float)) and c in RATIO_COLS:
            cell.number_format = "0.00"


def _section(ws, r, title):
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=TABLE_WIDTH)
    c = ws.cell(r, 1, title)
    c.font = Font(bold=True, size=11)
    c.fill = SEC_FILL
    c.alignment = LEFT
    return r + 1


def _header(ws, r):
    groups = [("基础信息", 1, 14), ("薪酬信息", 15, 22), ("辅助信息", 23, TABLE_WIDTH)]
    for name, first, last in groups:
        ws.merge_cells(start_row=r, start_column=first, end_row=r, end_column=last)
        cell = ws.cell(r, first, name)
        cell.font = Font(bold=True, size=9)
        cell.fill = SEC_FILL
        cell.alignment = CENTER
        for c in range(first, last + 1):
            ws.cell(r, c).border = BORDER
    r += 1
    for c, h in enumerate(HEADERS, 1):
        cell = ws.cell(r, c, h)
        cell.font = Font(bold=True, size=9)
        cell.fill = HEAD_FILL
        cell.alignment = CENTER
        cell.border = BORDER
    return r + 1


def _avg_row(ws, r, avg):
    ws.cell(r, 2, "平均值").font = Font(bold=True)
    for c, key in [(14, "fixed"), (15, "bonus_base"), (17, "total_fixed_bonus"),
                   (19, "last_bonus"), (20, "last_lti"), (21, "competitiveness")]:
        cell = ws.cell(r, c, avg.get(key))
        cell.font = Font(bold=True)
        if key == "competitiveness":
            cell.number_format = "0.00"
        else:
            cell.number_format = MONEY_FMT
    for c in range(1, TABLE_WIDTH + 1):
        ws.cell(r, c).fill = AVG_FILL
        ws.cell(r, c).border = BORDER
        ws.cell(r, c).alignment = LEFT
    return r + 1


def _fmt_growth(g):
    return None if g is None else round(g, 4)


def _cn_number(n):
    chars = "一二三四五六七八九"
    return chars[n - 1] if 1 <= n <= len(chars) else str(n)


def _text_units(value):
    """估算显示宽度：中文/全角按 2，英文/数字按 1。"""
    text = str(value)
    return sum(2 if ord(ch) > 127 else 1 for ch in text)


def _autofit(ws, min_widths=None, max_width=32, caps=None):
    """按内容估算列宽/行高；表头已由调用方设置居中，内容保持左对齐。"""
    import math

    min_widths = min_widths or [8] * ws.max_column
    caps = caps or {}
    merged_top = {}
    for rng in ws.merged_cells.ranges:
        merged_top[(rng.min_row, rng.min_col)] = rng

    # 列宽：合并单元格里的长标题不参与单列宽度，避免把 A 列撑得过宽。
    # 多行单元格只按最长一行估算，避免组织路径把 B/C 列拉得过大。
    widths = [0] * (ws.max_column + 1)
    for row in ws.iter_rows():
        for cell in row:
            if cell.value is None:
                continue
            rng = merged_top.get((cell.row, cell.column))
            if rng and rng.max_col > rng.min_col:
                continue
            longest = max(_text_units(line) for line in str(cell.value).split("\n"))
            widths[cell.column] = max(widths[cell.column], longest + 2)

    for col in range(1, ws.max_column + 1):
        floor = min_widths[col - 1] if col - 1 < len(min_widths) else 8
        cap = min(max_width, caps.get(col, max_width))
        ws.column_dimensions[get_column_letter(col)].width = min(max(floor, widths[col]), cap)

    # 行高：按换行和列宽估算，合并单元格按合并后的总宽度估算
    for row in ws.iter_rows():
        line_count = 1
        for cell in row:
            if cell.value is None:
                continue
            rng = merged_top.get((cell.row, cell.column))
            if rng:
                cols = range(rng.min_col, rng.max_col + 1)
            else:
                cols = [cell.column]
            total_width = sum(
                ws.column_dimensions[get_column_letter(c)].width or 10 for c in cols
            )
            text = str(cell.value)
            for line in text.split("\n"):
                line_count = max(
                    line_count,
                    max(1, math.ceil(_text_units(line) / max(4, total_width * 1.05))),
                )
        if line_count > 1:
            row_no = row[0].row
            old_height = ws.row_dimensions[row_no].height or 0
            new_height = min(96, max(20, line_count * 15 + 4))
            if new_height > old_height:
                ws.row_dimensions[row_no].height = new_height


# ============================================================ 定薪
HIRE_HEADERS = ["科目", "原单位", "拟定信息", "涨幅", "备注"]
HIRE_WIDTHS = [20, 15, 20, 10, 28, 12, 12, 12, 12, 12, 12, 12, 12, 12]


FAIL_FONT = Font(color="FFC00000", bold=True)   # 硬底线未过：红字加粗
WARN_FONT = Font(color="FFC55A11")              # 参考超限：橙字


def _render_checks(ws, r, checks):
    """不符合项段：编号+名称+结论+建议 的中文行，硬底线红字、参考超限橙字。
    返回下一可用行号。"""
    bad = report_checks(checks or [])
    if not bad:
        return r
    ws.cell(r, 1, "底线与参考项校验").font = Font(bold=True)
    r += 1
    for ck in bad:
        no = str(ck.get("no") or "")
        kind = str(ck.get("kind") or "")
        if kind == "hard":
            verdict = "未通过" if ck.get("res") == "fail" else "未校验"
            font = FAIL_FONT
        else:
            verdict = "未校验" if ck["res"] == "unchecked" else "超限"
            font = WARN_FONT
        parts = ["%s %s：%s" % (no, ck.get("name") or "", verdict)]
        if ck.get("note"):
            parts.append("（%s）" % ck["note"])
        suggest = str(ck.get("suggest") or "").strip()
        if suggest:
            parts.append("；%s" % suggest)
        cell = ws.cell(r, 1, "".join(parts))
        cell.alignment = LEFT
        cell.font = font
        r += 1
    return r


def _hire_section(ws, r, title):
    c = ws.cell(r, 1, title)
    c.font = Font(bold=True, size=11)
    c.alignment = LEFT
    return r + 1


def build_hire(bundle, path):
    from structure import city_tier
    wb = Workbook()
    ws = wb.active
    ws.title = "定薪方案"
    for i, w in enumerate(WIDTHS, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.column_dimensions["A"].width = 20
    ws.column_dimensions["B"].width = 18
    ws.column_dimensions["C"].width = 18
    ws.column_dimensions["D"].width = 12
    ws.column_dimensions["E"].width = 28

    t = bundle["target"]
    c = ws.cell(1, 1, "定薪方案报告 - %s" % t["name"])
    c.font = Font(bold=True, size=14)
    c.alignment = LEFT
    ws.row_dimensions[1].height = 20

    r = 3
    r = _hire_section(ws, r, "一、定薪背景")
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=TABLE_WIDTH)
    org = bundle.get("origin", {})
    new_org = t.get("org_path") or t.get("org") or ""
    bg = "%s %s，计划招聘为 %s %s，GGS%s，序列%s，base %s（%s）" % (
        org.get("company") or org.get("city", ""), org.get("post", ""),
        new_org, t.get("post", ""),
        t["new_ggs"], t.get("seq", ""), t.get("city", ""),
        city_tier(t.get("city", "")))
    cell = ws.cell(r, 1, bg)
    cell.alignment = LEFT
    r += 2

    upper = bundle.get("upper")
    upper_title = "二、上级薪酬情况"
    if upper:
        upper_title += " - %s（工号 %s）" % (upper.get("name", ""), upper.get("emp_id", ""))
    r = _hire_section(ws, r, upper_title)
    r = _header(ws, r)
    if upper:
        _person_row(ws, r, upper, masked=not bundle.get("upper_visible"))
        r += 1
    else:
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=TABLE_WIDTH)
        ws.cell(r, 1, "上级岗位为空。").alignment = LEFT
        r += 1
    r += 1

    sec_no = 2
    if bundle["peers"]:
        sec_no += 1
        r = _hire_section(ws, r, "%s、同级薪酬情况（GGS %s）" % (_cn_number(sec_no), t["new_ggs"]))
        r = _header(ws, r)
        for row in bundle["peers"]:
            _person_row(ws, r, row)
            r += 1
        if bundle["peer_avg"]:
            r = _avg_row(ws, r, bundle["peer_avg"])
        r += 1

    if bundle.get("reportees"):
        sec_no += 1
        r = _hire_section(ws, r, "%s、下级薪酬情况" % _cn_number(sec_no))
        r = _header(ws, r)
        for row in bundle["reportees"]:
            _person_row(ws, r, row)
            r += 1
        if bundle.get("reportee_avg"):
            r = _avg_row(ws, r, bundle["reportee_avg"])
        r += 1

    sec_no += 1
    r = _hire_section(ws, r, "%s、定薪方案（模板：%s）" % (_cn_number(sec_no), bundle["template"]))
    for c, h in enumerate(HIRE_HEADERS, 1):
        cell = ws.cell(r, c, h)
        cell.font = Font(bold=True, size=9)
        cell.fill = HEAD_FILL
        cell.alignment = CENTER
        cell.border = BORDER
    ws.row_dimensions[r].height = 22
    r += 1
    scheme_items = list(bundle["scheme"].items())
    if str(bundle.get("template", "")).startswith("GGS12"):
        scheme_items = [(k, v) for k, v in scheme_items if "长期激励" not in k]

    extra = bundle.get("extra") or {}

    def put_plan_row(subj, before=None, after=None, growth=None, note=None, group=False):
        nonlocal r
        if group:
            cell = ws.cell(r, 1, subj)
            cell.font = Font(bold=True)
            cell.fill = HEAD_FILL
            cell.alignment = LEFT
            for c in range(1, 6):
                ws.cell(r, c).border = BORDER
        else:
            for c, val in enumerate([subj, before, after, _fmt_growth(growth), note], 1):
                cell = ws.cell(r, c, val)
                cell.border = BORDER
                cell.alignment = LEFT
                if c in (2, 3) and isinstance(val, (int, float)):
                    cell.number_format = MONEY_FMT
                if c == 4 and isinstance(val, (int, float)):
                    cell.number_format = "0.0%"
        if subj == "组织岗位职级":
            ws.row_dimensions[r].height = 88.5
            for c in range(1, 7):
                ws.cell(r, c).border = BORDER
        r += 1

    def put_extra_rows():
        if extra.get("lti_note"):
            put_plan_row("长期激励说明", note=extra.get("lti_note"))
        if extra.get("cash_allowance"):
            put_plan_row("现金补贴", before=None,
                         after=extra.get("cash_allowance"),
                         note=extra.get("cash_note", ""))
        if extra.get("social") or extra.get("fund"):
            put_plan_row("其他薪酬", group=True)
            if extra.get("social"):
                put_plan_row("社保", before=extra.get("social"))
            if extra.get("fund"):
                put_plan_row("公积金", before=extra.get("fund"))
        if extra.get("special"):
            put_plan_row("特殊约定", before=extra.get("special"))

    groups = {
        "固薪": "固薪",
        "奖金基线": "奖金",
        "上年实发长期激励": "长期激励",
        "固薪+奖金基线": "汇总",
    }
    for subj, v in scheme_items:
        if subj == "固薪+奖金基线":
            put_extra_rows()
        if subj in groups:
            put_plan_row(groups[subj], group=True)
        put_plan_row(subj, v.get("before"), v.get("after"), v.get("growth"), v.get("note"))

    # 最终方案只展示“不符合项”，pass/info 不铺开
    for key, label in (("peer", "同级"), ("reportee", "下级")):
        counts = bundle.get("sample_counts", {}).get(key, {})
        if counts.get("missing"):
            ws.cell(r, 1, "%s固薪样本：有效 %d 人，缺失 %d 人（已排除）。" %
                    (label, counts["valid"], counts["missing"])).alignment = LEFT
            r += 1
    r = _render_checks(ws, r, bundle.get("checks"))

    _autofit(ws, [40] + WIDTHS[1:], max_width=46, caps={1: 46, 2: 18, 3: 18})

    # sheet2 结构表
    ws2 = wb.create_sheet("薪酬结构表（附录）")
    for i, w in enumerate([10, 8, 12, 12, 12, 12, 12], 1):
        ws2.column_dimensions[get_column_letter(i)].width = w
    for c, h in enumerate(["城市", "GGS", "一档", "二档", "三档", "四档", "五档"], 1):
        cell = ws2.cell(1, c, h)
        cell.font = Font(bold=True)
        cell.fill = HEAD_FILL
        cell.alignment = CENTER
        cell.border = BORDER
    r2 = 2
    for tier in ("一线", "二线"):
        for ggs in sorted(GRADE_TABLE[tier]):
            band = GRADE_TABLE[tier][ggs]
            for c, v in enumerate([tier, ggs] + band, 1):
                cell = ws2.cell(r2, c, v)
                cell.border = BORDER
                cell.alignment = CENTER
                if c >= 3:
                    cell.number_format = MONEY_FMT
            r2 += 1

    # sheet3 字段与口径
    ws3 = wb.create_sheet("字段与口径")
    for i, w in enumerate([22, 46, 26], 1):
        ws3.column_dimensions[get_column_letter(i)].width = w
    for c, h in enumerate(["字段/科目", "口径", "来源"], 1):
        cell = ws3.cell(1, c, h)
        cell.font = Font(bold=True)
        cell.fill = HEAD_FILL
        cell.alignment = CENTER
        cell.border = BORDER
    rows3 = [
        ("拟定固薪", "原单位固薪 × (1 + 系统建议涨幅)", "系统建议"),
        ("月薪", "拟定固薪 / 拟定价薪数（拟定默认 13 薪，≥12 薪可指定）", "计算"),
        ("奖金基线", "固薪 × 占比/(1-占比)", "计算"),
        ("奖金基线占比", "拟定按 GGS 标准占比表；原单位按告知", "SKILL 内置/告知"),
        ("固薪+奖金基线", "固薪 + 奖金基线", "计算"),
        ("上年实发奖金/长期激励", "拟定 = 同层级平均", "同层级平均"),
        ("薪酬竞争力", "拟定固薪 / 城市×GGS 三档", "计算"),
        ("建议涨幅", "底线 5%~30% + 参考原则", "系统建议"),
        ("模板", "拟定 GGS ≤ 12 → GGS12及以下（无长期激励）", "规则"),
        ("13薪/12薪", "原单位按告知（支持任意薪数）；拟定默认 13 薪，可指定 ≥12 薪", "规则"),
        ("特殊约定/补贴/社保/公积金", "选填，无则不显示", "用户告知"),
    ]
    for i, (a, b, c) in enumerate(rows3, 2):
        for j, v in enumerate([a, b, c], 1):
            cell = ws3.cell(i, j, v)
            cell.border = BORDER
            cell.alignment = WRAP

    return _save(wb, path)


def build(bundle, path):
    wb = Workbook()
    ws = wb.active
    ws.title = "调薪方案"
    for i, w in enumerate(WIDTHS, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    t = bundle["target"]
    s = bundle["scheme"]
    ws.cell(1, 1, "调薪方案报告 - %s" % t["name"]).font = Font(bold=True, size=14)
    ws.row_dimensions[1].height = 20

    r = 3
    ws.cell(r, 1, "一、调薪背景").font = Font(bold=True)
    r += 1
    old_org = t.get("org_path") or t.get("l2") or ""
    new_org = t.get("new_org_path") or t.get("new_org") or old_org
    old_post = t.get("post") or ""
    new_post = t.get("new_post") or old_post
    old_seq = t.get("seq") or ""
    new_seq = t.get("new_seq") or old_seq
    seq_text = ("%s不变" % old_seq) if old_seq == new_seq else ("%s→%s" % (old_seq, new_seq))
    ws.cell(r, 1, "工号%s %s，原任 %s %s，现任 %s %s，GGS%s→GGS%s，序列%s，base %s" % (
        t.get("emp_id", ""), t.get("name", ""), old_org, old_post,
        new_org, new_post, t.get("ggs", ""), t.get("new_ggs", ""), seq_text,
        t.get("city", ""))).alignment = LEFT
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=TABLE_WIDTH)
    r += 2

    upper = bundle.get("upper")
    title = "二、上级薪酬情况" + (" - %s（工号 %s）" % (upper["name"], upper["emp_id"]) if upper else "")
    ws.cell(r, 1, title).font = Font(bold=True)
    r += 1
    r = _header(ws, r)
    if upper:
        _person_row(ws, r, upper, masked=not bundle.get("upper_visible"))
        r += 1
    r += 1

    sec_no = 2
    if bundle["peers"]:
        sec_no += 1
        ws.cell(r, 1, "%s、同级薪酬情况（GGS %s）" % (_cn_number(sec_no), t["new_ggs"])).font = Font(bold=True)
        r += 1
        r = _header(ws, r)
        for row in bundle["peers"]:
            _person_row(ws, r, row)
            r += 1
        if bundle["peer_avg"]:
            r = _avg_row(ws, r, bundle["peer_avg"])
        r += 1

    if bundle["reportees"]:
        sec_no += 1
        ws.cell(r, 1, "%s、下级薪酬情况" % _cn_number(sec_no)).font = Font(bold=True)
        r += 1
        r = _header(ws, r)
        for row in bundle["reportees"]:
            _person_row(ws, r, row)
            r += 1
        if bundle["reportee_avg"]:
            r = _avg_row(ws, r, bundle["reportee_avg"])
        r += 1

    sec_no += 1
    ws.cell(r, 1, "%s、调薪方案" % _cn_number(sec_no)).font = Font(bold=True)
    r += 2
    meta_start = r

    # 与用户调整后的模板一致：上次调薪、绩效、九宫格放在方案表之前
    def meta_label(cell, value):
        cell.value = value
        cell.font = Font(bold=True, size=9)
        cell.fill = HEAD_FILL
        cell.alignment = CENTER

    def meta_value(cell, value, fmt=None):
        cell.value = value
        cell.font = Font(size=11)
        cell.alignment = LEFT
        if fmt:
            cell.number_format = fmt

    def meta_blank(cell):
        cell.font = Font(size=10)
        cell.alignment = LEFT

    meta_label(ws.cell(r, 1), "上次调薪日期")
    meta_value(ws.cell(r, 2), t.get("last_raise_date", ""))
    meta_blank(ws.cell(r, 3))
    meta_label(ws.cell(r, 4), "固薪调整比例")
    meta_value(ws.cell(r, 5), t.get("last_raise_ratio"), "0.0%")
    r += 1

    year = datetime.date.today().year
    meta_label(ws.cell(r, 1), "最近两次绩效等级")
    meta_value(ws.cell(r, 2), "%02d年: %s" % ((year - 2) % 100, t.get("perf2", "")))
    meta_value(ws.cell(r, 3), "%02d年: %s" % ((year - 1) % 100, t.get("perf1", "")))
    meta_blank(ws.cell(r, 4))
    meta_blank(ws.cell(r, 5))
    r += 1

    meta_label(ws.cell(r, 1), "最新九宫格评价")
    meta_value(ws.cell(r, 2), t.get("nine_box", ""))
    meta_blank(ws.cell(r, 3))
    meta_blank(ws.cell(r, 4))
    meta_blank(ws.cell(r, 5))
    r += 2

    # 摘要块只画 A-E 的边框，F 列保持空白
    for mr in range(meta_start, meta_start + 3):
        for c in range(1, 6):
            ws.cell(mr, c).border = BORDER

    for c, h in enumerate(["科目", "当前信息", "拟定信息", "涨幅", "同层级参考", "备注"], 1):
        cell = ws.cell(r, c, h)
        cell.font = Font(bold=True, size=9)
        cell.fill = HEAD_FILL
        cell.alignment = CENTER
        cell.border = BORDER
    r += 1

    ggs12 = str(bundle.get("template", "")).startswith("GGS12")

    def put(subj, before=None, after=None, growth=None, peer=None, note=None, group=False):
        nonlocal r
        if group:
            cell = ws.cell(r, 1, subj)
            cell.font = Font(bold=True)
            cell.fill = HEAD_FILL
            cell.alignment = LEFT
            for c in range(1, 7):
                ws.cell(r, c).border = BORDER
        else:
            for c, val in enumerate([subj, before, after, growth, peer, note], 1):
                cell = ws.cell(r, c, val)
                cell.border = BORDER
                cell.alignment = LEFT
                if c in (2, 3, 5) and isinstance(val, (int, float)):
                    cell.number_format = MONEY_FMT
                if c == 4 and isinstance(val, (int, float)):
                    cell.number_format = "0.0%"
        r += 1

    def g(key):
        return s.get(key, {})

    put("组织岗位职级",
        "%s\n%s\n%s序列 GGS%s" % (old_org, old_post, old_seq, t.get("ggs", "")),
        "%s\n%s\n%s序列 GGS%s" % (new_org, new_post, new_seq, t.get("new_ggs", "")))
    org_row = r - 1
    ws.row_dimensions[org_row].height = 88.5
    for c in range(1, 7):
        ws.cell(org_row, c).border = BORDER
    put("职级", g("职级").get("before"), g("职级").get("after"))
    put("固薪", group=True)
    put("固薪", g("固薪").get("before"), g("固薪").get("after"),
        g("固薪").get("growth"), g("固薪").get("peer"))
    put("月薪", g("月薪").get("before"), g("月薪").get("after"),
        g("月薪").get("growth"), g("月薪").get("peer"))
    put("13薪/12薪", g("13薪/12薪").get("before"), g("13薪/12薪").get("after"),
        None, None, "按拟定薪数折算")
    put("奖金", group=True)
    put("奖金基线", g("奖金基线").get("before"), g("奖金基线").get("after"),
        g("奖金基线").get("growth"), g("奖金基线").get("peer"))
    put("奖金基线占比",
        "%.0f%%" % ((g("奖金基线占比").get("before") or 0) * 100),
        "%.0f%%" % ((g("奖金基线占比").get("after") or 0) * 100),
        None, None, "默认标准占比")
    put("上年实发奖金", g("上年实发奖金").get("before"), g("上年实发奖金").get("after"))
    if not ggs12:
        put("长期激励", group=True)
        put("长期激励标准", "按公司政策参与", "按公司政策参与")
        put("上年实发长期激励", g("上年实发长期激励").get("before"),
            g("上年实发长期激励").get("after"))
    resident_before = g("驻在津贴").get("before") or 0
    if resident_before:
        put("现金补贴", group=True)
        put("驻在津贴", resident_before, g("驻在津贴").get("after") or resident_before,
            None, None, "默认=调薪前")
    put("汇总", group=True)
    put("固薪+奖金基线", g("固薪+奖金基线").get("before"), g("固薪+奖金基线").get("after"),
        g("固薪+奖金基线").get("growth"), g("固薪+奖金基线").get("peer"))
    put("固薪+实发奖金", g("固薪+实发奖金").get("before"), g("固薪+实发奖金").get("after"),
        g("固薪+实发奖金").get("growth"))
    if not ggs12:
        put("固薪+实发奖金+实发长期激励", g("固薪+实发奖金+实发长期激励").get("before"),
            g("固薪+实发奖金+实发长期激励").get("after"),
            g("固薪+实发奖金+实发长期激励").get("growth"))

    r += 1

    # 最终方案只展示“不符合项”，pass/info 不铺开
    for key, label in (("peer", "同级"), ("reportee", "下级")):
        counts = bundle.get("sample_counts", {}).get(key, {})
        if counts.get("missing"):
            ws.cell(r, 1, "%s固薪样本：有效 %d 人，缺失 %d 人（已排除）。" %
                    (label, counts["valid"], counts["missing"])).alignment = LEFT
            r += 1
    r = _render_checks(ws, r, bundle.get("checks"))

    _autofit(ws, [40] + WIDTHS[1:], max_width=46, caps={1: 46, 2: 18, 3: 18})

    ws2 = wb.create_sheet("薪酬结构表（附录）")
    for i, w in enumerate([10, 8, 12, 12, 12, 12, 12], 1):
        ws2.column_dimensions[get_column_letter(i)].width = w
    for c, h in enumerate(["城市", "GGS", "一档", "二档", "三档", "四档", "五档"], 1):
        cell = ws2.cell(1, c, h)
        cell.font = Font(bold=True)
        cell.fill = HEAD_FILL
        cell.alignment = CENTER
        cell.border = BORDER
    r2 = 2
    for tier in ("一线", "二线"):
        for ggs in sorted(GRADE_TABLE[tier]):
            for c, v in enumerate([tier, ggs] + GRADE_TABLE[tier][ggs], 1):
                cell = ws2.cell(r2, c, v)
                cell.border = BORDER
                cell.alignment = CENTER
                if c >= 3:
                    cell.number_format = MONEY_FMT
            r2 += 1

    ws3 = wb.create_sheet("字段与口径")
    for i, w in enumerate([22, 46, 30], 1):
        ws3.column_dimensions[get_column_letter(i)].width = w
    for c, h in enumerate(["字段/科目", "口径", "来源"], 1):
        cell = ws3.cell(1, c, h)
        cell.font = Font(bold=True)
        cell.fill = HEAD_FILL
        cell.alignment = CENTER
        cell.border = BORDER
    rows3 = [
        ("固薪", "当前固薪 × (1+本次采用涨幅)", "系统建议/计算"),
        ("月薪", "年固薪 / 对应薪数", "计算"),
        ("奖金基线", "固薪 × 占比/(1-占比)", "计算"),
        ("奖金基线占比", "按拟定 GGS 查标准占比表", "SKILL 内置"),
        ("固定薪酬+奖金基线", "固薪 + 奖金基线", "计算"),
        ("上年实发奖金", "调薪后 = 同层级平均", "同层级平均"),
        ("上年实发长期激励", "调薪后 = 同层级平均", "同层级平均"),
        ("薪酬竞争力", "固薪 / 城市×GGS 三档", "计算"),
        ("建议涨幅", "按底线和参考原则给出；不写死绩效等级固定比例", "系统建议"),
        ("底线②", "当前固薪≤上级固薪时，调后固薪不得超上级；上级无权限或当前已高于上级→不校验", "规则"),
        ("平均值", "固薪、奖金基线、合计、上年实发奖金、长期激励、竞争力", "计算"),
        ("13薪/12薪", "沿用原月数，空→13", "规则"),
        ("模板", "调薪后 GGS≤12 → GGS12 及以下", "规则"),
        ("名单圈人", "上级=组织管理者（M 组织-1 级/P/T 同组织）；同级=大L3/中小L2+GGS+序列；下级=仅M、本组织+下级组织前10", "规则"),
    ]
    for i, (a, b, c) in enumerate(rows3, 2):
        for j, v in enumerate([a, b, c], 1):
            cell = ws3.cell(i, j, v)
            cell.border = BORDER
            cell.alignment = WRAP

    return _save(wb, path)

# -*- coding: utf-8 -*-
"""薪酬计算 & 涨幅建议

  - 薪酬竞争力 = 固薪 / 城市×GGS 三档
  - 月薪       = 固薪 / 对应薪数（缺失时依业务场景处理）
  - 奖金基线   = 固薪 × 占比 / (1−占比)（按 GGS 查占比）
  - 固薪+奖金基线 = 固薪 + 奖金基线
  - 上年实发奖金 / 长期激励（调薪后）= 同层级平均
"""

import math

from structure import (
    standard_bonus_ratio, grade_band, grade_third, city_tier,
    RATIO_MIN, RATIO_MAX,
)


def _clamp(v, lo, hi):
    return max(lo, min(hi, v))


# ---------------- 单点计算 ----------------
def monthly(fixed, months):
    """月薪 = 固薪 / 薪数；支持任意薪数（12/13/16薪…），缺失默认 13。"""
    m = int(months) if months and int(months) > 0 else 13
    return round(fixed / m, 2)


def bonus_ratio(ggs):
    return standard_bonus_ratio(ggs)


def bonus_base(fixed, ggs):
    # 占比定义：r = 奖金基线 / (固薪 + 奖金基线) → 奖金基线 = 固薪 × r/(1-r)
    r = standard_bonus_ratio(ggs)
    return round(fixed * r / (1 - r), 2)


def total_fixed_plus_bonus(fixed, ggs):
    return round(fixed + bonus_base(fixed, ggs), 2)


def competitiveness(fixed, city, ggs):
    denom = grade_third(city, ggs)
    return round(fixed / denom, 4) if denom and fixed is not None else None


# ---------------- 人员一览行（报告二/三/四节） ----------------
def competition_note(fixed, city, grade):
    value = competitiveness(fixed, city, grade)
    if value is None:
        return "薪酬竞争力未校验，缺少对应职级的薪酬结构档位。"
    return "薪酬竞争力：%.1f%%" % (value * 100)


def person_row(p, ggs=None):
    """生成报告人员行。缺失固薪及其派生列保持为空。"""
    g = int(ggs if ggs is not None else p.get("ggs") or 0)
    fixed = p.get("fixed")
    bb = bonus_base(fixed, g) if fixed is not None else None
    return {
        "emp_id": p["emp_id"],
        "name": p["name"],
        "nationality": p.get("nationality", ""),
        "ggs": g,
        "l2": p.get("l2", ""),
        "l3": p.get("l3", ""),
        "l4": p.get("l4", ""),
        "l5": p.get("l5", ""),
        "l6": p.get("l6", ""),
        "seq": p.get("seq", ""),
        "post": p.get("post", ""),
        "city": p.get("city", ""),
        "city_tier": city_tier(p.get("city", "")),
        "fixed": fixed,
        "bonus_base": bb,
        "bonus_ratio": standard_bonus_ratio(g),
        "total_fixed_bonus": round(fixed + bb, 2) if bb is not None else None,
        "months": p.get("months", 13) or 13,
        "currency": "人民币" if str(p.get("currency", "")).upper() in ("CNY", "RMB") else (p.get("currency") or "人民币"),
        "last_bonus": p.get("last_bonus", 0),
        "last_lti": p.get("last_lti", 0),
        "competitiveness": competitiveness(fixed, p.get("city"), g),
        "perf1": p.get("perf1", ""),
        "perf2": p.get("perf2", ""),
        "perf3": p.get("perf3", ""),
        "nine_box": p.get("nine_box", ""),
        "edu": p.get("edu", ""),
        "school_type": p.get("school_type", ""),
        "join_date": p.get("join_date", ""),
        "cohort": p.get("cohort", ""),
        "family": p.get("family", ""),
        "post_class": p.get("post_class", ""),
        "post_sub": p.get("post_sub", ""),
    }


def average_rows(rows):
    """平均值行：固薪、奖金基线、合计、上年实发奖金、上年实发长期激励、竞争力。"""
    rows = [row for row in rows if (row.get("fixed") or 0) > 0]
    if not rows:
        return None

    def avg(k):
        vals = [r[k] for r in rows if r[k] is not None]
        return round(sum(vals) / len(vals), 2) if vals else None

    return {
        "emp_id": "", "name": "平均值", "ggs": "", "l2": "", "l3": "",
        "seq": "", "post": "",
        "fixed": avg("fixed"),
        "bonus_base": avg("bonus_base"),
        "bonus_ratio": "",
        "total_fixed_bonus": avg("total_fixed_bonus"),
        "last_bonus": avg("last_bonus"),
        "last_lti": avg("last_lti"),
        "competitiveness": avg("competitiveness"),
    }


# ---------------- 涨幅建议（区间中点向上取整） ----------------
def recommend_ratio(cur_fixed, new_ggs, city, peer_avg_fixed=None,
                    upper_fixed=None):
    """按底线/参考原则得到可行区间，取中点并向上取整到 1%。

    可行区间：
      5%~30%；当前固薪不超过上级时，调后不超上级；
      当前固薪不超过同级平均时，调后不超同级平均；
      调后不超薪酬结构表五档。
    绩效、九宫格、竞争力不再参与涨幅取值。
    """
    low = RATIO_MIN
    high = RATIO_MAX
    warnings = []

    # 当前固薪为 0（新入职无固薪，或数据缺失）时无法算任何比例上限，
    # 直接按基础区间给建议并明确提示，避免除零。
    if not cur_fixed or cur_fixed <= 0:
        warnings.append("当前固薪为 0 或缺失，无法按上级/同级/五档封顶，"
                        "建议仅按 %d%%~%d%% 基础区间参考，请先核实现值"
                        % (round(RATIO_MIN * 100), round(RATIO_MAX * 100)))
        mid = (low + high) / 2.0
        return {
            "low": round(low, 4),
            "high": round(high, 4),
            "suggest": round(math.ceil(round(mid * 100, 6)) / 100.0, 4),
            "competitiveness": "",
            "warnings": warnings,
            "basis": "当前固薪缺失，按基础区间中点给（未做封顶）",
        }

    # 底线 2：只在当前固薪不超过上级时，约束调后固薪
    if upper_fixed and cur_fixed <= upper_fixed:
        cap = upper_fixed / cur_fixed - 1
        high = min(high, max(low, cap))
    elif upper_fixed and cur_fixed > upper_fixed:
        warnings.append("当前固薪已高于上级固薪，不适用上级封顶")

    # 参考：只在调薪前不超过同级平均时，才约束调后不超过同级平均
    if peer_avg_fixed:
        if cur_fixed <= peer_avg_fixed:
            cap = peer_avg_fixed / cur_fixed - 1
            high = min(high, max(low, cap))
        else:
            warnings.append("当前固薪已高于同级平均，不适用同级平均封顶")

    # 参考：不超过薪酬结构表五档
    band = grade_band(city, new_ggs)
    band5 = band[4] if band else None
    if band5 and cur_fixed > 0:
        cap = band5 / cur_fixed - 1
        high = min(high, max(low, cap))
        if cur_fixed * (1 + high) > band5:
            warnings.append("调后固薪接近/超过薪酬结构表五档")
    elif band5 and cur_fixed <= 0:
        warnings.append("当前固薪为 0（薪酬台账无记录？），涨幅区间不可信，请先核实现值")

    if high < low:
        high = low

    # 区间中点，向上取整到 1%
    mid = (low + high) / 2.0
    first = math.ceil(round(low * 100, 9))
    last = math.floor(round(high * 100, 9))
    suggest = max(first, min(last, math.ceil(round(mid * 100, 9)))) / 100.0
    needs_approval = bool(upper_fixed and cur_fixed <= upper_fixed
                          and round(cur_fixed * (1 + suggest), 2) > upper_fixed)
    if needs_approval:
        warnings.append("最低涨幅仍超过上级固薪，需人工审批。")

    return {
        "low": round(low, 4),
        "high": round(high, 4),
        "suggest": round(suggest, 4),
        "competitiveness": competitiveness(cur_fixed, city, new_ggs),
        "warnings": warnings,
        "requires_approval": needs_approval,
        "basis": "最低涨幅方案，需审批" if needs_approval else "在允许区间内取接近中点的整数百分比",
    }


# ---------------- 方案科目表（sheet1 五、调薪方案） ----------------
def build_scheme(target, new_ggs, ratio, peer_rows, new_months=None):
    old_fixed = float(target["fixed"])
    new_fixed = round(old_fixed * (1 + ratio), 2)
    old_months = target.get("months") or 13
    new_months = int(new_months or 13)   # 定薪拟定默认13薪；可用 new_months 指定
    peer_avg_bonus = average_rows(peer_rows)["last_bonus"] if peer_rows else None
    peer_avg_lti = average_rows(peer_rows)["last_lti"] if peer_rows else None

    old_bb = bonus_base(old_fixed, target["ggs"])
    new_bb = bonus_base(new_fixed, new_ggs)
    old_ratio = standard_bonus_ratio(target["ggs"])
    new_ratio = standard_bonus_ratio(new_ggs)

    def growth(a, b):
        return round((b - a) / a, 4) if a else None

    return {
        "职级": {"before": target["ggs"], "after": new_ggs, "growth": None,
                 "peer": None, "note": "职级来源用户告知"},
        "固薪": {"before": old_fixed, "after": new_fixed, "growth": growth(old_fixed, new_fixed),
                 "peer": (average_rows(peer_rows) or {}).get("fixed"),
                 "note": competition_note(new_fixed, target.get("city"), new_ggs)},
        "月薪": {"before": monthly(old_fixed, old_months), "after": monthly(new_fixed, new_months),
                 "growth": growth(monthly(old_fixed, old_months), monthly(new_fixed, new_months)),
                 "peer": round((average_rows(peer_rows) or {}).get("fixed", 0) / new_months, 2) if peer_rows else None,
                 "note": "月薪=固薪/%d薪" % new_months},
        "13薪/12薪": {"before": "%d薪" % old_months, "after": "%d薪" % new_months,
                      "growth": None, "peer": None,
                      "note": "拟定默认13薪；支持任意≥12薪数"},
        "奖金基线": {"before": old_bb, "after": new_bb, "growth": growth(old_bb, new_bb),
                     "peer": (average_rows(peer_rows) or {}).get("bonus_base"),
                     "note": "占比 %d%%→%d%%" % (old_ratio * 100, new_ratio * 100)},
        "奖金基线占比": {"before": old_ratio, "after": new_ratio, "growth": None,
                         "peer": None, "note": "默认标准占比"},
        "上年实发奖金": {"before": target.get("last_bonus", 0), "after": peer_avg_bonus,
                         "growth": None, "peer": None, "note": "调薪后参考上年同层级平均"},
        "上年实发长期激励": {"before": target.get("last_lti", 0), "after": peer_avg_lti,
                             "growth": None, "peer": None, "note": "调薪后参考上年同层级平均"},
        "驻在津贴": {"before": target.get("resident", 0), "after": target.get("resident", 0),
                     "growth": None, "peer": None, "note": "默认=调薪前"},
        "固薪+奖金基线": {
            "before": round(old_fixed + old_bb, 2), "after": round(new_fixed + new_bb, 2),
            "growth": growth(old_fixed + old_bb, new_fixed + new_bb),
            "peer": (average_rows(peer_rows) or {}).get("total_fixed_bonus"), "note": "计算"},
        "固薪+实发奖金": {
            "before": round(old_fixed + target.get("last_bonus", 0), 2),
            "after": round(new_fixed + (peer_avg_bonus or 0), 2),
            "growth": growth(old_fixed + target.get("last_bonus", 0), new_fixed + (peer_avg_bonus or 0)),
            "peer": None, "note": "调薪后实发奖金参考上年同层级平均"},
        "固薪+实发奖金+实发长期激励": {
            "before": round(old_fixed + target.get("last_bonus", 0) + target.get("last_lti", 0), 2),
            "after": round(new_fixed + (peer_avg_bonus or 0) + (peer_avg_lti or 0), 2),
            "growth": growth(old_fixed + target.get("last_bonus", 0) + target.get("last_lti", 0),
                             new_fixed + (peer_avg_bonus or 0) + (peer_avg_lti or 0)),
            "peer": None, "note": "奖金、长期激励参考上年同层级平均"},
    }
